<?php

return array(
    'app_name' => '渠道特权-稳定的特权',//项目名称
    'db' => array(
        'dsn' => 'mysql:host=127.0.0.1;port=3306;dbname=tq',//数据库IP和端口(端口可以省略 如果是默认端口的话) 数据库名称
        'username' => 'root',//用户名
        'password' => 'a19900725',//密码
        'table_prefix' => 'lol_'//表前缀
    ),
    'app_file_name' => 'app_lol',//APP文件夹名称
    'auto_import' => array('base','models','extends','tcp'),
    'is_param_route' => true,//是否为参数路由
    'is_log' => false,//是否需要记录日志
);
