$.app = {
    postData:function(url,post_data,callback,errcallbak){
        var interval;
        var tip_e = $('#tip_info');

        $.ajax({
            url: url,
            data: post_data,
            type: 'post',
            dataType: 'json',
            beforeSend: function(){
                tip_e.html('执行中');
                var text = '';
                interval = setInterval(function(){
                    if(text == '···'){
                        text = '';
                    }else{
                        text += '·';
                    }
                    tip_e.html('执行中'+text);
                },1000);
            },
            success: function (res_data) {
                clearInterval(interval);

                if(res_data.hasOwnProperty('msg')){
                    tip_e.html(res_data['msg']);
                }

                if(res_data['ok']){
                    if(callback){
                        callback();
                    }else{
                        window.location.href = res_data['url'];
                    }
                }else{
                    if(errcallbak){
                        errcallbak();
                    }
                }
            },
            error: function (res_data) {
                clearInterval(interval);
                tip_e.html('未知错误请稍后尝试');
            }
        });
    },
    post:function(form,callback,errcallback){
        var url = form.attr('action');
        var post_data = form.serialize();
        this.postData(url,post_data,callback,errcallback);
    }
}

$('.btn_search').click(function(){
    var search_form = $(this).parent('.search_form');
    var url = search_form.attr('action');
    var condition = search_form.serialize();
    window.location.href = url+'&'+condition;
});

$('.page_box .btn_page').click(function(){
    var page = $(this).data('page');
    $('#page').val(page);
    $('.btn_search').click();
});

$('.date_time').focus(function(){
    WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})
});