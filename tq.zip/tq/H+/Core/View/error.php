<!DOCTYPE html>
<html>
<head>
    <title><?php echo H::app()->getConfig('app_name'); ?></title>
    <meta charset="utf-8">
    <style>
        body{text-align: center;position: relative;top: 100px;color: red;font-size: 24px;}
    </style>
</head>
<body>

<div style="color: red;">
    <?php

    echo $msg.'<br/>';

    if(is_array($data)){
        foreach($data as $v){
            echo $v['file'].'[第'.$v['line'].'行]<br/>';
        }
    }else{
        echo $file.'[第'.$line.'行]<br/>';
    }

    ?>
</div>

</body>
</html>