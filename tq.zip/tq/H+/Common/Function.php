<?php

/**
 * 打印方法
 * @param mixed $var 被打印的数据
 */
function p($var) {
    echo "<pre>" . print_r($var, true) . "</pre>";
}

function getClientIP() {
    global $ip;
    if (getenv("HTTP_CLIENT_IP"))
        $ip = getenv("HTTP_CLIENT_IP");
    else if (getenv("HTTP_X_FORWARDED_FOR"))
        $ip = getenv("HTTP_X_FORWARDED_FOR");
    else if (getenv("REMOTE_ADDR"))
        $ip = getenv("REMOTE_ADDR");
    else $ip = "Unknow";
    return $ip;
}

function getAbsoluteUrl($url){
    if(isset($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME']){
        $REQUEST_SCHEME = $_SERVER['REQUEST_SCHEME'];
    }else{
        $REQUEST_SCHEME = 'http';
    }
    return $REQUEST_SCHEME.'://'.$_SERVER['HTTP_HOST'].$url;
}