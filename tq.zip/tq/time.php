<?php

echo time();