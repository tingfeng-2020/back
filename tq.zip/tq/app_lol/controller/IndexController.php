<?php

class IndexController extends HController{

    public function actionIndex(){
        $this->render([]);
    }

}