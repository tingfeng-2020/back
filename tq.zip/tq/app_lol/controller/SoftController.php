<?php

class SoftController extends ManageAuthController{

    public function beforeAction() {
        if(!AuthManage::isHave(AuthManage::SET_SOFT_NOTICE)){
            echo 'page error';
            exit;
        }

        return parent::beforeAction();
    }

    public function actionSet(){
        list($ver,$msg) = Set::model()->getHuojianInfo();

        $qq_qun = Set::model()->getHuojianQun();

        $this->render(array(
            'msg' => $msg,
            'qq_qun' => $qq_qun
        ));
    }

    public function actionSave(){
        $msg = $this->getParams('msg');
        $qq_qun = $this->getParams('qq_qun');

        Set::model()->updateByType(Set::HUOJIAN_VER,[
            'msg' => $msg
        ]);

        Set::model()->updateByType(Set::HUOJIAN_QQ_QUN,[
            'data' => $qq_qun
        ]);

        $this->echoOk(array(
            'data' => array(
                'url' => $this->genurl('set')
            )
        ));
    }

}