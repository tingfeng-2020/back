<?php

class ToolController extends ManageAuthController{

    public function beforeAction() {
        if(!Manage::isSuperAdmin()){
            echo 'page error';
            exit;
        }

        return parent::beforeAction();
    }

    public function actionIndex(){
        $this->render();
    }

    public function actionSave(){
        $mac = $this->getParams('mac');
        $num = (int)$this->getParams('num');
        $remark = $this->getParams('remark',false,'');

        if($num <= 0 || $num >= 100){
            $this->echoErr('生成个数必须大于0且小于100');
        }

        $mac_arr = [];
        for($i=0;$i<=$num;$i++){
            $last = $i+1;
            if($last < 10){
                $last = '0'.$last;
            }
            $mac_arr[] = $mac.'-'.$last.' '.$remark.$last;
        }

        $filename = 'MAC-'.date('YmdHis').'-('.$num.'个).txt';
        header("Content-Type: application/octet-stream");
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        foreach($mac_arr as $str){
            echo $str."\r\n";
        }
    }

}