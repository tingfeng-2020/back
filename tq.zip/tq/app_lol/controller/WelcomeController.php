<?php

class WelcomeController extends Controller{

    public function actionIndex(){
        //$nb = $this->getParams('nb',false,'');
        $this->render([],false);
    }

}