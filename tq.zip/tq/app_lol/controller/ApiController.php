<?php

class ApiController extends Controller{

    private function ipCheck(){
        if(!IpCheck::model()->isOk(getClientIP())){
            $this->echoErr('你的请求太着急，请休息5秒再尝试');
        }
    }

    public function actionLogintest(){
        $this->echoErr('当前版本不可用！');
        $account = $this->getParams('account');
        $pwd = $this->getParams('pwd');
        $device = $this->getParams('device');
        $nb = (int)$this->getParams('nb',false,0);

        $user = User::model()->queryByAccount($account);
        if(!$user){
            $this->echoErr('账号或密码错误');
        }

        if($user['pwd'] != Encrypt::encodeUserPwd($pwd)){
            $this->echoErr('账号或密码错误');
        }

        if($nb && $user['type'] != User::TYPE_VIP){
            $this->echoErr('您不是VIP尊享客户，请使用普通版本');
        }

        if($user['end_time'] <= time()){
            $this->echoErr('账号已到期，请充值后使用');
        }

        if($user['status'] != User::STATUS_OK){
            $this->echoErr('账号已被禁用');
        }

        $update_data = [
            'ip' => getClientIP()
        ];

        if($user['device']){
            if($user['device'] != $device){
                $this->echoErr('账号与绑定的机器不一致');
            }
        }else{
            $update_data['device'] = $device;
        }

        User::model()->updateAttrById($user['id'],$update_data);

        $this->echoOk(array('data'=>array(
            'msg' => '到期时间 '.date('Y-m-d H:i:s',$user['end_time']),
            'sign' => Encrypt::getSign(time(),$user['id'])
        )));
    }

    public function actionLogin(){
        $account = $this->getParams('account');
        $pwd = $this->getParams('pwd');
        $device = $this->getParams('device');
        $nb = (int)$this->getParams('nb',false,0);
        $cf = (int)$this->getParams('cf',false,0);

        $user = User::model()->queryByAccount($account);
        if(!$user){
            $this->echoErr('账号或密码错误');
        }

        if($user['pwd'] != Encrypt::encodeUserPwd($pwd)){
            $this->echoErr('账号或密码错误');
        }

        if($cf && $user['type'] != User::TYPE_CHAOFAN){
            $this->echoErr('账号或密码错误');
        }

        if(!$nb && !$cf && $user['type'] != User::TYPE_NORMAL){
            $this->echoErr('账号或密码错误');
        }

        if($nb && $user['type'] != User::TYPE_VIP){
            $this->echoErr('您不是VIP尊享客户，请使用普通版本');
        }

        if($user['end_time'] <= time()){
            $this->echoErr('账号已到期，请充值后使用');
        }

        if($user['status'] != User::STATUS_OK){
            $this->echoErr('账号已被禁用');
        }

        $update_data = [
            'ip' => getClientIP()
        ];

        if($user['device']){
            if($user['device'] != $device){
                $this->echoErr('账号与绑定的机器不一致');
            }
        }else{
            $update_data['device'] = $device;
        }

        User::model()->updateAttrById($user['id'],$update_data);

        $this->echoOk(array('data'=>array(
            'msg' => '到期时间 '.date('Y-m-d H:i:s',$user['end_time']),
            'sign' => Encrypt::getSign(time(),$user['id'])
        )));
    }

    public function actionReg() {
        $this->ipCheck();

        if(!Set::model()->isCanReg()){
            $this->echoErr('当前注册通道关闭，请等待开放');
        }

        $account = $this->getParams('account');
        $pwd = $this->getParams('pwd');
        $code = $this->getParams('code');
        $nb = (int)$this->getParams('nb',false,0);
        $cf = (int)$this->getParams('cf',false,0);

        $card = Card::model()->queryByCode($code);
        if(!$card){
            $this->echoErr('卡密不存在');
        }

        if($cf && $card['card_type'] != Card::CARD_TYPE_CHAOFAN){
            $this->echoErr('卡密不存在');
        }

        if(!$cf && !$nb && $card['card_type'] != Card::CARD_TYPE_NORMAL){
            $this->echoErr('卡密不存在');
        }

        if($nb && $card['card_type'] != Card::CARD_TYPE_VIP){
            $this->echoErr('该卡密不是VIP尊享卡密无法使用');
        }

        if($card['status'] == Card::STATUS_BANED || $card['status'] == Card::STATUS_CHANGE){
            $this->echoErr('卡密已被封禁');
        }

        if($card['uid'] || $card['status'] == Card::STATUS_USE){
            $this->echoErr('卡密已被使用');
        }

        $user = User::model()->queryByAccount($account);
        if($user){
            $this->echoErr('账号已经存在');
        }

        $transaction = HModel::beginTransaction();

        $uid = User::model()->insert([
            'account' => $account,
            'pwd' => Encrypt::encodeUserPwd($pwd),
            'ip' => getClientIP(),
            'type' => $card['card_type'],
            'card_type_id' => $card['card_type_id'],
        ]);

        $user = User::model()->queryByUid($uid);
        list($ok,$msg) = Card::cardPay($user,$card);
        if($ok){
            $transaction->commit();
            $this->echoOk(array('data' => array(
                'msg' => $cf?'注册成功，欢迎使用易迅':'注册成功，欢迎加入渠道！'
            )));
        }else{
            $transaction->rollBack();
            $this->echoErr($msg);
        }

    }

    public function actionPay() {
        $this->ipCheck();

        if(!Set::model()->isCanPay()){
            $this->echoErr('当前充值通道关闭，请等待开放');
        }

        $account = $this->getParams('account');
        $code = $this->getParams('code');
        $cf = (int)$this->getParams('cf',false,0);
        $nb = (int)$this->getParams('nb',false,0);

        $user = User::model()->queryByAccount($account);
        if(!$user){
            $this->echoErr('账号不存在');
        }

        if($cf && $user['type'] != User::TYPE_CHAOFAN){
            $this->echoErr('账号不存在');
        }

        if($nb && $user['type'] != User::TYPE_VIP){
            $this->echoErr('账号不存在');
        }

        if(!$cf && !$nb && $user['type'] != User::TYPE_NORMAL){
            $this->echoErr('账号不存在');
        }

        $card = Card::model()->queryByCode($code);
        if(!$card){
            $this->echoErr('卡密不存在');
        }

        if($cf && $card['card_type'] != Card::CARD_TYPE_CHAOFAN){
            $this->echoErr('卡密不存在');
        }

        if($nb && $card['card_type'] != Card::CARD_TYPE_VIP){
            $this->echoErr('卡密不存在');
        }

        if(!$nb && !$cf && $card['card_type'] != Card::CARD_TYPE_NORMAL){
            $this->echoErr('卡密不存在');
        }

        if($user['type'] == User::TYPE_VIP){
            if($card['card_type'] == Card::CARD_TYPE_NORMAL){
                $this->echoErr('该卡密为普通卡密，不可以充值VIP用户');
            }
        }

        $is_need_fenpei = false;
        if($card['card_type'] == Card::CARD_TYPE_VIP && $user['type'] != User::TYPE_VIP){
            $is_need_fenpei = true;
        }

        $transaction = HModel::beginTransaction();
        list($ok,$msg) = Card::cardPay($user,$card,$is_need_fenpei);
        if($ok){
            User::model()->updateAttrById($user['id'],[
                'type' => $card['card_type'],
                'card_type_id' => $card['card_type_id']
            ]);

            $transaction->commit();
            $this->echoOk(array('data' => array(
                'msg' => '充值成功，感谢你的支持！'
            )));
        }else{
            $transaction->rollBack();
            $this->echoErr($msg);
        }

    }

    public function actionEdit() {
        $this->ipCheck();

        $account = $this->getParams('account');
        $pwd_old = $this->getParams('pwd_old');
        $pwd_new = $this->getParams('pwd_new');

        $user = User::model()->queryByAccount($account);
        if(!$user){
            $this->echoErr('账号不存在');
        }

        if($user['pwd'] != Encrypt::encodeUserPwd($pwd_old)){
            $this->echoErr('旧密码错误');
        }

        User::model()->updateAttrById($user['id'],[
            'pwd' => Encrypt::encodeUserPwd($pwd_new)
        ]);

        $this->echoOk(array('data' => array(
            'msg' => '修改密码成功'
        )));
    }

    public function actionGetnum(){
        $list = WgMac::model()->getFenpeiCanUseNum();
        $this->echoOk(array('data' => array(
            'list' => $list
        )));
    }

    public function actionGetfile(){
        $nb = (int)$this->getParams('nb',false,0);

        $this->echoOk(array('data' => array(
            'list' => Files::model()->getList($nb)
        )));
    }

    public function actionLucybox(){
        $account = $this->getParams('account');
        $device = $this->getParams('device');
        $activity_id = $this->getParams('aid');
        $ip = getClientIP();

        $start_time = 0;
        $activity_id_arr = [];

        $activity_arr = Activity::model()->queryAllByNowTime();
        $is_have = FALSE;
        foreach($activity_arr as $activity){
            $start_time = $activity['s_time'];
            $activity_id_arr[] = $activity['id'];
            if($activity['id'] == $activity_id){
                $is_have = TRUE;
            }
        }

        if(!$is_have){
            $this->echoErr('活动不存在');
        }

        $user = User::model()->queryByAccount($account);
        if(!$user){
            $this->echoErr('账号不存在，无法参与抽奖');
        }

        $time = time();

        if($user['end_time'] < $time){
            $this->echoErr('账号已到期，无法参与抽奖');
        }

        $is_start = FALSE;
        $time_ok_arr = [];
        foreach($activity_arr as $activity){
            if($activity['s_time'] <= $time){
                $is_start = TRUE;
                if($time <= $activity['e_time']){
                    $time_ok_arr[] = $activity;
                }
            }
        }

        if(!$is_start){
            $this->echoErr('活动还未开始');
        }
        if(empty($time_ok_arr)){
            $this->echoErr('活动已经结束');
        }

        $can_use_arr = [];
        foreach($time_ok_arr as $activity){
            if($activity['lucy_num'] < $activity['all_num']){
                $can_use_arr[] = $activity;
            }
        }

        if(empty($can_use_arr)){
            $this->echoErr('所有奖品已经发放完毕');
        }

        $pay_num = Card::model()->getPayNumByUidAndTime($user['id'],$start_time);
        $pay_num++;//加1次默认的抽奖机会

        $lucy_num = LucyUser::model()->countByTimeActivityIdArr($user['id'],$start_time,$activity_id_arr);
        if($pay_num <= $lucy_num){
            $this->echoErr('你已经参与：'.$lucy_num.'次，没有剩余可用次数。PS:每次充值增加1次');
        }

        $lucy_arr = [];
        foreach($can_use_arr as $activity){
            $rand = mt_rand(1,100);
            if($rand <= $activity['odds']){
                $lucy_arr[] = $activity;
            }
        }

        $transaction = HModel::beginTransaction();

        $num = 0;
        if(empty($lucy_arr)){
            $activity = $can_use_arr[0];
        }else{
            $max_key = count($lucy_arr) - 1;
            $key = mt_rand(0,$max_key);
            $activity = $lucy_arr[$key];

            $sign_num = Activity::model()->getSignNum($activity['id']);
            if($sign_num <= $activity['all_num']){
                $num = $activity['num'];

                $sql = 'update {{activity}} set lucy_num = lucy_num + 1 where id = '.$activity['id'];
                Activity::model()->querySql($sql);
            }
        }

        $msg = '很遗憾你未能中奖';
        if($num > 0){
            if($user['end_time'] > time()){
                $end_time = $user['end_time'] + $num*3600;
            }else{
                $end_time = time() + $num*3600;
            }

            $wg_id_arr = $activity['wg_id_str']?explode(',',$activity['wg_id_str']):[];

            list($ok,$msg) = User::model()->upsertUserWgMacId($user,$end_time,0,$wg_id_arr);
            if($ok){
                $msg = '恭喜你抽中了 '.$activity['name'];
            }else{
                $num = 0;
                $sql = 'update {{activity}} set sign_num = sign_num - 1,lucy_num = lucy_num - 1 where id = '.$activity['id'];
                Activity::model()->querySql($sql);
            }
        }

        LucyUser::model()->insert([
            'activity_id' => $activity['id'],
            'uid' => $user['id'],
            'time' => time(),
            'num' => $num,
            'ip' => $ip,
            'device' => $device
        ]);

        //计算中奖的KEY 2 4 6 8
        $key = mt_rand(1,8);

        if($num){
            if($num >= 360){
                $key = 8;//特等奖
            }else if($num >= 168){
                $key = 2;//1等奖
            }else if($num > 24 && $num <= 72){
                $key = 4;//2等奖
            }else{
                $key = 6;//3等奖
            }
        }else{
            if($key == 2 || $key == 4){
                $key--;
            }else if($key == 6 || $key == 8){
                $key++;
            }
        }

        $transaction->commit();

        $this->echoOk(array('data' => array(
            'msg' => '转动吧我的小黄!',
            'real_msg' => $msg,
            'key' => $key//中奖的KEY
        )));
    }

}