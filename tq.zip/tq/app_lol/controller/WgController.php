<?php

class WgController extends ManageAuthController{

    public function beforeAction() {
        if(!Manage::isSuperAdmin()){
            echo 'page error';
            exit;
        }

        return parent::beforeAction();
    }

    public function actionIndex(){
        $list = Wg::model()->getList();

        $this->render(array(
            'list' => $list
        ));
    }

    public function actionAlt(){
        if(!Manage::isSuperAdmin()){
            $this->echoErr('没有权限修改');
        }

        $id = (int)$this->getParams('id');

        $wg = Wg::model()->queryById($id);
        if(!$wg){
            $this->echoErr('网关不存在');
        }

        $this->render(array(
            'wg' => $wg
        ));
    }

    public function actionSave(){
        $id = (int)$this->getParams('id');
        $type = (int)$this->getParams('type');
        $account = $this->getParams('account');
        $local_config = $this->getParams('local_config');

        $wg = Wg::model()->queryById($id);
        if(!$wg){
            $this->echoErr('网关不存在');
        }

        Wg::saveData($id,array(
            'type' => $type?1:0,
            'account' => $account,
            'local_config' => $local_config
        ));

        Wg::model()->updateMacNum($wg['id']);

        $this->echoOk(array(
            'data' => array(
                'url' => $this->genurl('index')
            )
        ));
    }

    public function actionAdd(){
        $id = (int)$this->getParams('id');

        $wg = Wg::model()->queryById($id);

        if(!$wg){
            $this->echoErr('网关不存在');
        }

        $this->render(array(
            'wg' => $wg
        ));
    }

    public function actionSavemac(){
        $id = (int)$this->getParams('id');
        $end_time = $this->getParams('end_time',false,'');
        $mac_str = $this->getParams('mac_str');
        $group_str = $this->getParams('group_str',false,'');
        $type = (int)$this->getParams('type',false,WgMac::TYPE_FENPEI_MAC);

        if($mac_str == ''){
            $this->echoErr('MAC地址不可以为空');
        }

        $wg = Wg::model()->queryById($id);

        if(!$wg){
            $this->echoErr('网关不存在');
        }

        $mac_arr = explode("\n",$mac_str);

        $all_arr = array();
        foreach($mac_arr as $v){
            $arr = explode(' ',trim($v));
            if(count($arr) <= 0){
                $this->echoErr('MAC地址存在错误,请更正');
            }
            $mac = trim($arr[0]);
            if(!Mac::checkedMac($mac)){
                $this->echoErr($mac.' MAC地址错误,请更正');
            }
            if(in_array($mac,$all_arr)){
                $this->echoErr($mac.' 该MAC地址再本次操作中重复');
            }

            $all_arr[] = $mac;
        }

        $end_time = $end_time?strtotime($end_time):0;

        $inser_data = array();
        foreach($all_arr as $mac){
            if($type == WgMac::TYPE_WB_MAC){
                $is_have = Mac::model()->queryByMac($mac);
            }else{
                $is_have = WgMac::model()->queryByMac($mac);
            }
            if($is_have){
                $this->echoErr($mac.' 这个MAC地址已经存在');
            }

            if($type == WgMac::TYPE_WB_MAC){
                $inser_data[] = array(
                    'time' => time(),
                    'group_str' => $group_str,
                    'mac' => $mac,
                    'wg_id' => $wg['id'],
                    'end_time' => $end_time
                );
            }else{
                $inser_data[] = array(
                    'mac' => $mac,
                    'wg_id' => $wg['id'],
                    'card_id' => 0,
                    'status' => WgMac::STATUS_OFFLINE
                );
            }
        }

        if($type == WgMac::TYPE_WB_MAC){
            Mac::model()->insertAll($inser_data);
        }else{
            WgMac::model()->insertAll($inser_data);
        }

        Wg::model()->updateMacNum($wg['id']);

        $this->echoOk(array(
            'data' => array(
                'url' => $this->genurl('index')
            )
        ));
    }

    public function actionDel(){
        if(!Manage::isSuperAdmin()){
            $this->echoErr('没有权限修改');
        }

        $id = (int)$this->getParams('id');
        $wg = Wg::model()->queryById($id);
        if(!$wg){
            $this->echoErr('网关不存在');
        }

        Wg::model()->delete(array(
            'condition' => 'id = ?',
            'param' => array($wg['id'])
        ));

        Mac::model()->delete(array(
            'condition' => 'wg_id = ?',
            'param' => array($wg['id'])
        ));

        $this->echoOk();
    }

    public function actionTgpkey(){
        $id = (int)$this->getParams('id');

        $wg = Wg::model()->queryById($id);

        if(!$wg){
            $this->echoErr('网关不存在');
        }

        if(!Manage::isSuperAdmin() && $wg['mid'] != HSession::get('uid')){
            $this->echoErr('无权限操作');
        }

        $filename = 'tgp.key';
        header("Content-Type: application/octet-stream");
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $data = $wg['id'].'-'.md5('tgp'.md5($wg['id']).'key');

        echo $data;
    }

}