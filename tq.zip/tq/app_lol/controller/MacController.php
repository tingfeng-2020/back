<?php

class MacController extends ManageAuthController{

    public function beforeAction() {
        if(!Manage::isSuperAdmin()){
            echo 'page error';
            exit;
        }

        return parent::beforeAction();
    }

    public function actionIndex(){
        list($list,$all_num,$now_page) = Mac::model()->getList($this);

        $this->render(array(
            'list' => $list,
            'all_num' => $all_num,
            'now_page' => $now_page
        ));
    }

    public function actionAlt(){
        $id = (int)$this->getParams('id');

        $mac = Mac::model()->queryById($id);
        if(!$mac){
            $this->echoErr('MAC不存在');
        }

        $this->render(array(
            'mac' => $mac
        ));
    }

    public function actionSave(){
        $id = (int)$this->getParams('id');
        $group_str = $this->getParams('group_str');
        $end_time = $this->getParams('end_time');
        $mac_str = $this->getParams('mac');
        $status = (int)$this->getParams('status');
        $wg_id = (int)$this->getParams('wg_id',false,0);

        $mac = Mac::model()->queryById($id);
        if(!$mac){
            $this->echoErr('MAC不存在');
        }

        $update_data = [
            'mac' => $mac_str,
            'group_str' => $group_str,
            'end_time' => $end_time?strtotime($end_time):0,
            'status' => $status==Mac::STATUS_OK?Mac::STATUS_OK:Mac::STATUS_NO
        ];

        if($wg_id){
        	$update_data['wg_id'] = $wg_id;
        }

        Mac::saveData($id,$update_data);

        $this->echoOk(array(
            'data' => array(
                'url' => $this->genurl('index')
            )
        ));
    }

    public function actionDel(){
        $id = (int)$this->getParams('id');
        $mac = Mac::model()->queryById($id);
        if(!$mac){
            $this->echoErr('MAC不存在');
        }

        Mac::model()->delete(array(
            'condition' => 'id = ?',
            'param' => array($mac['id'])
        ));

        $this->echoOk();
    }

}