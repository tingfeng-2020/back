<?php

class TaskController extends Controller{

    public function actionRestart(){
        $wg_id = (int)$this->getParams('wg_id');

        $task = Task::model()->getByWgId($wg_id);
        if($task){
            Task::model()->updateAllDeal($wg_id);
        }

        $this->echoOk(array('data' => array(
            'restart' => $task?1:0
        )));
    }

}