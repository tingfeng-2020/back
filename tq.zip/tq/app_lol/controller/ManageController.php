<?php

Class ManageController extends ManageAuthController{

    public function beforeAction() {
        if(!Manage::isManage()){
            echo 'page error';
            exit;
        }

        return parent::beforeAction();
    }

    public function actionIndex(){
        list($list,$all_num,$now_page,$all_money)  = Manage::model()->getList($this);

        $this->render(array(
            'list' => $list,
            'all_num' => $all_num,
            'now_page' => $now_page,
            'all_money' => $all_money
        ));
    }

    public function actionAlt(){
        $id = (int)$this->getParams('id',false,0);

        $manage = Manage::model()->queryById($id);

        $this->render(array(
            'manage' => $manage
        ));
    }

    public function actionSave(){
        $id = $this->getParams('id',false,0);
        $qq = $this->getParams('qq',false,'');
        $account = $this->getParams('account');
        $pwd = $this->getParams('pwd',false,'');
//        $type = (int)$this->getParams('type',false,0);
        $money = (float)$this->getParams('money',false,0);
        $status = (int)$this->getParams('status');
        $auth_arr = $this->getParams('auth',false,[]);
        $can_view_card_type = $this->getParams('can_view_card_type',false,'');

        $manage = null;
        if($id > 0){
            $manage = Manage::model()->queryById($id);
            if(!$manage){
                $this->echoErr('用户不存在');
            }

            if(!Manage::isSuperAdmin() && $manage['pid'] != HSession::get('uid')){
                $this->echoErr('没有权限修改他的资料');
            }
        }

        if($account == ''){
            $this->echoErr('账号不可以为空');
        }
        if($pwd == '' && !$id){
            $this->echoErr('密码不可以为空');
        }
        $is_have = Manage::model()->queryByAccount($account,$id);
        if($is_have){
            $this->echoErr('账号已经存在');
        }

        $data = array(
            'account' => $account,
            'status' => $status,
            'qq' => $qq,
            'auth' => empty($auth_arr)?'':implode(',',$auth_arr),
            'can_view_card_type' => $can_view_card_type
        );

        $data['type'] = Manage::TYPE_MANAGE;

        if(Manage::isSuperAdmin()){
            $data['money'] = $money;
        }

        if($pwd != ''){
            $pwd = Encrypt::encodeUserPwd($pwd);
            $data['pwd'] = $pwd;
        }
        $mid = Manage::saveData($manage,$data);

        if(Manage::isSuperAdmin() && $money != 0){
            if($manage){
                $money = $money - (float)$manage['money'];
            }
            Money::model()->insert([
                'uid' => HSession::get('uid'),
                'money' => (string)$money,
                'mid' => $mid,
                'time' => time()
            ]);
        }

        $this->echoOk(array(
            'data' => array(
                'url' => $this->genurl('index')
            )
        ));
    }

    public function actionDel(){
        $id = (int)$this->getParams('id');
        $manage = Manage::model()->queryById($id);
        if(!$manage){
            $this->echoErr('用户不存在');
        }

        if(!Manage::isSuperAdmin() && $manage['pid'] != HSession::get('uid')){
            $this->echoErr('没有权限这样操作');
        }

        Manage::saveData($manage,[
            'status' => Manage::STATUS_DEL
        ]);

        $this->echoOk();
    }

}