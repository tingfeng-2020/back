<?php

class SysController extends ManageAuthController{

    public function beforeAction() {
        if(!Manage::isSuperAdmin()){
            echo 'page error';
            exit;
        }

        return parent::beforeAction();
    }

    public function actionSet(){
        $is_can_reg = Set::model()->isCanReg();
        $is_can_pay = Set::model()->isCanPay();

        $this->render(array(
            'is_can_reg' => $is_can_reg,
            'is_can_pay' => $is_can_pay
        ));
    }

    public function actionSave(){
        $is_can_reg = (int)$this->getParams('is_can_reg');
        $is_can_pay = (int)$this->getParams('is_can_pay');

        Set::model()->updateByType(Set::CAN_REG,[
            'data' => $is_can_reg==1?1:0
        ]);

        Set::model()->updateByType(Set::CAN_PAY,[
            'data' => $is_can_pay==1?1:0
        ]);

        $this->echoOk(array(
            'data' => array(
                'url' => $this->genurl('set')
            )
        ));
    }

}