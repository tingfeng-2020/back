<?php

class WgMacController extends ManageAuthController{

    public function beforeAction() {
        if(!Manage::isSuperAdmin()){
            echo 'page error';
            exit;
        }

        return parent::beforeAction();
    }

    public function actionIndex(){
        list($list,$all_num,$now_page) = WgMac::model()->getList($this);

        $this->render(array(
            'list' => $list,
            'all_num' => $all_num,
            'now_page' => $now_page
        ));
    }

    public function actionUnbind(){
        $id = (int)$this->getParams('id');
        $mac = WgMac::model()->queryById($id);
        if(!$mac){
            $this->echoErr('MAC不存在');
        }

        WgMac::model()->updateAttr($id,[
            'card_id' => 0,
            'uid' => 0
        ]);

        $this->echoOk();
    }

    public function actionDel(){
        $id = (int)$this->getParams('id');
        $mac = WgMac::model()->queryById($id);
        if(!$mac){
            $this->echoErr('MAC不存在');
        }

        WgMac::model()->delete(array(
            'condition' => 'id = ?',
            'param' => array($mac['id'])
        ));

        Wg::model()->updateMacNum($mac['wg_id']);

        $this->echoOk();
    }

    public function actionExport(){
        $mac_remark = $this->getParams('mac_remark',false,'');

        $mac_arr = WgMac::model()->getList($this,true);

        $filename = '导出MAC'.date('YmdHis').'-('.count($mac_arr).'个).txt';
        header("Content-Type: application/octet-stream");
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        foreach($mac_arr as $mac){
            echo $mac['mac']." ".$mac_remark."\r\n";
        }
    }

}