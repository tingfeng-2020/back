<?php

class TcpController extends Controller{

    public function actionRun(){
        //更新所有网关状态为不在线
        Wg::model()->updateALLOffline();
        WgMac::model()->updateALLOffline();

        $tcp_handler = new TcpHandler();

        $table = new swoole_table(1024*10);
        $table->column('type', swoole_table::TYPE_INT);
        $table->column('fd', swoole_table::TYPE_INT);
        $table->column('user_type', swoole_table::TYPE_INT);//用户类型 1.卡密用户 2.网吧用户
        $table->column('wg_id', swoole_table::TYPE_INT);
        $table->column('wg_fd', swoole_table::TYPE_INT);
        $table->column('card_id', swoole_table::TYPE_STRING, 20);//卡密ID
        $table->column('wg_mac', swoole_table::TYPE_STRING,20);//网关MAC地址
        $table->column('mac', swoole_table::TYPE_STRING,20);//88-88-88-88-88-88
        $table->column('ip', swoole_table::TYPE_STRING,20);//192.168.168.168
        $table->column('ip_inner', swoole_table::TYPE_STRING,20);
        $table->column('end_time', swoole_table::TYPE_STRING,11);
        $table->column('is_send_close_msg', swoole_table::TYPE_INT);
        $table->create();

        $server = new swoole_server('0.0.0.0', 2019);

        $server->table = $table;

        $server->set([
            'heartbeat_check_interval' => 20,//心跳检测间隔时间 单位S
            'heartbeat_idle_time' => 20,//TCP最大闲置时间 单位S 超过就断开连接
            'open_length_check' => true,//检测数据完整性
            'package_max_length' => 81920,//单个封包最大长度
            'package_body_offset' => 12,
            'package_length_func' => [$tcp_handler,'package_length_func'],
        ]);

        $server->on('connect', [$tcp_handler,'onConnect']);

        $server->on('receive', [$tcp_handler,'onReceive']);

        $server->on('close', [$tcp_handler,'onClose']);

        $server->start();
    }

}