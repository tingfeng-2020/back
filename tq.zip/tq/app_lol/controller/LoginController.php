<?php

class LoginController extends Controller{

    public function actionIndex(){
        $data = HGeetest::getInitData();

        $this->render($data,false);
    }

    public function actionLogin(){
        $account = $this->getParams('account');
        $pwd = $this->getParams('pwd');

//        $geetest_challenge = $this->getParams('geetest_challenge');
//        $geetest_validate = $this->getParams('geetest_validate');
//        $geetest_seccode = $this->getParams('geetest_seccode');
//
//        $code_status = HGeetest::checkStatus($geetest_challenge,$geetest_validate,$geetest_seccode);
//        if(!$code_status){
//            $this->echoErr('验证码测试失败!');
//        }

        list($ok,$msg) = Manage::model()->verifyUserInfo($account,$pwd);

        if($ok){
            $this->echoOk(array('data'=>array(
                'url' => $this->genurl('index/index')
            )));
        }else{
            $this->echoErr($msg);
        }
    }

    public function actionLogout(){
        HSession::loginOut();
        $this->redirect('login/index');
    }

    public function actionPage(){
        $nb = $this->getParams('nb',false,'');
        $cf = $this->getParams('cf',false,'');
        $ver = $this->getParams('ver',false,'1.0');

        $server_ver = '1.0';
        $msg = 'aaaa';
        $nb = 1;
//        if($nb){
//            list($server_ver,$msg) = Set::model()->getNeibuInfo();
//        }else if($cf){
//            list($server_ver,$msg) = Set::model()->getHuojianInfo();
//        }else{
//            list($server_ver,$msg) = Set::model()->getVerCard();
//        }
//
//        $activity = Activity::model()->queryByNowTime();

        $this->render([
            'api_url' => $this->genurl('',[],false),
            'ver' => $ver,
            'server_ver' => $server_ver,
            'aid' => 0,
            'ui_page' => '',
            'nb' => $nb,
            'cf' => $cf,
            'msg' => $msg
        ],false);
    }

    public function actionQdqun(){
        echo Set::model()->getQudaoQun();
        exit;
    }

    public function actionChaofanqun(){
        echo Set::model()->getHuojianQun();
        exit;
    }

    public function getAbsolutePublicUrl($url){
        return getAbsoluteUrl(H::app()->public_url).$url;
    }

}