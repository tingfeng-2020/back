<?php

class UserController extends HController{

    public function actionIndex(){
        list($list,$all_num,$now_page) = User::model()->getList($this);

        $this->render(array(
            'list' => $list,
            'all_num' => $all_num,
            'now_page' => $now_page
        ));
    }

    public function actionAlt(){
        if(!Manage::isSuperAdmin()){
            $this->echoErr('没有权限修改');
        }

        $id = $this->getParams('id',false,0);

        $user = User::model()->queryByUid($id);

        if(!Manage::checkCardTypeId($user['card_type_id'])){
            $this->echoErr('没有权限进行这样操作');
        }

        $this->render(array(
            'user' => $user
        ));
    }

    public function actionSave(){
        $id = $this->getParams('id',false,0);
        $pwd = $this->getParams('pwd',false,'');
        $num = (int)$this->getParams('num',false,0);
        $unbind = (int)$this->getParams('unbind',false,0);
        $account = $this->getParams('account',false,'');
        $new_wg_id = (int)$this->getParams('new_wg',false,0);
        $type = (int)$this->getParams('type',false,0);

        if(!Manage::isSuperAdmin()){
            $this->echoErr('没有权限修改');
        }

        $user = User::model()->queryByUid($id);

        if(!$user){
            $this->echoErr('用户不存在');
        }

        if(!Manage::checkCardTypeId($user['card_type_id'])){
            $this->echoErr('没有权限进行这样操作');
        }

        $transaction = HModel::beginTransaction();

        $data = [];

        if($pwd){
            $data['pwd'] = Encrypt::encodeUserPwd($pwd);
        }

        if(Manage::isHermitAdmin() && $account){
            $data['account'] = $account;
        }

        if($type > 0){
            if($user['type'] != $type){
                $card_type = CardType::model()->query([
                    'condition' => 'type = ?',
                    'param' => array($type),
                ]);
                $data['card_type_id'] = $card_type['id'];
            }
            $data['type'] = $type;
        }

        if($new_wg_id != 0){
            if($user['wg_mac_id']){
                WgMac::model()->updateAttr($user['wg_mac_id'],['uid' => -1]);
            }

            if($new_wg_id == -1){
                $wg_id_arr = [];
            }else{
                $wg_id_arr = [$new_wg_id];
            }

            list($wg_mac,$msg) = WgMac::model()->getFenpeiMac($user['id'],0,$wg_id_arr);
            if(!$wg_mac){
                $transaction->rollBack();
                $this->echoErr($msg);
            }
            $data['wg_mac_id'] = $wg_mac['id'];
        }

        if($num != 0){
            $data['end_time'] = $user['end_time'] + $num*3600;
            if($data['end_time'] < 0){
                $data['end_time'] = 0;
            }
        }

        if($unbind == 1){
            $data['device'] = '';
        }

        if(!empty($data)){
            User::model()->updateAttrById($user['id'],$data);
        }

        $transaction->commit();

        $this->echoOk(array(
            'data' => array(
                'url' => $this->genurl('index')
            )
        ));
    }

    public function actionBaned(){
        if(!AuthManage::isHave(AuthManage::USER_BANED)){
            $this->echoErr('没有权限这样操作');
        }

        $id = $this->getParams('id');
        $user = User::model()->queryByUid($id);
        if(!$user){
            $this->echoErr('用户不存在');
        }

        if(!Manage::checkCardTypeId($user['card_type_id'])){
            $this->echoErr('没有权限进行这样操作');
        }

        $transaction = HModel::beginTransaction();

        $status = $user['status']==User::STATUS_OK?User::STATUS_BANED:User::STATUS_OK;

        $res = User::model()->updateAttrById($user['id'],[
            'status' => $status
        ]);
        if(!$res){
            $this->echoErr('操作失败',array(
                'transaction' => $transaction
            ));
        }

        if($status==User::STATUS_BANED){
            Card::model()->sendDelClientMsg($user['id']);
        }

        $this->echoOk(array(
            'transaction' => $transaction
        ));
    }

    public function actionUnbind(){
        if(!AuthManage::isHave(AuthManage::USER_UNBIND)){
            $this->echoErr('没有权限这样操作');
        }

        $id = $this->getParams('id');
        $user = User::model()->queryByUid($id);
        if(!$user){
            $this->echoErr('用户不存在');
        }

        if(!Manage::checkCardTypeId($user['card_type_id'])){
            $this->echoErr('没有权限进行这样操作');
        }

        User::model()->updateAttrById($user['id'],[
            'device' => ''
        ]);

        $this->echoOk(array(
            'msg' => '解绑成功!'
        ));
    }

    public function actionBatchtime(){
        if(!Manage::isSuperAdmin()){
            $this->echoErr('没有权限这样操作');
        }

        $num = (int)$this->getParams('num',false,0);
        if($num <= 0){
            $this->echoErr('操作的时间数量必须大于0');
        }

        User::model()->getList($this,$num);

        $this->echoOk();
    }

    public function actionMoveuser(){
        if(!Manage::isSuperAdmin()){
            $this->echoErr('没有权限这样操作');
        }
        $wg_id = (int)$this->getParams('wg_id');
        $new_wg_id = (int)$this->getParams('new_wg_id');
        if(!$wg_id){
            $this->echoErr('WG_ID错误');
        }
        if(!$new_wg_id){
            $this->echoErr('NEW_WG_ID错误');
        }

        $time = time();

        $join = 'left join {{wg_mac}} as wg_mac on wg_mac.id = t.wg_mac_id';
        $condition = 't.end_time > ? and wg_mac.wg_id = ? and t.status = ? and t.wg_mac_id > 0';
        $param = [$time,$wg_id,User::STATUS_OK];

        $user_arr = User::model()->join($join)->queryAll([
            'condition' => $condition,
            'param' => $param,
            'field' => 't.id as id,t.wg_mac_id as wg_mac_id'
        ]);

        if(!empty($user_arr)){
            foreach ($user_arr as $user){
                $transaction = HModel::beginTransaction();

                $wg_mac_id = $user['wg_mac_id'];

                WgMac::model()->update([
                    'uid' => '-1'
                ],[
                    'condition' => 'id = '.$wg_mac_id,
                ]);

                list($wg_mac,$msg) = WgMac::model()->getFenpeiMac($user['id'],0,[$new_wg_id]);
                if($wg_mac){
                    User::model()->updateAttrById($user['id'],[
                        'wg_mac_id' => $wg_mac['id']
                    ]);
                    $transaction->commit();
                }else{
                    $transaction->rollBack();
                }
            }
        }

        $this->echoOk();
    }

}