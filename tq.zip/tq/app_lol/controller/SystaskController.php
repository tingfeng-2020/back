<?php

class SystaskController extends ManageAuthController{

    public function beforeAction() {
        if(!Manage::isSuperAdmin()){
            echo 'page error';
            exit;
        }

        return parent::beforeAction();
    }

    public function actionList(){
        list($list,$all_num,$now_page) = Task::model()->getList($this);

        $this->render(array(
            'list' => $list,
            'all_num' => $all_num,
            'now_page' => $now_page
        ));
    }

    public function actionAdd(){
        $wg_id = (int)$this->getParams('wg_id');

        Task::model()->insert([
            'wg_id' => $wg_id,
            'status' => Task::STATUS_WAIT,
            'time' => time()
        ]);

        $this->echoOk();
    }

}