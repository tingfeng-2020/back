<?php

class CardController extends HController{

    public function actionIndex(){
        list($list,$all_num,$now_page) = Card::model()->getList($this);

        $this->render(array(
            'list' => $list,
            'all_num' => $all_num,
            'now_page' => $now_page
        ));
    }

    public function actionAlt(){
        if(!Manage::isSuperAdmin()){
            $this->echoErr('没有权限修改');
        }

        $id = (int)$this->getParams('id');

        $card = Card::model()->queryById($id);
        if(!$card){
            $this->echoErr('卡密不存在');
        }

        $this->render(array(
            'card' => $card
        ));
    }

    public function actionAltsave(){
        if(!Manage::isSuperAdmin()){
            $this->echoErr('没有权限修改');
        }

        $id = (int)$this->getParams('id');
        $can_use_wg = $this->getParams('can_use_wg',false,'');
        $group_str = $this->getParams('group_str',false,'');

        $card = Card::model()->queryById($id);
        if(!$card){
            $this->echoErr('卡密不存在');
        }

        if(!Manage::checkCardTypeId($card['card_type_id'])){
            $this->echoErr('没有权限进行这样操作');
        }

        $wg_id_arr = [];
        $temp_arr = $can_use_wg?explode(',',$can_use_wg):[];
        foreach ($temp_arr as $wg_id){
            $wg = Wg::model()->queryById($wg_id);
            if($wg){
                $wg_id_arr[] = $wg_id;
            }else{
                $this->echoErr('填写的网关ID存在错误，请核实');
            }
        }

        $update_data = [
            'group_str' => $group_str,
            'can_use_wg' => implode(',',$wg_id_arr)
        ];

        if(Manage::isHermitAdmin()){
            $update_data['is_pay'] = $this->getParams('is_pay',false,0);
        }

        Card::model()->updateAttrById($card['id'],$update_data);

        $this->echoOk(array(
            'data' => array(
                'url' => $this->genurl('index')
            )
        ));
    }

    public function actionBatchCreate(){
        $type_arr = CardType::getTypeArr();

        $first_card_type = null;
        foreach($type_arr as $data){
            $first_card_type = $data;
            break;
        }
        $this->render(array(
            'type_arr' => $type_arr,
            'first_card_type' => $first_card_type
        ));
    }

    public function actionCheckData(){
        $num = (int)$this->getParams('num');
        $type_id = (int)$this->getParams('card_type',false,0);
        $group_str = $this->getParams('group_str',false,'');

        if(!Manage::checkCardTypeId($type_id)){
            $this->echoErr('没有权限进行这样操作');
        }

        if(strlen($group_str) > 20){
            $this->echoErr('标记字符串长度不可以超过20');
        }
        if($num <= 0 || $num > 1000){
            $this->echoErr('生成张数必须大于0且小于1000');
        }
        $card_type = CardType::model()->queryById($type_id);
        if(!$card_type){
            $this->echoErr('类型不存在');
        }

        if(!Manage::isSuperAdmin()){
            $me_money = (float)Manage::getMeInfo('money');
            $need_pay_money = $num*$card_type['money'];
            if($me_money < $need_pay_money){
                $this->echoErr('余额不足，无法生成对应数量的卡密');
            }
        }

        $this->echoOk();
    }

    public function actionSave(){
        $num = (int)$this->getParams('num');
        $type_id = (int)$this->getParams('card_type',false,0);
        $group_str = $this->getParams('group_str',false,'');
        $type = (int)$this->getParams('type',FALSE,0);
        $new_money = $this->getParams('new_money',false,0);

        if(!Manage::checkCardTypeId($type_id)){
            $this->echoErr('没有权限进行这样操作');
        }

        if(!Manage::isSuperAdmin()){
            $type = Card::TYPE_SALE;
        }

        if(strlen($group_str) > 20){
            $this->echoErr('标记字符串长度不可以超过20');
        }
        if($num <= 0 || $num > 1000){
            $this->echoErr('生成张数必须大于0且小于1000');
        }
        $card_type = CardType::model()->queryById($type_id);
        if(!$card_type){
            $this->echoErr('类型不存在');
        }

        if(Manage::isSuperAdmin()){
            $res = true;
            $transaction = HModel::beginTransaction();
        }else{
            $me_money = (float)Manage::getMeInfo('money');
            $need_pay_money = $num*$card_type['money'];
            if($me_money < $need_pay_money){
                $this->echoErr('余额不足，无法生成对应数量的卡密');
            }

            $transaction = HModel::beginTransaction();

            //先扣钱
            $res = Manage::model()->updateAttrById(HSession::get('uid'),array(
                'money' => $me_money - $need_pay_money
            ));
        }

        $insert_data = array();
        if($res && Card::batchCreate($type,$group_str,$num,$card_type,$insert_data,$new_money)){

            $filename = $card_type['name'].'-卡密'.date('YmdHis').'-('.count($insert_data).'张).txt';
            header("Content-Type: application/octet-stream");
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            foreach($insert_data as $card){
                echo $card['code']."\r\n";
            }

            $transaction->commit();
        }else{
            $transaction->rollBack();
        }
    }

    public function actionGetnew(){
        $code = $this->getParams('code');
        $card = Card::model()->queryByCode($code);
        if(!$card){
            $this->echoErr('卡密不存在');
        }

        if(!Manage::checkCardTypeId($card['card_type_id'])){
            $this->echoErr('没有权限进行这样操作');
        }

        if(!AuthManage::isHave(AuthManage::CARD_BANED_CHANGE)){
            $this->echoErr('没有权限这样操作');
        }

        if(!Manage::isSuperAdmin() && $card['manage_id'] != HSession::get('uid')){
            if(!AuthManage::isHave(AuthManage::CARD_VIEW_ALL)){
                $this->echoErr('没有权限这样操作');
            }
        }

        if($card['use_time'] == 0){
            $this->echoErr('卡密未被使用不可以封换，请使用删除卡密');
        }

        $card_end_time = $card['use_time'] + 6*3600;//6小时内才可以封换
        if($card_end_time < time()){
        	$this->echoErr('卡密被使用时间超过6小时无法封换');
        }

        $transaction = HModel::beginTransaction();

        $del_res = Card::model()->removeCard($card);
        if(!$del_res){
            $this->echoErr('封卡失败',array(
                'transaction' => $transaction
            ));
        }

        $manage = Manage::model()->queryById($card['manage_id']);
        if($manage && $manage['type'] != Manage::TYPE_SUPER_ADMIN){
            Manage::saveData($manage,array(
                'money' => $manage['money'] + $card['money']
            ));
        }

        $this->echoOk(array(
            'transaction' => $transaction
        ));
    }

    public function actionDel(){
        $code = $this->getParams('code');
        $del = (int)$this->getParams('del',FALSE,0);
        $card = Card::model()->queryByCode($code);
        if(!$card){
            $this->echoErr('卡密不存在');
        }

        if(!Manage::checkCardTypeId($card['card_type_id'])){
            $this->echoErr('没有权限进行这样操作');
        }

        if(!AuthManage::isHave(AuthManage::CARD_DEL)){
            $this->echoErr('没有权限这样操作');
        }

        if(!Manage::isSuperAdmin() && $card['manage_id'] != HSession::get('uid')){
            if(!AuthManage::isHave(AuthManage::CARD_VIEW_ALL)){
                $this->echoErr('没有权限这样操作');
            }
        }

        $transaction = HModel::beginTransaction();

        $del_res = Card::model()->removeCard($card);
        if(!$del_res){
            $this->echoErr('卡密删除失败',array(
                'transaction' => $transaction
            ));
        }

        if($card['use_time'] == 0 && $del == 0){
            $manage = Manage::model()->queryById($card['manage_id']);
            if($manage && $manage['type'] != Manage::TYPE_SUPER_ADMIN){
                Manage::saveData($manage,array(
                    'money' => $manage['money'] + $card['money']
                ));
            }
        }

        $this->echoOk(array(
            'transaction' => $transaction
        ));
    }

    public function actionUnbind(){
        $id = (int)$this->getParams('id');
        $card = Card::model()->queryById($id);
        if(!$card){
            $this->echoErr('卡密不存在');
        }

        if(!Manage::checkCardTypeId($card['card_type_id'])){
            $this->echoErr('没有权限进行这样操作');
        }

        if($card['use_time'] == 0){
            $this->echoErr('卡密未使用不可以解绑');
        }

        $del_time = 3600*6;
        if(($card['end_time'] - time()) < $del_time){
            $this->echoErr('卡密剩余时间不足6小时，无法解绑');
        }

        Card::model()->updateAttrById($id,[
            'device' => '',
            'end_time' => $card['end_time'] - $del_time
        ]);


        $this->echoOk();
    }

    public function actionExportcheck(){
    	$num = Card::model()->getList($this,true,true);
    	if($num > 1000){
            $this->echoErr('单次导出最多可以导出1000条卡密');
    	}
    	$this->echoOk();
    }

    public function actionExport(){
    	$card_arr = Card::model()->getList($this,true);
    	if(count($card_arr) > 1000){
            $this->echoErr('单次导出最多可以导出1000条卡密');
    	}

        $filename = '导出卡密'.date('YmdHis').'-('.count($card_arr).'张).txt';
        header("Content-Type: application/octet-stream");
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        foreach($card_arr as $card){
            echo $card['code']."\r\n";
        }
    }

    public function actionJiesuan(){
        if(!Manage::isHermitAdmin()){
            $this->echoErr('没有权限操作，滚到一边去！');
        }

    	Card::model()->getList($this,FALSE,FALSE,TRUE);

    	$this->echoOk();
    }

}