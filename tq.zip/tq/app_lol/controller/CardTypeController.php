<?php

class CardTypeController extends ManageAuthController{

    public function beforeAction() {
        if(!Manage::isSuperAdmin()){
            echo 'page error';
            exit;
        }

        return parent::beforeAction();
    }

    public function actionIndex(){
        $list = CardType::model()->getList();

        $this->render(array(
            'list' => $list
        ));
    }

    public function actionAlt(){
        $id = $this->getParams('id',false,0);

        $card_type = CardType::model()->queryById($id);

        $this->render(array(
            'card_type' => $card_type
        ));
    }

    public function actionSave(){
        $id = (int)$this->getParams('id',false,0);
        $name = $this->getParams('name');
        $num = (int)$this->getParams('num');
        $money = (float)$this->getParams('money');
        $prefix = $this->getParams('prefix',false,'');
        $can_use_wg = $this->getParams('can_use_wg',false,'');
        $is_show = (int)$this->getParams('is_show',false,0);
        $type = (int)$this->getParams('type',false,1);

        if($name == ''){
            $this->echoErr('名称不可以为空');
        }
        if($num <= 0){
            $this->echoErr('时长必须大于0');
        }
        if($money <= 0){
            $this->echoErr('价格必须大于0');
        }

        $card_type = CardType::model()->queryByName($name,$id);
        if($card_type){
            $this->echoErr('该名称的卡密类型已经存在');
        }

        $wg_id_arr = [];
        $temp_arr = $can_use_wg?explode(',',$can_use_wg):[];
        foreach ($temp_arr as $wg_id){
            $wg = Wg::model()->queryById($wg_id);
            if($wg){
                $wg_id_arr[] = $wg_id;
            }else{
                $this->echoErr('填写的网关ID存在错误，请核实');
            }
        }

        $can_use_wg = implode(',',$wg_id_arr);

        $update_data = [
            'name' => $name,
            'num' => $num,
            'money' => $money,
            'prefix' => $prefix,
            'can_use_wg' => $can_use_wg,
            'is_show' => $is_show,
            'type' => $type
        ];

        CardType::saveData($id,$update_data);

        //更新相同时间未使用的卡密
        Card::model()->update([
            'can_use_wg' => $can_use_wg
        ],[
            'condition' => 'num = ? and use_time = 0',
            'param' => array($num)
        ]);


        $this->echoOk(array(
            'data' => array(
                'url' => $this->genurl('index')
            )
        ));
    }

    public function actionDel(){
        $id = (int)$this->getParams('id');
        $card_type = CardType::model()->queryById($id);
        if(!$card_type){
            $this->echoErr('类型不存在');
        }

        CardType::model()->delete(array(
            'condition' => 'id = ?',
            'param' => array($card_type['id'])
        ));

        $this->echoOk();
    }

}