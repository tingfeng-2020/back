<?php

/**
 * User: Hermit
 * Date: 2018/6/22
 * Time: 22:40
 */
class DataTypeEnum {

    const TYPE_PC = 1;//PC
    const TYPE_WG = 2;//网关

    const TYPE_HEART_BEAT = 0;//心跳包
    const TYPE_PC_ONLINE = 1;//客户上线
    const TYPE_WG_ONLINE = 2;//网关上线
    const TYPE_DATA_SEND = 3;//数据转发
    const TYPE_TEQUAN_OK = 4;//特权成功
    const TYPE_DEL_CLIENT = 5;//删除客户

    const OPTION_ERR = 0;//错误消息
    const OPTION_ONLINE = 1;//上线成功
    const OPTION_OTHER = 2;//其它转发数据
    const OPTION_PC_CLOSE = 3;//客户掉线或下线

}