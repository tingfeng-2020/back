<?php
/**
 * User: Hermit
 * Date: 2018/1/23
 * Time: 18:13
 */

class BytesClass
{

    /**
     * 转换一个String字符串为byte数组
     *
     * @param string $str 需要转换的字符串
     * @param bool $need_iconv 是否需要转码
     * @param bool   $is_have_symbol
     *
     * @return array
     */
    public static function strToBytes($str,$need_iconv = FALSE ,$is_have_symbol = FALSE)
    {
        if($need_iconv){
            $str = iconv("UTF-8",'GBK//IGNORE',$str);
        }

        $len   = strlen($str);
        $bytes = [];
        for($i = 0; $i < $len; $i++){
            $byte = ord($str[$i]);

            if($is_have_symbol && $byte >= 128){
                $byte = $byte - 256;
            }

            $bytes[] = $byte;
        }

        return $bytes;
    }

    /**
     * 将字节数组转化为String类型的数据
     *
     * @param array $bytes 字节数组
     * @param bool $need_iconv 是否需要转码
     *
     * @return string 一个String类型的数据
     */
    public static function bytesToStr($bytes,$need_iconv = FALSE)
    {
        $str = '';
        foreach($bytes as $ch){
            $str .= chr($ch);
        }

        if($need_iconv){
            return iconv('GBK','UTF-8//IGNORE',$str);
        }

        return $str;
    }

    /**
     * 转换一个int为byte数组
     *
     * @param $val 需要转换的字符串
     *
     * @return array
     */
    public static function integerToBytes($val)
    {
        $byt    = [];
        $byt[0] = ($val & 0xff);
        $byt[1] = ($val >> 8 & 0xff);    //   >>：移位    &：与位
        $byt[2] = ($val >> 16 & 0xff);
        $byt[3] = ($val >> 24 & 0xff);

        return $byt;
    }

    /**
     * 从字节数组中指定的位置读取一个Integer类型的数据
     *
     * @param $bytes    字节数组
     * @param $position 指定的开始位置
     *
     * @return int 一个Integer类型的数据
     */
    public static function bytesToInteger($bytes, $position)
    {
        $val = 0;
        $val = $bytes[$position + 3] & 0xff;
        $val <<= 8;
        $val |= $bytes[$position + 2] & 0xff;
        $val <<= 8;
        $val |= $bytes[$position + 1] & 0xff;
        $val <<= 8;
        $val |= $bytes[$position] & 0xff;

        return $val;
    }

    /**
     * 转换一个shor字符串为byte数组
     *
     * @param $val 需要转换的字符串
     *
     * @return array
     */
    public static function shortToBytes($val)
    {
        $byt    = [];
        $byt[0] = ($val & 0xff);
        $byt[1] = ($val >> 8 & 0xff);

        return $byt;
    }

    /**
     * 从字节数组中指定的位置读取一个Short类型的数据。
     *
     * @param $bytes    字节数组
     * @param $position 指定的开始位置
     *
     * @return int 一个Short类型的数据
     */
    public static function bytesToShort($bytes, $position)
    {
        $val = 0;
        $val = $bytes[$position + 1] & 0xFF;
        $val = $val << 8;
        $val |= $bytes[$position] & 0xFF;

        return $val;
    }

}