<?php

/**
 * User: Hermit
 * Date: 2018/6/22
 * Time: 23:41
 */
class TcpHandler {

    private $_data_prefix = '7743220062018';
    private $_pack_prefix_bytes = [77,43,22,0,0,6,20,18];
    private $_data_prefix_lenth = 8;
    private $_data_min_lenth = 12;

    private function h_decode_data($data){
        $data = substr($data,$this->_data_min_lenth,strlen($data)-$this->_data_min_lenth);
        $type = ord(substr($data,0,1));
        $data = substr($data,1,strlen($data)-1);
        return [$type,$data];
    }

    public function package_length_func($data){
        if (strlen($data) <= $this->_data_min_lenth) {
            return 0;//数据不足，需要接收更多数据
        }

        $data_type_str = substr($data, 0, $this->_data_prefix_lenth);
        $temp_str_arr = unpack('C*',$data_type_str);//解析为字节集
        $data_type = implode('',$temp_str_arr);
        if($data_type != $this->_data_prefix){
            return -1;//数据错误，底层会自动关闭连接
        }

        $length_str = substr($data, $this->_data_prefix_lenth, 4);
        $length_arr = unpack('I',$length_str);
        $length = 0;
        if(isset($length_arr[1]) && $length_arr[1] > 0){
            $length = $length_arr[1];
        }
        if ($length <= 0) {
            return -1;//数据错误，底层会自动关闭连接
        }

        return $this->_data_min_lenth + $length;
    }

    public function onConnect($server, $fd){}

    public function onReceive($server, $fd, $reactor_id, $data){
        list($type,$data) = $this->h_decode_data($data);

        if($type == DataTypeEnum::TYPE_DATA_SEND){
            $this->transmitData($server,$fd,$data);
        }else if($type == DataTypeEnum::TYPE_HEART_BEAT){
            //心跳包
        }else if($type == DataTypeEnum::TYPE_TEQUAN_OK){
            //特权成功
            $obj = $this->getOnlineObjByFd($server,$fd);
            if($obj && $obj->getType() == DataTypeEnum::TYPE_PC){
                $obj->tequanOkUpdate();
            }
        }else if($type == DataTypeEnum::TYPE_DEL_CLIENT){
            $uid = trim($data);
            foreach($server->connections as $pc_fd){
                $obj = $this->getOnlineObjByFd($server,$pc_fd);
                if($obj && $obj->getType() == DataTypeEnum::TYPE_PC && $obj->getUserType() == PcClass::USER_TYPE_CARD){
                    if($obj->getCardId() == $uid){
                        $this->sendMsg($server,$pc_fd,'卡密被封禁或删除');
                        $server->table->del($pc_fd);//删除客户
                        $obj->updateOnline(WgMac::STATUS_OFFLINE);
                        $server->close($pc_fd);
                    }
                }
            }
            $server->close($fd);
        }else{
            $fd_info = $server->getClientInfo($fd);
            $ip = $fd_info['remote_ip'];
            if($type == DataTypeEnum::TYPE_PC_ONLINE){
                $obj = new PcClass($ip,$fd,$data);
            }else if($type == DataTypeEnum::TYPE_WG_ONLINE){
                $obj = new WgClass($ip,$fd,$data);
            }else{
                $server->close($fd);
                return;
            }

            //是否该MAC已经在线
            list($is_online,$msg) = $this->isOnline($server,$obj);
            if($is_online){
                $this->sendMsg($server,$fd,$msg);
                $server->close($fd);
                return;
            }

            //登录验证
            list($ok,$msg) = $obj->login();
            if(!$ok){
                $this->sendMsg($server,$fd,$msg);
                $server->close($fd);
                return;
            }

            $wg_id = $obj->getWgId();
            if($obj->getType() == DataTypeEnum::TYPE_PC){
                $wg_is_off = true;
                foreach($server->connections as $_v_fd){
                    $_v_info = $server->table->get($_v_fd);
                    if($_v_info !== false && $_v_info['type'] == DataTypeEnum::TYPE_WG && $_v_info['wg_id'] == $wg_id){
                        $obj->setWgFd($_v_info['fd']);
                        $wg_is_off = false;
                        break;
                    }
                }
                if($wg_is_off){
                    $this->sendMsg($server,$fd,'网关：'.$wg_id.' 不在线，请联系代理');
                    $server->close($fd);
                    return;
                }
            }else{
                foreach($server->connections as $_v_fd){
                    $_v_info = $server->table->get($_v_fd);
                    if($_v_info !== false && $_v_info['type'] == DataTypeEnum::TYPE_PC && $_v_info['wg_id'] == $wg_id){
                        $server->table->set($_v_fd,['wg_fd'=>$obj->getFd()]);
                    }
                }
            }

            //上线成功
            $this->addTableObj($server,$fd,$obj);

            if($obj->getType() == DataTypeEnum::TYPE_PC){
                $res_data = [
                    'time' => time(),
                    'fd' => $obj->getFd(),
                    'msg' => '到期时间 '.date('Y-m-d H:i:s',$obj->getEndTime()),
                    'end_time' => $obj->getEndTime(),
                    'wg_mac' => $obj->getLoginSendMac(),
                    'wg_ip_inner' => $obj->getWgIpInner(),
                    'wg_account_ini' => $obj->getWgAccountIni(),
                    'wg_local_config' => $obj->getWgLocalConfig(),
                    'injec_game' => $obj->getInjecGame()
                ];
                $this->send($server,$fd,json_encode($res_data),DataTypeEnum::OPTION_ONLINE);
                unset($res_data);
            }
        }
    }

    /**
     * @param $server
     * @param int $fd
     * @param PcClass $obj
     */
    private function addTableObj($server,$fd,$obj){
        if($obj->getType() == DataTypeEnum::TYPE_PC){
            $server->table->set($fd,[
                'type' => DataTypeEnum::TYPE_PC,
                'user_type' => $obj->getUserType(),
                'fd' => (int)$fd,
                'wg_id' => (int)$obj->getWgId(),
                'wg_fd' => (int)$obj->getWgFd(),
                'card_id' => (string)$obj->getCardId(),
                'wg_mac' => $obj->getWgMac(),
                'mac' => $obj->getMac(),
                'device' => $obj->getDevice(),
                'ip' => $obj->getIp(),
                'ip_inner' => $obj->getIpInner(),
                'end_time' => (string)$obj->getEndTime(),
                'wg_ip_inner' => $obj->getWgIpInner(),
                'is_send_close_msg' => $obj->isSendCloseMsg()?1:0
            ]);

            $obj->updateOnline(WgMac::STATUS_ONLINE);

        }else if($obj->getType() == DataTypeEnum::TYPE_WG){
            $server->table->set($fd,[
                'type' => DataTypeEnum::TYPE_WG,
                'fd' => (int)$fd,
                'wg_id' => (int)$obj->getWgId(),
                'wg_fd' => (int)$obj->getWgFd(),
                'mac' => $obj->getMac(),
                'device' => $obj->getDevice(),
                'ip' => $obj->getIp(),
                'ip_inner' => $obj->getIpInner()
            ]);

            Task::model()->updateAllDeal($obj->getWgId());

        }else{
            $this->sendMsg($server,$fd,'请不要乱连接哦');
            $server->close($fd);
        }
    }

    public function onClose($server,$fd){
        /**
         * @var HTcpBaseClass $obj
         */
        $obj = $this->getOnlineObjByFd($server,$fd);
        if(!$obj){
            return;
        }
        if($obj->getType() == DataTypeEnum::TYPE_WG){
            $wg_id = $obj->getWgId();
            $server->table->del($fd);//删除网关

            foreach($server->connections as $pc_fd){
                $pc = $server->table->get($pc_fd);
                if($pc && $pc['type'] == DataTypeEnum::TYPE_PC && $pc['wg_id'] == $wg_id){
                    $server->table->set($pc_fd,['wg_fd'=>0]);
//                    $server->table->set($pc_fd,['is_send_close_msg'=>0]);
//                    $server->table->del($pc_fd);//删除客户
//                    $this->sendMsg($server,$pc_fd,'网关掉线，程序自动关闭，请联系代理');
//                    $server->close($pc_fd);
                }
            }

            //更新网关为不在线
            Wg::model()->upsertData($obj->getMac(),$obj->getIp(),$obj->getIpInner(),Wg::STATUS_OFFLINE);
            //更新网关的MAC为不在线
//            WgMac::model()->update([
//                'status' => WgMac::STATUS_OFFLINE,
//            ],array(
//                'condition' => 'wg_id = ?',
//                'param' => array($wg_id)
//            ));
        }else if($obj->getType() == DataTypeEnum::TYPE_PC){
            $server->table->del($fd);//删除客户
            /**
             * @var PcClass $obj
             */
            if($obj->isSendCloseMsg()){
                $this->sendPcOffline($server,$fd,$obj->getWgFd());
                $obj->updateOnline(WgMac::STATUS_OFFLINE);
            }
        }
    }

    /**
     * @param $server
     * @param HTcpBaseClass $obj
     * @return bool
     */
    private function isOnline($server,$obj){
        if($obj->getType() == DataTypeEnum::TYPE_PC){
            /**
             * @var PcClass $obj
             */
            $card_id = $obj->getCardId();
            if($card_id){
                foreach($server->connections as $fd){
                    $online_card_id = $server->table->get($fd,'card_id');
                    if($online_card_id == $card_id){
                        return [true,'该用户已经在线'];
                    }
                }
            }
        }else{
            $mac = $obj->getMac();
            foreach($server->connections as $fd){
                $online_mac = $server->table->get($fd,'mac');
                if($online_mac == $mac){
                    return [true,'该MAC已经在线'];
                }
            }
        }
        return [false,''];
    }

    /**
     * @param $server
     * @param $fd
     *
     * @return null|PcClass|WgClass
     */
    private function getOnlineObjByFd($server,$fd){
        $data = $server->table->get($fd);
        if($data == false){
            return null;
        }

        if($data['type'] == DataTypeEnum::TYPE_PC){
            $obj = new PcClass($data['ip'],$fd,'',false);
            $obj->setType(DataTypeEnum::TYPE_PC);
        }else{
            $obj = new WgClass($data['ip'],$fd,'',false);
            $obj->setType(DataTypeEnum::TYPE_WG);
        }

        $obj->setFd($fd)->setWgId($data['wg_id'])->setWgFd($data['wg_fd']);
        $obj->setMac($data['mac'])->setIp($data['ip'])->setIpInner($data['ip_inner']);

        if($data['type'] == DataTypeEnum::TYPE_PC){
            $obj->setWgMac($data['wg_mac'])->setUserType($data['user_type'])->setCardId($data['card_id']);
            $obj->setEndTime($data['end_time'])->setIsSendCloseMsg($data['is_send_close_msg']==1?true:false);
        }

        return $obj;
    }

    private function sendMsg($server,$fd,$data){
        $this->send($server,$fd,$data,DataTypeEnum::OPTION_ERR);
    }

    private function send($server,$fd,$data,$option,$is_need_iconv = true){
        $data = $this->getSendData($option,$data,$is_need_iconv);
        $server->send($fd, $data);
    }

    public function getSendData($option,$data,$is_need_iconv = true){
        if($data != '' && $is_need_iconv){
            $data = iconv("UTF-8",'GBK//IGNORE',$data);
        }

        $fd_str = BytesClass::bytesToStr(BytesClass::integerToBytes($option));

        if($data == ''){
            $data = $fd_str;
        }else{
            $data = $fd_str.$data;
        }

        return  $this->packData($data);
    }

    private function transmitData($server,$fd,$data){
        /**
         * @var HTcpBaseClass $obj
         */
        $obj = $this->getOnlineObjByFd($server,$fd);

        if($obj === null){
            return;
        }

        list($to_fd,$data) = $obj->getSendData($data);
        if($to_fd > 0 && $server->table->exist($to_fd)){
            $this->send($server,$to_fd,$data,DataTypeEnum::OPTION_OTHER,false);
        }else if($obj->getType() ==  DataTypeEnum::TYPE_PC){
            $this->sendMsg($server,$fd,'网关掉线无法授权，请退出重试');
        }
    }

    private function packData($data){
        $lenth = strlen($data);

        $lenth_bytes = BytesClass::integerToBytes($lenth);

        $bytes = array_merge($this->_pack_prefix_bytes,$lenth_bytes);

        return BytesClass::bytesToStr($bytes).$data;
    }

    private function sendPcOffline($server,$fd,$wg_fd){
        if($wg_fd > 0){
            $fd_bytes = BytesClass::integerToBytes($fd);
            $data = BytesClass::bytesToStr($fd_bytes);
            $this->send($server,$wg_fd,$data,DataTypeEnum::OPTION_PC_CLOSE);
        }
    }

}