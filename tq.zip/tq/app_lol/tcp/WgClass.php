<?php

/**
 * User: Hermit
 * Date: 2018/6/22
 * Time: 22:39
 */
class WgClass extends HTcpBaseClass{

    protected $_type = DataTypeEnum::TYPE_WG;

    private $_status = Wg::STATUS_OFFLINE;

    public function __construct($ip,$fd,$data = '',$is_need_init = true){
        if($is_need_init){
            parent::__construct($ip,$fd,$data);

            $status = isset($this->_pc_arr['status'])?(int)$this->_pc_arr['status']:Wg::STATUS_OFFLINE;

            $this->_status = $status==Wg::STATUS_ONLINE?Wg::STATUS_ONLINE:Wg::STATUS_OFFLINE;

            $this->_pc_arr = [];
        }
    }

    public function login(){
        list($wg_id,$type) = Wg::model()->upsertData($this->getMac(),$this->getIp(),$this->getIpInner(),$this->_status);

        if($type == Wg::TYPE_OK){
            $this->setWgId($wg_id);
            return [true,''];
        }else{
            return [false,'未授权网关无法连接'];
        }
    }

    public function getSendData($data){
        $to_fd_str = substr($data, 0, 4);
        $to_fd_arr = unpack('I',$to_fd_str);
        $to_fd = 0;
        if(isset($to_fd_arr[1]) && $to_fd_arr[1] > 0){
            $to_fd = $to_fd_arr[1];
        }

        $data = substr($data,4,strlen($data)-4);

        return [$to_fd,$data];
    }

}