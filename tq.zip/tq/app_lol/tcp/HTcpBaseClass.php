<?php

/**
 * User: Hermit
 * Date: 2018/6/25
 * Time: 6:37
 */
class HTcpBaseClass {

    protected $_pc_arr = [];
    protected $_type = DataTypeEnum::TYPE_PC;
    private $_fd = 0;
    private $_wg_id = 0;
    private $_wg_fd = 0;
    private $_mac = '';
    private $_device = '';

    private $_ip = '';
    private $_ip_inner = '';

    public function __construct($ip,$fd,$data = ''){
        $this->_fd = $fd;

        $this->_ip = $ip;

        $json_str = iconv("GBK",'UTF-8//IGNORE',$data);

        $this->_pc_arr = $json_str?json_decode($json_str,true):[];

        $this->_mac = isset($this->_pc_arr['mac'])?$this->_pc_arr['mac']:'';
        $this->_device = isset($this->_pc_arr['device'])?$this->_pc_arr['device']:'';
        $this->_ip_inner = isset($this->_pc_arr['ip_inner'])?$this->_pc_arr['ip_inner']:'';
    }

    public function setIp($ip){
        $this->_ip = $ip;
        return $this;
    }

    public function setIpInner($ip_inner){
        $this->_ip_inner = $ip_inner;
        return $this;
    }

    public function setMac($mac){
        $this->_mac = $mac;
        return $this;
    }

    public function setFd($fd){
        $this->_fd = $fd;
        return $this;
    }

    public function setType($type){
        $this->_type = $type;
        return $this;
    }

    public function getIp(){
        return $this->_ip;
    }

    public function getIpInner(){
        return $this->_ip_inner;
    }

    public function getType(){
        return $this->_type;
    }

    public function getFd(){
        return $this->_fd;
    }

    public function getWgId(){
        return $this->_wg_id;
    }

    public function setWgId($wg_id){
        $this->_wg_id = $wg_id;
        return $this;
    }

    public function getMac(){
        return $this->_mac;
    }

    public function getDevice(){
        return $this->_device;
    }

    public function getWgFd(){
        return $this->_wg_fd;
    }

    public function setWgFd($wg_fd){
        $this->_wg_fd = $wg_fd;
        return $this;
    }

    public function login(){
        return [false,'子类未实现接口'];
    }

    public function getSendData($data){
        return [0,$data];
    }

}