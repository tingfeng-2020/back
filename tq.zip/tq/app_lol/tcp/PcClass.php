<?php

/**
 * User: Hermit
 * Date: 2018/6/22
 * Time: 22:39
 */
class PcClass extends HTcpBaseClass{

    const USER_TYPE_CARD = 1;//卡密用户
    const USER_TYPE_WB = 2;//网吧用户

    protected $_type = DataTypeEnum::TYPE_PC;
    private $_code = '';
    private $_end_time = 0;
    private $_wg_ip_inner = '';
    private $_wg_account_ini = '';
    private $_wg_local_config = '';
    private $_is_send_close_msg = true;
    private $_ver = '';
    private $_wg_mac = '';
    private $_user_type = self::USER_TYPE_CARD;
    private $_uid = 0;//这个全部变成了用户ID
    private $_user_info = null;
    private $_wg_mac_id = 0;
    private $_is_mac = false;
    private $_sign_err = '';
    private $_injec_game = 1;

    public function __construct($ip,$fd,$data = '',$is_need_init = true){
        if($is_need_init){
            parent::__construct($ip,$fd,$data);

            $this->_code = isset($this->_pc_arr['code'])?trim($this->_pc_arr['code']):'';

            if($this->_code != ''){
                list($ok,$uid) = Encrypt::checkSign($this->_code);
                if($ok){
                    $this->_user_info = User::model()->queryByUid($uid);
                    if($this->_user_info){
                        $this->_uid = $this->_user_info['id'];
                    }
                }else{
                    $this->_sign_err = $uid;
                }
            }else{
                $this->_sign_err = '签名丢失';
            }

            $this->_ver = isset($this->_pc_arr['ver'])?$this->_pc_arr['ver']:'';
            $this->_is_mac = isset($this->_pc_arr['is_mac'])?$this->_pc_arr['is_mac']:false;

            $this->_pc_arr = [];
        }
    }

    public function login(){
        if($this->_is_mac){
            list($ver,$msg) = Set::model()->getVerMac();
            if($this->_ver != $ver){
                return [false,$msg];
            }
        }else if($this->_sign_err){
            return [false,$this->_sign_err];
        }

        if(!IpCheck::model()->isOk($this->getIp())){
            return [false,'你的请求太着急，请休息5秒再尝试'];
        }

        if($this->_code == ''){

            $mac = Mac::model()->queryByMac($this->getMac());
            if(!$mac){
                return [false,'[本机MAC：'.$this->getMac().'] MAC不存在 请联系代理'];
            }

            if($mac['end_time'] <= time()){
                return [false,'['.$this->getMac().'] 该MAC已经到期，请续费后打开'];
            }

            $updata_data = [
                'ip' => $this->getIp()
            ];
            if(!$mac['device']){
                $updata_data['device'] = $this->getDevice();
            }else if($mac['device'] != $this->getDevice()){
                return [false,'['.$this->getMac().'] 该MAC与绑定的机器不一致，无法使用'];
            }

            Mac::model()->updateAttr($mac['id'],$updata_data);

            if($mac['status'] != Mac::STATUS_OK){
                return [false,'暂时未授权，等待授权中'];
            }

            $this->_user_type = self::USER_TYPE_WB;
            $this->_wg_mac = $mac['mac'];
            $this->_end_time = $mac['end_time'];
            $wg_id = $mac['wg_id'];
        }else{

            $user = $this->_user_info;
            if(!$user){
                return [false,'用户不存在'];
            }

            $this->_injec_game = $this->_user_info['injec_game'];

            $updata_data = [
                'ip' => $this->getIp()
            ];

            if($user['status'] != User::STATUS_OK){
                return [false,'用户已被封禁无法使用'];
            }

            if($user['end_time'] <= time()){
                return [false,'用户已经到期'];
            }

            if(!$user['device']) {
                $updata_data['device'] = $this->getDevice();
            }else if($user['device'] != $this->getDevice()){
                return [false,'与该用户绑定的机器不一致，无法使用'];
            }

            User::model()->updateAttrById($user['id'],$updata_data);
            if(!$user['wg_mac_id']){
                return [false,'该用户未分配位置，无法使用'];
            }

            $wg_mac = WgMac::model()->queryById($user['wg_mac_id']);
            if(!$wg_mac){
                return [false,'分配的位置已被删除'];
            }

            $this->_wg_mac_id = $wg_mac['id'];
            $this->_wg_mac = $wg_mac['mac'];
            $this->_end_time = $user['end_time'];
            $wg_id = $wg_mac['wg_id'];
        }

        $wg = Wg::model()->queryById($wg_id);
        if(!$wg){
            return [false,'暂时未被分配网关，请联系代理分配'];
        }

        if($wg['status'] == Wg::STATUS_OFFLINE){
            return [false,'网关：'.$wg_id.' 不在线，请联系代理'];
        }

        $this->setWgId($wg['id']);

        $this->_wg_ip_inner = $wg['ip_inner'];
        $this->_wg_account_ini = $wg['account'];
        $this->_wg_local_config = $wg['local_config'];

        return [true,''];
    }

    public function getInjecGame(){
        return $this->_injec_game;
    }

    public function getLoginSendMac(){
        if($this->_is_mac){
            return 'NO';
        }
        return str_replace('-','',$this->_wg_mac);
    }

    public function setCardId($uid){
        $this->_uid = $uid;
        return $this;
    }

    public function getCardId(){
        return $this->_uid;
    }

    public function getUserType(){
        return $this->_user_type;
    }

    public function setUserType($user_type){
        $this->_user_type = $user_type;
        return $this;
    }

    public function getWgMac(){
        return $this->_wg_mac;
    }

    public function setWgMac($wg_mac){
        $this->_wg_mac = $wg_mac;
        return $this;
    }

    public function isSendCloseMsg(){
        return $this->_is_send_close_msg;
    }

    public function setIsSendCloseMsg($is_send){
        $this->_is_send_close_msg = $is_send;
        return $this;
    }

    public function getSendData($data){
        $to_fd = $this->getWgFd();

        $fd_bytes = BytesClass::integerToBytes($this->getFd());
        $fd_str = BytesClass::bytesToStr($fd_bytes);

        $data = $fd_str.$data;

        return [$to_fd,$data];
    }

    public function setEndTime($end_time){
        $this->_end_time = (int)$end_time;
        return $this;
    }

    public function getEndTime(){
        return $this->_end_time;
    }

    public function getWgIpInner(){
        return $this->_wg_ip_inner;
    }

    public function getWgAccountIni(){
        $data = $this->_wg_account_ini;
        $this->_wg_account_ini = '';
        return $data;
    }

    public function getWgLocalConfig(){
        $data = $this->_wg_local_config;
        $this->_wg_local_config = '';
        return $data;
    }

    public function tequanOkUpdate(){
        if($this->_user_type == self::USER_TYPE_CARD){
            $sql = 'update lol_user set near_time = '.time().',all_num = all_num + 1 where id = '.$this->getCardId();
            Card::model()->querySql($sql);
        }else{
            $sql = 'update lol_mac set near_time = '.time().',near_num = near_num + 1,num = num + 1 where mac = "'.$this->getMac().'"';
            Mac::model()->querySql($sql);
        }
    }

    public function updateOnline($status){
        if($this->_user_type == self::USER_TYPE_CARD){
            $updata_data = [
                'status' => $status==WgMac::STATUS_ONLINE?WgMac::STATUS_ONLINE:WgMac::STATUS_OFFLINE,
            ];

            if($status==WgMac::STATUS_ONLINE){
                $updata_data['last_use_time'] = time();
                $updata_data['uid'] = $this->_uid;
            }

            WgMac::model()->updateAttrByMac($this->_wg_mac,$updata_data);
        }
    }

}