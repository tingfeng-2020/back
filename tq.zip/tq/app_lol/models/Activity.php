<?php

class Activity extends HModel {

    public function getSignNum($activity_id){
        $this->setIsDebugSql(TRUE);

        $sql = 'update {{activity}} set sign_num = sign_num + 1 where id = '.$activity_id;
        $this->querySql($sql);

        $res = $this->queryById($activity_id);

        return $res['sign_num'];
    }

    public function queryById($activity_id){
        $condition = 'id = ?';
        $param = [$activity_id];

        return $this->query(array(
            'condition' =>  $condition,
            'param' => $param
        ));
    }

    public function updateById($activity_id,$attr){
        $this->update($attr,[
            'condition' =>  'id = ?',
            'param' => [$activity_id]
        ]);
    }

    public function queryByNowTime(){
        return $this->query(array(
            'condition' =>  's_time < ? and e_time > ?',
            'param' => [time(),time()]
        ));
    }

    public function queryAllByNowTime(){
        return $this->queryAll(array(
            'condition' =>  's_time < ? and e_time > ?',
            'param' => [time(),time()]
        ));
    }

}