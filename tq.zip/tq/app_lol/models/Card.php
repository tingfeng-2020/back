<?php

class Card extends HModel {

    const STATUS_OK = 1;//正常
    const STATUS_USE = 2;//已使用
    const STATUS_CHANGE = 3;//封换
    const STATUS_BANED = 4;//封禁
    const STATUS_DEL = 5;//删除

    const TYPE_SALE = 1;//销售卡密
    const TYPE_GIVE = 2;//赠送卡密

    const PAY_OK = 1;//已结算
    const PAY_NO = 0;//未结算

    const CARD_TYPE_NORMAL = 1;//普通客户
    const CARD_TYPE_VIP = 2;//VIP客户
    const CARD_TYPE_CHAOFAN = 3;//超凡

    public function getList($search,$is_export = false,$is_check = false,$is_jiesuan = FALSE){
        $condition = 't.status >= ? and t.status < ?';
        $params = array(self::STATUS_OK,self::STATUS_CHANGE);

        $join = 'left join {{manage}} as manage on manage.id = t.manage_id';
        $join .= ' left join {{user}} as user on t.uid = user.id';

        if(!Manage::isSuperAdmin() && !AuthManage::isHave(AuthManage::CARD_VIEW_ALL)){
            $condition .= ' and t.manage_id = ?';
            $params[] = HSession::get('uid');
        }

        $card_type_id_str = Manage::getMeInfo('can_view_card_type');
        if($card_type_id_str){
            $condition .= ' and t.card_type_id in ('.$card_type_id_str.')';
        }

        $code = $search->getParams('code',false,'');
        if($code){
            $condition .= ' and t.code like ?';
            $params[] = '%'.$code.'%';
        }

        $cuser = $search->getParams('cuser',false,'');
        if($cuser){
            $condition .= ' and manage.account like ?';
            $params[] = '%'.$cuser.'%';
        }

        $account = $search->getParams('account',false,'');
        if($account){
            $condition .= ' and user.account = ?';
            $params[] = $account;
        }

        $group_str = $search->getParams('group_str',false,'');
        if($group_str){
            $condition .= ' and t.group_str like ?';
            $params[] = '%'.$group_str.'%';
        }

        $s_time = $search->getParams('s_time',false,'');
        if($s_time){
            $condition .= ' and t.time >= ?';
            $params[] = strtotime($s_time);
        }
        $e_time = $search->getParams('e_time',false,'');
        if($e_time){
            $condition .= ' and t.time <= ?';
            $params[] = strtotime($e_time);
        }

        $status = (int)$search->getParams('status',false,0);
        if($status > 0){
            if($status == self::STATUS_USE){//已使用
                $condition .= ' and t.use_time > 0';
            }else{//未使用
                $condition .= ' and t.use_time = 0';
            }
        }

        $status = (int)$search->getParams('status_end',false,0);
        if($status > 0){
            if($status == 1){//未到期
                $condition .= ' and (t.end_time = 0 or t.end_time > ?)';
                $params[] = time();
            }else{//已到期
                $condition .= ' and t.end_time > 0 and t.end_time < ?';
                $params[] = time();
            }
        }

        $pay = (int)$search->getParams('pay',false,0);
        if($pay > 0){
            if($pay == 1){
                $is_pay = self::PAY_OK;
            }else{
                $is_pay = self::PAY_NO;
            }

            $condition .= ' and t.is_pay = '.$is_pay;
        }

        $type = (int)$search->getParams('type',false,0);
        if($type > 0){
            $condition .= ' and t.type = ?';
            $params[] = $type;
        }

        $use_s_time = $search->getParams('use_s_time',false,'');
        if($use_s_time){
            $condition .= ' and t.use_time >= ?';
            $params[] = strtotime($use_s_time);
        }
        $use_e_time = $search->getParams('use_e_time',false,'');
        if($e_time){
            $condition .= ' and t.use_time <= ?';
            $params[] = strtotime($use_e_time);
        }

        $option_arr = array(
            'condition' => $condition,
            'param' => $params,
            'field' => 't.*,manage.account as m_account,user.account as account',
            'order' => 't.id DESC',
            'count_key' => 't.id'
        );

        if($is_jiesuan){
            unset($option_arr['order']);
            unset($option_arr['field']);
            unset($option_arr['count_key']);

            return $this->join($join)->update([
                't.is_pay' => 1
            ],$option_arr);
        }else if($is_export){
            if($is_check){
                return $this->join($join)->count('t.code',$option_arr);
            }else{
                return $this->join($join)->queryAll($option_arr);
            }
        }else{
            list($query_res,$all_num,$now_page,$size) = $this->join($join)->queryAllPage($option_arr);

            foreach($query_res as $key => $data){
                if($data['type'] == self::TYPE_GIVE){
                    $query_res[$key]['group_str'] = '<span style="color: red;">'.$data['group_str'].'</span>';
                }

                $query_res[$key]['num'] = CardType::formatNum($data['num']);
                $query_res[$key]['time']  = $data['time']?date('Y-m-d H:i:s',$data['time']):'';
                if($data['end_time']){
                    $time_str = date('Y-m-d H:i:s',$data['end_time']);
                    if($data['end_time'] < time()){
                        $query_res[$key]['end_time'] = '<span style="color: red;">'.$time_str.'</span>';
                    }else{
                        $query_res[$key]['end_time'] = '<span style="color: green;">'.$time_str.'</span>';
                    }
                }else{
                    $query_res[$key]['end_time'] = '';
                }
                $query_res[$key]['use_time']  = $data['use_time']?date('Y-m-d H:i:s',$data['use_time']):'';
                $query_res[$key]['near_time']  = $data['near_time']?date('Y-m-d H:i:s',$data['near_time']):'';

                if($data['is_pay'] == self::PAY_OK){
                    $query_res[$key]['is_pay'] = '<span style="color: green;">已结算</span>';
                }else{
                    $query_res[$key]['is_pay'] = '<span style="color: red;">未结算</span>';
                }

                if($data['card_type'] == self::CARD_TYPE_VIP){
                    $query_res[$key]['card_type'] = 'VIP尊享';
                }else if($data['card_type'] == self::CARD_TYPE_CHAOFAN){
                    $query_res[$key]['card_type'] = '超凡';
                }else{
                    $query_res[$key]['card_type'] = '普通';
                }
            }

            return array($query_res,$all_num,$now_page);
        }
    }

    public static function batchCreate($type,$group_str,$num,$card_type,&$insert_data = array(),$new_money = 0){
        $uid = HSession::get('uid');

        $money = $card_type['money'];
        if(Manage::isHermitAdmin() && $new_money > 0){
            $money = $new_money;
        }

        for($i = 1; $i <= $num; $i++){
            $insert_data[] = array(
                'code' => self::buildCode($card_type['prefix']),
                'manage_id' => $uid,
                'group_str' => $group_str,
                'type' => $type==self::TYPE_SALE?self::TYPE_SALE:self::TYPE_GIVE,
                'time' => time(),
                'num' => $card_type['num'],
                'money' => $money,
                'status' => 1,
                'can_use_wg' => $card_type['can_use_wg'],
                'card_type' => $card_type['type'],
                'card_type_id' => $card_type['id']
            );
            usleep(1);
        }

        return self::model()->insertAll($insert_data);
    }

    private static function buildCode($prefix){
        $code = md5(date('YmdHis').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8).substr(microtime(), 2, 5));
        return $prefix.strtoupper($code);
    }

    public function queryById($id){
        return $this->query(array(
            'condition' => 'id = ? ',
            'param' => array($id)
        ));
    }

    public function queryByCode($code){
        return $this->query(array(
            'condition' => 'code = ? and status < ?',
            'param' => array($code,Card::STATUS_DEL)
        ));
    }

    public function updateAttr($code,$attr){
        return $this->update($attr,array(
            'condition' => 'code = ?',
            'param' => array($code)
        ));
    }

    public function updateAttrById($id,$attr){
        return $this->update($attr,array(
            'condition' => 'id = ?',
            'param' => array($id)
        ));
    }

    public function removeCard($card){
        if($card['uid']){
            $user = User::model()->queryByUid($card['uid']);
            $end_time = $user['end_time'] - $card['num']*3600;
            User::model()->updateAttrById($user['id'],[
                'end_time' => $end_time
            ]);
            if($end_time <= time()){
                $this->sendDelClientMsg($user['id']);
            }
        }

        $del_res = $this->updateAttrById($card['id'],array(
            'status' => self::STATUS_DEL,
        ));

        return $del_res;
    }

    public function sendDelClientMsg($uid){
        $client = new swoole_client(SWOOLE_SOCK_TCP);
        if (!$client->connect('127.0.0.1', 2019, 0.5)) {
            return false;
        }
        $tcp = new TcpHandler();
        $data = $tcp->getSendData(DataTypeEnum::TYPE_DEL_CLIENT,(string)$uid,false);
        if (!$client->send($data)) {
            return false;
        }
        $client->close();
    }

    public static function getCanUseWgIdArr($card){
        $can_use_wg = isset($card['can_use_wg'])?$card['can_use_wg']:'';
        $wg_id_arr = $can_use_wg?explode(',',$can_use_wg):[];
        return $wg_id_arr;
    }

    public static function cardPay($user,$card,$is_need_fenpei = false){
        if($card['status'] == Card::STATUS_BANED || $card['status'] == Card::STATUS_CHANGE){
            return [false,'卡密已被封禁'];
        }

        if($card['uid']){
            return [false,'卡密已被使用'];
        }

        $updata_data = [
            'ip' => getClientIP(),
            'uid' => $user['id'],
            'status' => Card::STATUS_USE,
            'wg_mac_id' => 0
        ];
        if($card['end_time']){
            if($card['end_time'] <= time()){
                return [false,'该卡密已到期不可以使用'];
            }
            $end_time = $card['end_time'];
        }else{
            if($user['end_time'] > time()){
                $end_time = $user['end_time'] + $card['num']*3600;
            }else{
                $end_time = time() + $card['num']*3600;
            }
            $updata_data['use_time'] = time();
        }

        $res = Card::model()->updateAttrById($card['id'],$updata_data);

        if($res){
            $wg_id_arr = Card::getCanUseWgIdArr($card);
            list($ok,$msg) = User::model()->upsertUserWgMacId($user,$end_time,$card['manage_id'],$wg_id_arr,$is_need_fenpei);
            return [$ok,$msg];
        }

        return [false,'充值失败请稍后尝试'];
    }

    public function getPayNumByUidAndTime($uid,$s_time){
        $condition = 'uid = ? and use_time > ?';
        $param = [$uid,$s_time];

        return $this->count('id',array(
            'condition' =>  $condition,
            'param' => $param
        ));
    }

}