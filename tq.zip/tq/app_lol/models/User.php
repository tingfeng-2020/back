<?php

class User extends HModel {

    const STATUS_DEL = 0;//删除
    const STATUS_OK = 1;//正常
    const STATUS_BANED = 2;//禁用

    const TYPE_NORMAL = 1;//普通客户
    const TYPE_VIP = 2;//VIP客户
    const TYPE_CHAOFAN = 3;//超凡

    public function getList($search,$update_num = 0){
        $join = 'left join {{manage}} as manage on manage.id = t.manage_id';
        $join .= ' left join {{wg_mac}} as wg_mac on wg_mac.id = t.wg_mac_id';

        $condition = 't.status > ?';
        $params = [self::STATUS_DEL];

        if(!AuthManage::isHave(AuthManage::USER_VIEW_ALL)){
            $condition .= ' and t.manage_id = ?';
            $params[] = HSession::get('uid');
        }

        $_uid = HSession::get('uid');
        if($_uid == 6){//卡牌
            $condition .= ' and t.type in (1,2)';//普通和VIP
        }else if($_uid == 11){//超凡
            $condition .= ' and t.type = 3';
        }

        $card_type_id_str = Manage::getMeInfo('can_view_card_type');
        if($card_type_id_str){
            $condition .= ' and t.card_type_id in ('.$card_type_id_str.')';
        }

        $account = $search->getParams('account',false,'');
        if($account){
            $condition .= ' and t.account like ?';
            $params[] = '%'.$account.'%';
        }

        $status = (int)$search->getParams('status',false,0);
        if($status){
            $condition .= ' and t.status = ?';
            $params[] = $status;
        }

        $pay_type = (int)$search->getParams('pay_type',false,0);
        if($pay_type){
            if($pay_type == 1){
                $condition .= ' and t.end_time > 0';
            }else{
                $condition .= ' and t.end_time = 0';
            }
        }

        $type = (int)$search->getParams('type',false,0);
        if($type){
            $condition .= ' and t.type = '.$type;
        }

        $wg_id = (int)$search->getParams('wg_id',false,0);
        if($wg_id){
            $condition .= ' and wg_mac.wg_id = ?';
            $params[] = $wg_id;
        }

        $s_time = $search->getParams('s_time',false,'');
        if($s_time){
            $condition .= ' and t.end_time >= ?';
            $params[] = strtotime($s_time);
        }
        $e_time = $search->getParams('e_time',false,'');
        if($e_time){
            $condition .= ' and t.end_time <= ?';
            $params[] = strtotime($e_time);
        }

        $sort = (int)$search->getParams('sort',false,0);
        $sort_str = 't.id DESC';
        if($sort){
            switch ($sort){
                case 1:
                    $sort_str = 't.end_time ASC,t.id DESC';
                    break;
                case 2:
                    $sort_str = 't.end_time DESC,t.id DESC';
                    break;
                default:;
            }
        }

        if($update_num){
            $this->join($join)->update([],[
                'condition' => $condition,
                'param' => $params
            ],[
                'end_time = end_time + '.(3600*$update_num)
            ]);
        }else{
            list($query_res,$all_num,$now_page,$size) = $this->join($join)->queryAllPage([
                'condition' => $condition,
                'param' => $params,
                'field' => 't.*,manage.account as m_account,wg_mac.wg_id as wg_id,wg_mac.mac as wg_mac_str',
                'order' => $sort_str
            ]);

            foreach($query_res as $key => $data){
                $query_res[$key]['status_str'] = $data['status']==self::STATUS_OK?'正常':'禁用';
                $query_res[$key]['near_time'] = $data['near_time']?date('Y-m-d H:i:s',$data['near_time']):'';
                if($data['end_time']){
                    $time_str = date('Y-m-d H:i:s',$data['end_time']);
                    if($data['end_time'] < time()){
                        $query_res[$key]['end_time'] = '<span style="color: red;">'.$time_str.'</span>';
                    }else{
                        $query_res[$key]['end_time'] = '<span style="color: green;">'.$time_str.'</span>';
                    }
                }else{
                    $query_res[$key]['end_time'] = '';
                }

                if($data['type'] == self::TYPE_VIP){
                    $query_res[$key]['type'] = 'VIP尊享';
                }else if($data['type'] == self::TYPE_CHAOFAN){
                    $query_res[$key]['type'] = '超凡';
                }else{
                    $query_res[$key]['type'] = '普通';
                }
            }

            return array($query_res,$all_num,$now_page);
        }
    }

    public function queryByUid($uid){
        $condition = 'id = ?';
        $param = array($uid);
        return $this->query(array(
            'condition' => $condition,
            'param' => $param
        ));
    }

    public function queryByAccount($account){
        $condition = 'account = ?';
        $param = array($account);

        return $this->query(array(
            'condition' => $condition,
            'param' => $param
        ));
    }

    public function updateAttrById($id,$attr){
        return $this->update($attr,array(
            'condition' => 'id = ?',
            'param' => array($id)
        ));
    }

    public function upsertUserWgMacId($user,$end_time,$manage_id = 0,$wg_id_arr = [],$is_fenpei = false){
        $wg_mac_id = 0;

        if($user['wg_mac_id']){
            //验证是否可以继续使用
            $wg_mac = WgMac::model()->queryById($user['wg_mac_id']);
            if($wg_mac && $wg_mac['uid'] == $user['id']){
                $wg_mac_id = $user['wg_mac_id'];
            }
        }

        $updata_wg_mac_data = [];

        $old_wg_mac_id = $wg_mac_id;
        if(!$wg_mac_id || $is_fenpei){
            list($wg_mac,$msg) = WgMac::model()->getFenpeiMac($user['id'],0,$wg_id_arr);
            if(!$wg_mac){
                return [FALSE,$msg];
            }
            $updata_wg_mac_data['card_id'] = 0;
            $updata_wg_mac_data['uid'] = $user['id'];
            $updata_wg_mac_data['last_use_time'] = time();
            $wg_mac_id = $wg_mac['id'];
        }

        $user_updata = [
            'wg_mac_id' => $wg_mac_id,
            'end_time' => $end_time
        ];
        if($manage_id){
            $user_updata['manage_id'] = $manage_id;
        }

        User::model()->updateAttrById($user['id'],$user_updata);

        if(!empty($updata_wg_mac_data)){
            WgMac::model()->updateAttr($wg_mac_id,$updata_wg_mac_data);
        }

        if($is_fenpei && $old_wg_mac_id){//把旧的MAC改为需要释放
            WgMac::model()->updateAttr($old_wg_mac_id,[
                'uid' => -1
            ]);
        }

        return [TRUE,''];
    }

}