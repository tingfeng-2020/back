<?php

class LucyUser extends HModel {

    public function queryUser($activity_id,$uid,$ip,$device){
        $condition = 'activity_id = ? and (uid = ? or ip = ? or device = ?)';
        $param = [$activity_id,$uid,$ip,$device];

        return $this->query(array(
            'condition' =>  $condition,
            'param' => $param
        ));
    }

    public function countByTimeActivityIdArr($uid,$s_time,$activity_id_arr){
        $condition = 'uid = ? and activity_id in ('.implode(',',$activity_id_arr).') and time > ?';
        $param = [$uid,$s_time];

        return $this->count('id',array(
            'condition' =>  $condition,
            'param' => $param
        ));
    }

}