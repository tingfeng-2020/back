<?php

class Money extends HModel {

}