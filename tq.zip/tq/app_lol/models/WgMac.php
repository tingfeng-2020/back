<?php

class WgMac extends HModel {

    const STATUS_ONLINE = 1;//在线
    const STATUS_OFFLINE = 2;//离线

    const TYPE_WB_MAC = 1;//网吧MAC
    const TYPE_FENPEI_MAC = 2;//分配MAC

    public function getList($search,$is_export = false){
        $join = 'left join {{card}} as card on card.id = t.card_id';
        $join .= ' left join {{user}} as user on user.id = t.uid';

        $condition = '';
        $params = array();

        $id = (int)$search->getParams('id',false,'');
        if($id){
            if($condition != ''){
                $condition .= ' and ';
            }

            $condition .= 't.id = ?';
            $params[] = $id;
        }

        $mac = $search->getParams('mac',false,'');
        if($mac){
            if($condition != ''){
                $condition .= ' and ';
            }

            $condition .= 't.mac like ?';
            $params[] = '%'.$mac.'%';
        }

        $wg_id = (int)$search->getParams('wg_id',false,0);
        if($wg_id){
            if($condition != ''){
                $condition .= ' and ';
            }
        	$condition .= 't.wg_id = ?';
        	$params[] = $wg_id;
        }

        $account = $search->getParams('account',false,'');
        if($account){
            if($condition != ''){
                $condition .= ' and ';
            }

            $condition .= 'user.account like ?';
            $params[] = '%'.$account.'%';
        }

        $status = (int)$search->getParams('status',false,0);
        if($status){
            if($condition != ''){
                $condition .= ' and ';
            }
        	$condition .= 't.status = ?';
        	$params[] = $status;
        }

        $type = (int)$search->getParams('type',false,0);
        if($type){
            if($condition != ''){
                $condition .= ' and ';
            }
            if($type == 1){//已使用
                $condition .= '(t.card_id > 0 or t.uid > 0)';
            }else{//未使用
                $condition .= 't.card_id = 0 and t.uid = 0';
            }
        }

        $unbind = (int)$search->getParams('unbind',false,0);
        if($unbind == 1){
            if($condition != ''){
                $condition .= ' and ';
            }
            $temp = [
                't.card_id > 0 and ((card.status <= '.Card::STATUS_USE.' and card.end_time < '.time().') or card.status > '.Card::STATUS_USE.')',
                't.uid > 0 and ((user.status != '.User::STATUS_DEL.' and user.end_time < '.time().') or user.status = '.User::STATUS_DEL.')',
                't.uid = -1'
            ];
            $condition .= '('.implode(' or ',$temp).')';
        }

        $sort = (int)$search->getParams('sort',false,0);
        $sort_str = 't.id DESC';
        if($sort){
            if($condition != ''){
                $condition .= ' and ';
            }
            $condition .= 't.uid > 0';

            switch ($sort){
                case 1:
                    $sort_str = 'user.end_time ASC,t.id DESC';
                    break;
                case 2:
                    $sort_str = 'user.end_time DESC,t.id DESC';
                    break;
                default:;
            }
        }

        if($is_export){
            return $this->join($join)->queryAll([
                'condition' => $condition,
                'param' => $params,
                'field' => 't.*,card.code code',
                'order' => $sort_str
            ]);
        }

        list($query_res,$all_num,$now_page,$size) = $this->join($join)->queryAllPage(array(
            'condition' => $condition,
            'param' => $params,
            'field' => 't.*,card.code code,card.status card_status,card.end_time end_time,user.account as account,user.end_time as u_end_time,user.status as u_status',
            'order' => $sort_str
        ));

        $time = time();
        foreach($query_res as $key => $data){
            $query_res[$key]['status'] = $data['status']==self::STATUS_ONLINE?'在线':'离线';
            $query_res[$key]['u_end_time_str'] = $data['u_end_time']?date('Y-m-d H:i:s',$data['u_end_time']):'';

            $query_res[$key]['color_class'] = '';
            if($data['card_id'] > 0){
                if($data['card_status'] <= Card::STATUS_USE && $data['end_time'] < $time){
                    $query_res[$key]['color_class'] = 'red';
                }else if($data['card_status'] > Card::STATUS_USE){
                    $query_res[$key]['color_class'] = 'red';
                }
            }
            if($data['uid'] > 0){
                if($data['u_status'] != User::STATUS_DEL && $data['u_end_time'] < $time){
                    $query_res[$key]['color_class'] = 'red';
                }else if($data['u_status'] == User::STATUS_DEL){
                    $query_res[$key]['color_class'] = 'red';
                }
            }
            if($data['uid'] == -1){
                $query_res[$key]['color_class'] = 'red';
            }
        }

        return array($query_res,$all_num,$now_page);
    }

    public function queryByMac($mac){
        $res = $this->query(array(
            'condition' =>  'mac = ?',
            'param' => array($mac)
        ));
        return $res;
    }

    public function queryById($id = 0){
        if($id <= 0){
            return null;
        }

        $wg = $this->query(array(
            'condition' =>  'id = ?',
            'param' => array($id)
        ));
        return $wg;
    }

    public function updateAttr($id,$attr){
        return $this->update($attr,array(
            'condition' => 'id = ?',
            'param' => array($id)
        ));
    }

    public function updateAttrByMac($mac,$attr){
        return $this->update($attr,array(
            'condition' => 'mac = ?',
            'param' => array($mac)
        ));
    }

    public function getOneOfflineMac($wg_mac_id = 0){
        $join = 'left join {{wg}} as wg on wg.id = t.wg_id';

        $mac = $this->join($join)->query([
            'condition' => 't.id = ? and t.status = ? and wg.status = ?',
            'param' => array($wg_mac_id,self::STATUS_OFFLINE,Wg::STATUS_ONLINE),
            'field' => 't.*',
        ]);
        if(!$mac){
            $mac = $this->join($join)->query([
                'condition' => 't.status = ? and wg.status = ?',
                'param' => array(self::STATUS_OFFLINE,Wg::STATUS_ONLINE),
                'order' => 't.last_use_time ASC,t.id DESC',
                'field' => 't.*',
            ]);
        }

        return [$mac,'抱歉暂时没有可用端口，请等待一会儿，再尝试使用'];
    }

    public function getFenpeiMac($uid,$wg_mac_id = 0,$wg_id_arr = []){
        if($wg_mac_id){
            $mac = $this->query([
                'condition' => 'id = ?',
                'param' => array($wg_mac_id),
                'field' => '*',
            ]);
        }else{
            $join = 'left join {{wg}} as wg on wg.id = t.wg_id';

            $condition = 't.card_id = 0 and t.status = ? and wg.status = ? and t.uid = 0';
            if(!empty($wg_id_arr)){
                $condition .= ' and t.wg_id in ('.implode(',',$wg_id_arr).')';
            }

            //标记一个
            $res = $this->join($join)->query([
                'condition' => $condition,
                'param' => [self::STATUS_OFFLINE,Wg::STATUS_ONLINE],
                'order' => 't.last_use_time ASC,t.id DESC',
                'field' => 't.id'
            ]);

            if($res){

                $this->join('')->update([
                    'uid' => $uid
                ],[
                    'condition' => 'id = ? and t.uid = 0 and t.card_id = 0',
                    'param' => [$res['id']]
                ]);

                $mac = $this->query([
                    'condition' => 'uid = ?',
                    'param' => [$uid],
                    'field' => '*',
                ]);
            }else{
                $mac = null;
            }
        }

        return [$mac,'暂时没有可用位置，请等待'];
    }

    public function updateALLOffline(){
        $this->update(array(
            'status' => self::STATUS_OFFLINE
        ));
    }

    public function getFenpeiCanUseNum(){
        $card_type_arr = CardType::model()->getShowNumArr();

        $list = [];
        foreach ($card_type_arr as $card_type){
            $can_use_wg = isset($card_type['can_use_wg'])?$card_type['can_use_wg']:'';
            $wg_id_arr = $can_use_wg?explode(',',$can_use_wg):[];

            $condition = 't.card_id = 0 and t.status = ? and wg.status = ? and t.uid = 0';
            if(!empty($wg_id_arr)){
                $condition .= ' and wg.id in ('.implode(',',$wg_id_arr).')';
            }

            $join = 'left join {{wg}} as wg on wg.id = t.wg_id';
            $res = $this->join($join)->query([
                'condition' => $condition,
                'param' => [self::STATUS_OFFLINE,Wg::STATUS_ONLINE],
                'order' => 't.last_use_time ASC,t.id DESC',
                'field' => 'count(distinct t.id) as num',
            ]);

            $num = isset($res['num'])?(int)$res['num']:0;

            $list[] = '剩余 '.$card_type['name'].' 位置：'.$num.'个';
        }

        return $list;
    }

}