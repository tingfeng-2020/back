<?php

class Manage extends HModel {

    const TYPE_DAILI = 1;//代理
    const TYPE_MANAGE = 2;//管理员
    const TYPE_SUPER_ADMIN = 3;//超管

    const STATUS_FORBID = 0;//禁止
    const STATUS_OK = 1;//正常
    const STATUS_DEL = 2;//删除

    private static $_me = null;

    /**
     * 验证账号密码
     * @param string $account
     * @param string $pwd
     * @return array
     */
    public function verifyUserInfo($account,$pwd){
        $user = $this->query(array(
            'condition' => 'account = ?',
            'param' => array($account)
        ));
        if(!$user){
            return array(false,'账号不存在');
        }

        if($user['pwd'] != $pwd){
            return array(false,'密码不正确');
        }

        if($user['status'] == self::STATUS_FORBID){
            return array(false,'已被禁用');
        }

        if($user['status'] == self::STATUS_DEL){
            return array(false,'已被删除');
        }

        HSession::login(['uid' => $user['id']]);

        return array(true,'');
    }

    public static function getMeInfo($key = 'account'){
        if(self::$_me === null){
            self::$_me = self::model()->query(array(
                'condition' => 'id = ? and status = ?',
                'param' => array(HSession::get('uid'),self::STATUS_OK)
            ));
        }
        return isset(self::$_me[$key])?self::$_me[$key]:'';
    }

    public function updateAttrById($id,$attr){
        return $this->update($attr,array(
            'condition' => 'id = ?',
            'param' => array($id)
        ));
    }

    public function getList($search){
        $uid = HSession::get('uid');

        $condition = 'type < 3';
        $params = array();

        if(!Manage::isSuperAdmin()){
            $condition .= ' and pid = ?';
            $params[] = $uid;
        }

        $acount = $search->getParams('acount',false,'');
        if($acount){
            $condition .= ' and account like ?';
            $params[] = '%'.$acount.'%';
        }

        $status = (int)$search->getParams('status',false,0);
        if($status > 0){
            $condition .= ' and status = ?';
            $params[] = $status - 1;
        }

        $condition .= ' and status < ?';
        $params[] = self::STATUS_DEL;

        list($query_res,$all_num,$now_page,$size) = $this->queryAllPage(array(
            'condition' => $condition,
            'param' => $params,
            'order' => 'id ASC',
            'limit' => 15,
            'count_key' => 'id'
        ));

        $sum_res = $this->query(array(
            'condition' => $condition,
            'param' => $params,
            'field' => 'sum(money) as all_money'
        ));

        foreach($query_res as $key => $data){
            $card_num = Card::model()->count('code',array(
                'condition' => 'manage_id = ? and use_time = 0 and status = 1',
                'param' => array($data['id']),
            ));

            $query_res[$key]['card_num'] = $card_num.'张';
            $query_res[$key]['type'] = $data['type']==self::TYPE_DAILI?'代理':'管理';
            $query_res[$key]['money'] = $data['money'].'元';
            $query_res[$key]['status'] = self::formatStatus($data['status']);
        }

        return array($query_res,$all_num,$now_page,$sum_res['all_money']);
    }

    public function queryById($id = 0){
        if($id <= 0){
            return null;
        }

        $data = $this->query(array(
            'condition' =>  'id = ?',
            'param' => array($id)
        ));
        return $data;
    }

    public static function formatStatus($status){
        $arr = array(
            self::STATUS_FORBID => '禁止',
            self::STATUS_OK => '正常',
            self::STATUS_DEL => '删除'
        );
        return isset($arr[$status])?$arr[$status]:'未知';
    }

    public static function saveData($manage,$attr){
        if($manage){
            self::model()->update($attr,array(
                'condition' => 'id = ?',
                'param' => array($manage['id'])
            ));
            $id = $manage['id'];
        }else{
            $attr['pid'] = HSession::get('uid');
            $id = self::model()->insert($attr);
        }

        return $id;
    }

    public static function isHermitAdmin(){
        return self::getMeInfo('account')=='hermit';
    }

    public static function isSuperAdmin(){
        return self::getMeInfo('type')==self::TYPE_SUPER_ADMIN;
    }

    public static function isManage(){
        if(self::isSuperAdmin()){
            return true;
        }
        return self::getMeInfo('type')==self::TYPE_MANAGE;
    }

    public function queryByAccount($account,$id = 0){
        $condition = 'account = ?';
        $param = array($account);
        if($id > 0){
            $condition .= ' and id != ?';
            $param[] = $id;
        }

        return $this->query(array(
            'condition' => $condition,
            'param' => $param
        ));
    }

    public static function checkCardTypeId($card_type_id){
        $card_type_id_str = self::getMeInfo('can_view_card_type');
        $card_type_id_arr = $card_type_id_str?explode(',',$card_type_id_str):[];
        if(!empty($card_type_id_arr) && !in_array($card_type_id,$card_type_id_arr)){
            return false;
        }
        return true;
    }

}