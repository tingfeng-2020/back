<?php

class Set extends HModel {

    const VER_CARD = 'card_ver';//卡密版本号
    const VER_MAC = 'mac_ver';//MAC本号
    const VER_USE_MAC = 'use_mac';//是否使用MAC
    const CAN_REG = 'can_reg';//是否可以注册
    const CAN_PAY = 'can_pay';//是否可以充值
    const NEIBU_VER = 'neibu_ver';//内部
    const HUOJIAN_VER = 'huojian_ver';//火箭
    const HUOJIAN_QQ_QUN = 'huojian_qq_qun';//火箭QQ群
    const QD_QQ_QUN = 'qd_qq_qun';//渠道QQ群

    public function getVerCard(){
        $res = $this->query(array(
            'condition' => 'type = ?',
            'param' => array(self::VER_CARD)
        ));
        if($res){
            return [$res['data'],$res['msg']];
        }
        return ['1.0',''];
    }

    public function getVerMac(){
        $res = $this->query(array(
            'condition' => 'type = ?',
            'param' => array(self::VER_MAC)
        ));
        if($res){
            return [$res['data'],$res['msg']];
        }
        return ['1.0',''];
    }

    private $_is_use_mac = null;

    public function isUseMac(){
        if($this->_is_use_mac === null){
            $this->_is_use_mac = false;

            $res = $this->query(array(
                'condition' => 'type = ?',
                'param' => array(self::VER_USE_MAC)
            ));
            if($res){
                $this->_is_use_mac = $res['data']==1?true:false;
            }
        }
        return $this->_is_use_mac;
    }

    public function isCanReg(){
        $res = $this->query(array(
            'condition' => 'type = ?',
            'param' => array(self::CAN_REG)
        ));
        return $res?$res['data']:1;
    }

    public function isCanPay(){
        $res = $this->query(array(
            'condition' => 'type = ?',
            'param' => array(self::CAN_PAY)
        ));
        return $res?$res['data']:1;
    }

    public function updateByType($type,$attr){
        return $this->update($attr,array(
            'condition' => 'type = ?',
            'param' => array($type)
        ));
    }

    public function getNeibuInfo(){
        $res = $this->query(array(
            'condition' => 'type = ?',
            'param' => array(self::NEIBU_VER)
        ));
        if($res){
            return [$res['data'],$res['msg']];
        }
        return ['1.0',''];
    }

    public function getHuojianInfo(){
        $res = $this->query(array(
            'condition' => 'type = ?',
            'param' => array(self::HUOJIAN_VER)
        ));
        if($res){
            return [$res['data'],$res['msg']];
        }
        return ['1.0',''];
    }

    public function getHuojianQun(){
        $res = $this->query(array(
            'condition' => 'type = ?',
            'param' => array(self::HUOJIAN_QQ_QUN)
        ));
        if($res){
            return $res['data'];
        }
        return '';
    }

    public function getQudaoQun(){
        $res = $this->query(array(
            'condition' => 'type = ?',
            'param' => array(self::QD_QQ_QUN)
        ));
        if($res){
            return $res['data'];
        }
        return '';
    }

}