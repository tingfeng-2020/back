<?php

class Task extends HModel {

    const STATUS_WAIT = 0;//等待处理
    const STATUS_OK = 1;//已经处理

    public function getList(){
        list($query_res,$all_num,$now_page,$size) = $this->queryAllPage([
            'order' => 'id DESC'
        ]);

        foreach($query_res as $key => $data){
            $query_res[$key]['time']  = $data['time']?date('Y-m-d H:i:s',$data['time']):'';
            $query_res[$key]['status']  = $data['status']==self::STATUS_OK?'已执行':'等待执行';
        }

        return array($query_res,$all_num,$now_page);
    }

    public function getByWgId($wg_id){
        return $this->query([
            'condition' => 'wg_id = ? and status = ?',
            'param' => [$wg_id,self::STATUS_WAIT],
            'order' => 'id DESC'
        ]);
    }

    public function updateAllDeal($wg_id){
        $this->update([
            'status' => self::STATUS_OK
        ],[
            'condition' => 'wg_id = ? and status = ?',
            'param' => [$wg_id,self::STATUS_WAIT],
        ]);
    }

}