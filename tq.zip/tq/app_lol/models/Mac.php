<?php

class Mac extends HModel {

    const STATUS_OK = 1;//已授权
    const STATUS_NO = 0;//未授权

    public function getList($search){
        $join = 'left join {{wg}} as wg on wg.id = t.wg_id';

        $condition = '';
        $params = array();

        $group_str = $search->getParams('group_str',false,'');
        if($group_str){
            if($condition != ''){
                $condition .= ' and ';
            }
            $condition .= 't.group_str like ?';
            $params[] = '%'.$group_str.'%';
        }

        $mac = $search->getParams('mac',false,'');
        if($mac){
            if($condition != ''){
                $condition .= ' and ';
            }

            $condition .= 't.mac like ?';
            $params[] = '%'.$mac.'%';
        }

        $ip = $search->getParams('ip',false,'');
        if($ip){
            if($condition != ''){
                $condition .= ' and ';
            }

            $condition .= 't.ip like ?';
            $params[] = '%'.$ip.'%';
        }

        $type = (int)$search->getParams('type',false,0);
        if($type == 1){
            if($condition != ''){
                $condition .= ' and ';
            }
            $condition .= 't.end_time > ?';
            $params[] = time();
        }else if($type == 2){
            if($condition != ''){
                $condition .= ' and ';
            }
            $condition .= 't.end_time <= ?';
            $params[] = time();
        }

        $wg_id = (int)$search->getParams('wg_id',false,0);
        if($wg_id){
            if($condition != ''){
                $condition .= ' and ';
            }
        	$condition .= 't.wg_id = ?';
        	$params[] = $wg_id;
        }

        $sort = (int)$search->getParams('sort',false,0);
        $order_str = 't.id DESC';
        if($sort == 1){
            $order_str = 't.end_time ASC,t.id ASC';
        }

        list($query_res,$all_num,$now_page,$size) = $this->join($join)->queryAllPage(array(
            'condition' => $condition,
            'param' => $params,
            'field' => 't.*',
            'order' => $order_str
        ));

        foreach ($query_res as $key => $data){
            $query_res[$key]['end_time'] = $data['end_time']?date('Y-m-d H:i:s',$data['end_time']):'';
            $query_res[$key]['status'] = $data['status']==self::STATUS_OK?'已授权':'未授权';
            $query_res[$key]['near_time'] = $data['near_time']?date('Y-m-d H:i:s',$data['near_time']):'';
            $query_res[$key]['num'] = $data['num'].'次';
        }

        return array($query_res,$all_num,$now_page);
    }

    public function queryById($id = 0){
        if($id <= 0){
            return null;
        }

        $mac = $this->query(array(
            'condition' =>  'id = ?',
            'param' => array($id)
        ));
        return $mac;
    }

    public function queryByMac($mac){
        $res = $this->query(array(
            'condition' =>  'mac = ?',
            'param' => array($mac)
        ));
        return $res;
    }

    public function getUseMacNum(){
        $user_num = User::model()->join('')->count('id',array(
            'condition' =>  'e_time > ? and status = ?',
            'param' => array(time(),User::STATUS_OK)
        ));

        $mac_num = $this->join('')->count('id');

        return (int)$user_num + (int)$mac_num;
    }

    public static function getCanUseMacnum(){
        $mac_num = Wg::model()->getMacnum();
        if($mac_num <= 0){
            return 0;
        }

        $use_num = self::model()->getUseMacNum();
        $num = $mac_num - $use_num;
        return $num?$num:0;
    }

    public static function getTips(){
        $mac_num = Wg::model()->getMacnum();
        if($mac_num <= 0){
            return '很遗憾，服务器未添加位置';
        }

        $use_num = self::model()->getUseMacNum();
        $num = $mac_num - $use_num;
        if($num > 0){
            return '剩余'.$num.'个位置';
        }

        return '所有位置已经被抢光';
    }

    public static function checkedMac(&$mac){
        $arr = explode(' ',$mac);
        if(count($arr) < 1){
            return false;
        }
        $mac = $arr[0];

        $arr = explode('-',$mac);
        if(count($arr) != 6){
            return false;
        }
        return true;
    }

    public static function saveData($id,$attr){
        $mac = self::model()->queryById($id);
        if($mac){
            return self::model()->update($attr,array(
                'condition' => 'id = ?',
                'param' => array($mac['id'])
            ));
        }else{
            return self::model()->insert($attr);
        }
    }

    public function getWgmacinfo($wg_id){
        $mac = '';
        $remark = '';
        $del_mac = '';

        $e_time = time() + 5*60;

        $add_mac = $this->query(array(
            'condition' => 'wg_id = ? and e_time >= ? and status = ?',
            'param' => [$wg_id,$e_time,self::STATUS_NO],
            'order' => 'id ASC'
        ));

        $ok_mac_num = 31;

        if($add_mac){
            $mac = $add_mac['mac'];
            $remark = 'h_'.$add_mac['id'];
        }else{
            $ok_mac_num = $this->count('id',array(
                'condition' => 'wg_id = ? and status = ?',
                'param' => [$wg_id,$e_time,self::STATUS_OK]
            ));
        }

        if($ok_mac_num > 30){
            $res = $this->query(array(
                'condition' => 'wg_id = ? and e_time <= ? and status = ?',
                'param' => [$wg_id,time(),self::STATUS_OK],
                'order' => 'id ASC'
            ));
            $del_mac = $res?$res['mac']:'';
        }

        return [$mac,$remark,$del_mac];
    }

    public function updateStatus($wg_id,$mac,$status){
        $status = $status==self::STATUS_OK?self::STATUS_OK:self::STATUS_NO;

        $this->update(['status' => $status],array(
            'condition' => 'wg_id = ? and mac = ?',
            'param' => [$wg_id,$mac],
        ));
    }

    public function updateAttr($id,$attr){
        $this->update($attr,array(
            'condition' => 'id = ?',
            'param' => [$id],
        ));
    }

}