<?php

class IpCheck extends HModel {

    private function queryByIp($ip){
        return $this->query(array(
            'condition' =>  'ip = ?',
            'param' => array($ip)
        ));
    }

    public function isOk($ip){
        $ip_check = $this->queryByIp($ip);
        if($ip_check){
            if((time() - 5) <= $ip_check['last_time']){
                return false;
            }
            $this->update(['last_time' => time()],[
                'condition' => 'ip = ?',
                'param' => [$ip]
            ]);
        }else{
            $this->insert(['ip' => $ip,'last_time' => time()]);
        }

        return true;
    }

}