<?php

class ManagePrice extends HModel {

    public function getTypeArr(){
        $query_res = $this->queryAll(array(
            'condition' => 'manage_id = ?',
            'param' => array(HSession::get('uid')),
        ));

        $type_arr = array();
        foreach($query_res as $data){
            $type_arr[$data['type_id']] = $data['money'];
        }
        return $type_arr;
    }

    public function queryByTpeId($type_id){
        return $this->query(array(
            'condition' => 'manage_id = ? and type_id = ?',
            'param' => array(HSession::get('uid'),$type_id),
        ));
    }


}