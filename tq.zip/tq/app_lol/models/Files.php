<?php

class Files extends HModel {

    public function getList($nb){
        $condition = '((s_time = 0 and e_time = 0) or (s_time < ? and e_time > ?)) and type = ?';
        $type = $nb?'2':'1';

        $query_res = $this->queryAll(array(
            'condition' => $condition,
            'param' => [time(),time(),$type],
        ));

        $list = [];
        foreach($query_res as $data){
            $list[] = [
                'name' => $data['name'],
                'path' => $data['path'],
                'url' => $data['url'],
                'ver' =>  $data['ver'],
                'need_kill' => $data['need_kill']
            ];
        }

        return $list;
    }

}