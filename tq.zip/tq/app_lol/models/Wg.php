<?php

class Wg extends HModel {

    const STATUS_OFFLINE = 0;//离线
    const STATUS_ONLINE = 1;//在线

    const TYPE_OK = 1;//授权
    const TYPE_ERR = 0;//未授权

    public function getList(){
        $query_res = $this->queryAll(array(
            'order' => 'id ASC'
        ));

        foreach($query_res as $key => $data){
            $query_res[$key]['type']  = $data['type']?'已授权':'未授权';
            $query_res[$key]['status']  = $data['status']?'在线':'离线';
            $query_res[$key]['time']  = $data['time']?date('Y-m-d H:i:s',$data['time']):'';
            $query_res[$key]['off_time']  = $data['off_time']?date('Y-m-d H:i:s',$data['off_time']):'';
        }

        return $query_res;
    }

    private static $_wg_id_name_arr = null;
    public static function getWgIdNameArr($default = []){
        if(self::$_wg_id_name_arr === null){
            $query_res = self::model()->queryAll(array(
                'order' => 'id ASC'
            ));

            $arr = [];
            foreach($query_res as $data){
                $arr[$data['id']] = '网关'.$data['id'];
            }
            self::$_wg_id_name_arr = $arr;
        }

        foreach (self::$_wg_id_name_arr as $wg_id => $name){
            $default[$wg_id] = $name;
        }
        return $default;
    }

    public function queryById($id = 0){
        if($id <= 0){
            return null;
        }

        $wg = $this->query(array(
            'condition' =>  'id = ?',
            'param' => array($id)
        ));
        return $wg;
    }

    public static function saveData($id,$attr){
        $wg = self::model()->queryById($id);
        if($wg){
            self::model()->update($attr,array(
                'condition' => 'id = ?',
                'param' => array($wg['id'])
            ));
        }else{
            self::model()->insert($attr);
        }
    }

    public function updateALLOffline(){
        $this->update(array('status' => self::STATUS_OFFLINE));
    }

    public function upsertData($mac,$ip,$ip_inner,$status){
        $wg = $this->query(array(
            'condition' =>  'mac = ?',
            'param' => array($mac)
        ));
        if($wg){
            $update_data = [
                'ip' => $ip,
                'status' => $status
            ];
            if($wg['ip_inner'] == ''){
                $update_data['ip_inner'] = $ip_inner;
            }

            if($status == self::STATUS_ONLINE){
                $update_data['time'] = time();
                $update_data['off_time'] = 0;
            }else{
                $update_data['time'] = 0;
                $update_data['off_time'] = time();

                //如果是离线 且 是授权成功的网关 则添加掉线重启任务
                if($wg['type'] == Wg::TYPE_OK){
                    Task::model()->insert([
                        'wg_id' => $wg['id'],
                        'status' => Task::STATUS_WAIT,
                        'time' => time()
                    ]);
                }
            }

            $this->update($update_data,array(
                'condition' => 'id = ?',
                'param' => array($wg['id'])
            ));
            $wg_id = $wg['id'];
            $type = $wg['type'];
        }else{
            $wg_id = $this->insert(array(
                'mac' => $mac,
                'ip' => $ip,
                'ip_inner' => $ip_inner,
                'type' => self::TYPE_ERR,
                'status' => self::STATUS_OFFLINE
            ));
            $type = self::TYPE_ERR;
        }

        return array($wg_id,$type);
    }

    public function getMacnum(){
        $wg = $this->query(array(
            'field' => 'sum(mac_num) as mac_num'
        ));
        return $wg['mac_num']?$wg['mac_num']:0;
    }

    public function queryByWgkey($wg_key){
        return $this->query(array(
            'condition' => 'wg_key = ?',
            'param' => [$wg_key],
            'field' => 'id'
        ));
    }

    public function updateMacNum($id){
        $num1 = Mac::model()->count('id',[
            'condition' => 'wg_id = ?',
            'param' => array($id)
        ]);

        $num2 = WgMac::model()->count('id',[
            'condition' => 'wg_id = ?',
            'param' => array($id)
        ]);

        $this->update([
            'mac_num' => $num1 + $num2
        ],[
            'condition' => 'id = ?',
            'param' => array($id)
        ]);
    }

}