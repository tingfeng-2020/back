<?php

class CardType extends HModel {

    const TYPE_NUM = 1;//次数
    const TYPE_TIME = 2;//时间

    const TYPE_NORMAL = 1;//普通客户
    const TYPE_VIP = 2;//VIP客户
    const TYPE_CHAOFAN = 3;//超凡

    public function getList(){
        $query_res = $this->queryAll(array(
            'order' => 'id ASC'
        ));

        foreach($query_res as $key => $data){
            $query_res[$key]['num'] = self::formatNum($data['num']);
            $query_res[$key]['money']  = $data['money'].'元';
        }

        return $query_res;
    }

    public static function formatType($type){
        if($type == self::TYPE_CHAOFAN){
            return '超凡';
        }else if($type == self::TYPE_VIP){
            return 'VIP尊享';
        }
        return '普通';
    }

    public function queryById($id = 0){
        if($id <= 0){
            return null;
        }

        $condition = 'id = ?';
        $param = [$id];

        $card_type = $this->query(array(
            'condition' =>  $condition,
            'param' => $param
        ));

        if($card_type){
            $manage_type = ManagePrice::model()->queryByTpeId($card_type['id']);
            if($manage_type){
                $card_type['money'] = $manage_type['money'];
            }
        }

        return $card_type;
    }

    public static function saveData($id,$attr){
        $card_type = self::model()->queryById($id);
        if($card_type){
            self::model()->update($attr,array(
                'condition' => 'id = ?',
                'param' => array($card_type['id'])
            ));
        }else{
            self::model()->insert($attr);
        }
    }

    public static function formatNum($num){
        return $num.'小时';
    }

    public function queryByName($name,$id = 0){
        $condition = 'name = ?';
        $param = array($name);
        if($id > 0){
            $condition .= ' and id != ?';
            $param[] = $id;
        }

        return $this->query(array(
            'condition' => $condition,
            'param' => $param
        ));
    }

    public static function getTypeArr(){
        $card_type_id_str = Manage::getMeInfo('can_view_card_type');

        if($card_type_id_str){
            $query_res = self::model()->queryAll(array(
                'condition' => 'id in ('.$card_type_id_str.')',
                'order' => 'num ASC'
            ));
        }else{
            $query_res = self::model()->queryAll(array(
                'order' => 'num ASC'
            ));
        }

        $manage_type_arr = ManagePrice::model()->getTypeArr();

        $type_arr = array();
        foreach($query_res as $data){
            if(isset($manage_type_arr[$data['id']])){
                $money = $manage_type_arr[$data['id']];
            }else{
                $money = $data['money'];
            }

            $type_arr[$data['id']] = array(
                'name' => $data['name'],
                'num' => self::formatNum($data['num']),
                'money' => $money.'元'
            );
        }
        return $type_arr;
    }

    public function getShowNumArr(){
        return $this->queryAll(array(
            'condition' => 'is_show = 1',
            'order' => 'id ASC'
        ));
    }

}