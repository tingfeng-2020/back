<?php

class HtmlBuilder {

    public static function buildFormStart($url){
        echo '<form action="'.$url.'" class="search_form">';
    }

    public static function buildFormEnd(){
        $html = '<a href="javascript:;" class="btn btn_search">搜索</a>';

        $page = isset($_GET['page'])?$_GET['page']:1;

        $html .= '<input id="page" type="hidden" name="page" value="'.$page.'">';

        $html .= '</form>';

        echo $html;
    }

    public static function buildSearchForm($url,$search_arr){
        self::buildFormStart($url);

        self::buildInputSearch($search_arr);

        self::buildFormEnd();
    }

    public static function buildInputSearch($search_arr){
        $html = '';
        foreach($search_arr as $key => $name){
            $html .= '<span class="search">';
            $html .=    '<label>'.$name.'：</label>';

            $value = isset($_GET[$key])?$_GET[$key]:'';

            $html .=    '<input name="'.$key.'" value="'.$value.'">';
            $html .= '</span>';
        }
        echo $html;
    }

    public static function buildSelectSearch($name,$name_postkey,$data_arr,$data = ''){
        echo '<span class="search">';

        echo '<label>'.$name.'：</label>';

        self::buildSelect($name_postkey,$data_arr,$data);

        echo '</span>';
    }

    public static function buildSelect($name,$data_arr,$data = '',$data_key = ''){
        $html = '<select id="'.$name.'" name="'.$name.'">';

        foreach($data_arr as $key => $val){
            if($data_key != ''){
                $val = $val[$data_key];
            }
            $select = $key==$data?'selected="selected"':'';
            $html .= '<option '.$select.' value="'.$key.'">'.$val.'</option>';
        }
        $html .= '</select>';

        echo $html;
    }

    public static function buildPage($now_page,$max_num,$size = 15){
        $html = '<div class="page_box">';

        $max_page = ceil($max_num/$size);
        //是否有上一页
        if($now_page > 1){
            $html .= ' <a href="javascript:;" data-page="'.($now_page - 1).'" class="btn btn_page">上一页</a>';
        }
        //是否有小页码
        if($max_page > 1){
            if($now_page - 1 > 0){
                $html .= ' <a href="javascript:;" data-page="'.($now_page - 1).'" class="btn btn_page">'.($now_page - 1).'</a>';
            }
            $html .= ' <a href="javascript:;" data-page="'.$now_page.'" class="btn btn_page active">'.$now_page.'</a>';
            if($now_page + 1 <= $max_page){
                $html .= ' <a href="javascript:;" data-page="'.($now_page + 1).'" class="btn btn_page">'.($now_page + 1).'</a>';
                $html .= ' <a href="javascript:;" data-page="'.($now_page + 1).'" class="btn btn_page">下一页</a>';
            }
        }

        $html .= '<span style="margin-left: 10px;">共计：'.$max_num.'</span>';

        $html .= '</div>';

        echo $html;
    }

    public static function buildStartAndEndSearch($name = '时间',$s_val = '',$e_val = '',$s_name = 's_time',$e_name = 'e_time'){
        $html =     '<span class="search">';
        $html .=        '<label>'.$name.'：';
        $html .=            '从 <input name="'.$s_name.'" class="date_time" value="'.$s_val.'" type="text">';
        $html .=            ' 到 <input name="'.$e_name.'" class="date_time" value="'.$e_val.'" type="text">';
        $html .=        '</label>';
        $html .=    '</span>';

        echo $html;
    }

}