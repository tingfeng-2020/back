<?php

class ManageAuthController extends HController{

    public function beforeAction(){
        if(Manage::isManage()){
            return parent::beforeAction();
        }
        $this->redirect('index/index');
    }

}