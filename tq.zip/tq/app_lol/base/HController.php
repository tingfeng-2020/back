<?php

class HController extends Controller{

    public function beforeAction(){
        if(HSession::isLogin() && Manage::isManage()){
            return true;
        }

        $this->redirect('login/index');
        return true;
    }

}