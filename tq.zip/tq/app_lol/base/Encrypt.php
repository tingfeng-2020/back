<?php

/**
 * 编码类
 * Class Encrypt
 */
class Encrypt {

    const KEY = 'H+Privilege';
    const LOGIN_SUCCESS_KEY = 'HProtect+';

    public static function getSign($sign_time,$uid){
        $api_str = $sign_time.'_'.$uid;
        $sign = md5(md5($api_str).self::KEY);
        return $sign.'-'.$sign_time.'-'.$uid;
    }

    public static function checkSign($str) {
        $arr = explode('-',$str);
        if(count($arr) != 3){
            return [false,'签名不合法1'];
        }

        $sign_time = $arr[1];
        $uid = $arr[2];

        $real_sign = self::getSign($sign_time,$uid);

        if($real_sign != $str){
            return [false,'签名不合法2'];
        }

        if(time() - $sign_time > 300){
            return [false,'签名已过期'];
        }

        return [true,$uid];
    }

    public static function encodeUserPwd($str){
        return md5(md5($str).self::KEY);
    }

    public static function encodeUid($uid,$time = null){
        if($time === null){
            $time = time();
        }
        return $uid.'-'.md5('uid'.md5($uid.self::LOGIN_SUCCESS_KEY).$time).'-'.$time;
    }

}