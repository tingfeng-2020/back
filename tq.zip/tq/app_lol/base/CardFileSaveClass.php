<?php

class CardFileSaveClass{

    /**
     * 保存卡密到TXT
     * @param $manage_id
     * @param $hours
     * @param $card_arr
     * @return bool
     */
    public function save($manage_id,$hours,$card_arr){
        $path = H::app()->base_path.'/files/'.$manage_id.'/'.date('Ymd').'/';

        if($this->makeDir($path)){
            $file_path = $path.$hours.'_'.uniqid().'.txt';
            //写入方式打开，将文件指针指向文件末尾。如果文件不存在则尝试创建
            $handle = fopen($file_path,'a');
            if($handle){
                foreach($card_arr as $card){
                    fwrite($handle,$card['code']."\r\n");
                }
                fclose($handle);
                return true;
            }
        }

        return false;
    }

    /**
     * 创建目录
     * @param string $dir 目录字符串
     * @return bool
     */
    private function makeDir($dir) {
        if (!is_dir($dir)) {
            if($this->makeDir(dirname($dir))) {
                return mkdir($dir);
            }
            return false;
        }
        return true;
    }

}