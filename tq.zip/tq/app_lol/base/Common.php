<?php

class Common {

    public static function formatDValueTime($d_value_time){
        $hours = $d_value_time/3600;
        $day = $hours/24;
        $hours = $hours%24;
        return $day.'天'.$hours.'小时';
    }

    public static function numberFormat($num,$decimals = 2){
        return (float)number_format($num,$decimals,'.','');
    }

}