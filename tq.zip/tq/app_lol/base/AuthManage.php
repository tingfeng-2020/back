<?php

/**
 * User: Hermit
 * Date: 2018/9/15
 * Time: 17:05
 */
class AuthManage {

    const CARD_VIEW_ALL = 1;
    const USER_UNBIND = 2;
    const USER_BANED = 3;
    const CARD_BANED_CHANGE = 4;
    const CARD_DEL = 5;
    const USER_VIEW_ALL = 6;
    const SET_SOFT_NOTICE = 7;//设置软件公告

    public static $all_auth_arr = [
        self::USER_VIEW_ALL => '查看所有用户',
        self::CARD_VIEW_ALL => '查看所有卡密',
        self::USER_UNBIND => '解除软件绑定',
        self::USER_BANED => '封禁用户',
        self::CARD_BANED_CHANGE => '卡密封换',
        self::CARD_DEL => '卡密删除',
        self::SET_SOFT_NOTICE => '设置软件公告',
    ];

    public static function isHave($auth_type,$manage = null){
        if($manage === null){
            if(Manage::isSuperAdmin()){
                return true;
            }
            $auth = Manage::getMeInfo('auth');
        }else{
            $auth = $manage['auth'];
        }

        $auth_arr = $auth?explode(',',$auth):[];

        if(in_array($auth_type,$auth_arr)){
            return true;
        }else{
            return false;
        }
    }

}