<form action="<?php echo $this->genurl('save'); ?>" class="edit_form">

    <div class="attr">
        <span class="attr_name">注册通道：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('is_can_reg',array(
                0 => '关闭注册',
                1 => '开放注册',
            ),$is_can_reg); ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">充值通道：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('is_can_pay',array(
                0 => '关闭充值',
                1 => '开放充值',
            ),$is_can_pay); ?>
        </span>
    </div>

    <a id="save_edit_info" href="javascript:;" class="btn">保存</a>
</form>

<script>
    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'));
    });
</script>