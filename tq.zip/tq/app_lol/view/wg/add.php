<form action="<?php echo $this->genurl('savemac'); ?>" class="edit_form">

    <input name="id" value="<?php echo $wg['id']; ?>" type="hidden">

    <div class="attr">
        <span class="attr_name">分组标记：</span>
        <span class="attr_info">
            <input name="group_str" type="text" value="">
            <span>例如：XX网吧</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">类型：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('type',array(
                WgMac::TYPE_WB_MAC => '网吧MAC',
                WgMac::TYPE_FENPEI_MAC => '分配MAC'
            ),WgMac::TYPE_FENPEI_MAC); ?>
            <span> 网吧MAC是不会自动分配给卡密用户，分配MAC 是可以分配给卡密用户使用</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">到期时间：</span>
        <span class="attr_info">
            <input class="date_time" name="end_time" type="text" value="">
        </span>
    </div>

    <div class="attr">
        <span class="attr_name" style="position: absolute;">MAC地址：</span>
        <span class="attr_info" style="margin-left: 100px;">
            <textarea name="mac_str" style="width: 350px;height: 400px;text-align: left;"></textarea>
            <span>例如：80-80-80-80-80-80</span>
        </span>
    </div>

    <a id="save_edit_info" href="javascript:;" class="btn">保存</a>
</form>

<script>
    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'));
    });
</script>