<form action="<?php echo $this->genurl('save',array('id'=>$wg['id'])); ?>" class="edit_form">

    <div class="attr">
        <span class="attr_name">ID：</span>
        <span class="attr_info">
            <?php echo $wg['id']; ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">MAC地址：</span>
        <span class="attr_info">
            <?php echo $wg['mac']; ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">IP地址：</span>
        <span class="attr_info">
            <?php echo $wg['ip']; ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">是否授权：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('type',array(
                0 => '未授权',
                1 => '已授权'
            ),$wg['type']); ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name" style="position: absolute;">网关Account：</span>
        <span class="attr_info" style="margin-left: 100px;">
            <textarea name="account" style="width: 400px;height: 150px;"><?php echo $wg['account']; ?></textarea>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name" style="position: absolute;">网关LocalConfig：</span>
        <span class="attr_info" style="margin-left: 100px;">
            <textarea name="local_config" style="width: 400px;height: 150px;"><?php echo $wg['local_config']; ?></textarea>
        </span>
    </div>

    <a id="save_edit_info" href="javascript:;" class="btn">保存</a>
</form>

<script>
    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'));
    });
</script>