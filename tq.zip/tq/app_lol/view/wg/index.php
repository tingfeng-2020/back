<table class="x-table x-table-even">
    <thead align="center">
        <tr>
            <th>ID</th>
            <th>MAC地址</th>
            <th>内网IP</th>
            <th>总数量</th>
            <th>是否授权</th>
            <th>状态</th>
            <th>上线时间</th>
            <th>断线时间</th>
            <th>操作</th>
        </tr>
    </thead>
    <tbody align="center">
        <?php foreach($list as $data): ?>
            <tr>
                <td><?php echo $data['id']; ?></td>
                <td><?php echo $data['mac']; ?></td>
                <td><?php echo $data['ip_inner']; ?></td>
                <td><?php echo $data['mac_num']; ?></td>
                <td><?php echo $data['type']; ?></td>
                <td><?php echo $data['status']; ?></td>
                <td><?php echo $data['time']; ?></td>
                <td><?php echo $data['off_time']; ?></td>
                <td>
                    <a href="<?php echo $this->genurl('add',array('id'=>$data['id'])); ?>" class="btn">添加MAC</a>
                    <?php if(Manage::isSuperAdmin()): ?>
                        <a href="<?php echo $this->genurl('alt',array('id'=>$data['id'])); ?>" class="btn">编辑</a>
                        <a data-id="<?php echo $data['id']; ?>"
                           data-href="<?php echo $this->genurl('del'); ?>"
                           class="btn btn_del">删除</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>


<script>
    $('.btn_del').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var id = this_e.data('id');
        var post_data = {"id":id};

        if(confirm('确定要删除该网关？会删除该网关下所有MAC地址')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });
</script>