<!DOCTYPE html>
<html>
<head>
    <title>易迅加速器</title>
    <meta charset="utf-8">
    <style>
        html,body{
            font-family: 'Microsoft YaHei', 'Arial', 'sans-serif', 'SimHei';
            -webkit-font-smoothing: subpixel-antialiased;
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }
        #main_window{
            width: 300px;
            height: 150px;
            margin: 0 auto;
            position: relative;
            overflow: hidden;
            padding: 10px;
            background-color: black;
            box-shadow: 0px 0px 15px rgb(101, 99, 99);
            top: 10px;
        }
        .right_btn{
            position: absolute;
            right: 10px;
            top: 10px;
        }
        a{
            text-decoration: none;
            cursor: pointer;
            display: inline-block;
            font-size: 13px;
            text-shadow: 0px 0px 5px #000000;
            padding: 2px 5px;
            color: white;
        }
        #new_ver{
            position: absolute;
            top: 60px;
            left: 0px;
            color: white;
            width: 100%;
            text-align: center;
        }
        #tips{
            position: absolute;
            top: 90px;
            left: 0px;
            color: white;
            width: 100%;
            text-align: center;
        }
    </style>

    <script src="http://lib.sinaapp.com/js/jquery/2.2.4/jquery-2.2.4.min.js"></script>
</head>
<body data-w="350" data-h="200">
    <div id="main_window">
        <span class="right_btn">
            <a class="minimize unmove" onclick="eBtnMsg('minimize','');">最小化</a>
            <a class="close unmove" onclick="eBtnMsg('close','');">关闭</a>
        </span>
        <div id="new_ver">最新版本号：<?php echo $server_ver; ?></div>
        <div id="tips">易迅加速器已更新<br>请在群里下载最新版本</div>
    </div>

    <script>
        var is_bind_move_function = false;
        $('#main_window').mousedown(function (e) {
            is_bind_move_function = false;
            if (typeof window.eMoveMsg != 'function') {
                return;
            }
            var mousedownCls = e.target.classList.toString();
            if (mousedownCls.indexOf('unmove') == -1) {
                is_bind_move_function = true;
            }
        });
        $(document).mousemove(function (e) {
            if(is_bind_move_function){
                eMoveMsg();
            }
        }).mouseup(function () {
            is_bind_move_function = false;
        });
        function tip_show(msg){}
        function setLoginInitData(version,account,pwd,device){}
        $(function(){
            var w = $('body').data('w');
            var h = $('body').data('h');
            if (typeof window.eBtnMsg == 'function') {
                eBtnMsg('auto_window',w,h);
            }
        });
    </script>
</body>
</html>