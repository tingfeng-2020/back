<!DOCTYPE html>
<html>
<head>
    <title>易迅加速器</title>
    <meta charset="utf-8">
    <style>
        html,body{
            font-family: 'Microsoft YaHei', 'Arial', 'sans-serif', 'SimHei';
            -webkit-font-smoothing: subpixel-antialiased;
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }
        #view_animation{
            overflow: hidden;
            width: 290px;
            height: 400px;
            position: absolute;
            color: white;
            background-size: cover;
            top: 10px;
            left: 50%;
            margin-left: -145px;
            z-index: 5;
            box-shadow: 0px 0px 10px rgb(70, 69, 69);
            display: none;
        }
        #bottom_box{
            overflow: hidden;
            padding: 10px;
            width: 270px;
            height: 380px;
            margin: 0 auto;
            position: relative;
            color: white;
            box-shadow: 0px 0px 10px rgb(70, 69, 69);
            background-size: cover;
            top: 10px;
            background: #383735 url(http://wx3.sinaimg.cn/large/0060lm7Tly1fygychpwtlj30820b4aaf.jpg) no-repeat;
            display: none;
        }
        #bottom_box .header{
            text-align: center;
            height: 24px;
            position: absolute;
            width: 100%;
            left: 0px;
            top: 0px;
        }
        a{
            text-decoration: none;
            cursor: pointer;
            display: inline-block;
            font-size: 13px;
            text-shadow: 0px 0px 5px #000000;
            padding: 2px 5px;
        }
        .right_btn{
            position: absolute;
            right: 0px;
        }
        .center_box{
            position: absolute;
            width: 100%;
            text-align: center;
            display: none;
            top: 220px;
            left: 0px;
            z-index: 2;
        }
        .input_div{
            margin-bottom: 20px;
            position: relative;
        }
        .input{
            width: 210px;
            outline: none;
            padding: 5px;
            font-size: 14px;
            text-align: center;
            background-color: white;
            border: none;
            transition: 0.4s;
            -moz-transition: 0.4s;
            -webkit-transition: 0.4s;
            color: #666;
            position: relative;
            left: 0px;
        }
        .btn{
            width: 220px;
            display: inline-block;
            height: 30px;
            line-height: 30px;
            cursor: pointer;
            border: none;
            transition: 0.4s;
            -moz-transition: 0.4s;
            -webkit-transition: 0.4s;
            color: white;
            background-color: #EFB901;
            font-size: 14px;
        }
        .login_box{
            display: inline;
        }
        .btn_return{
            width: 105px;
            position: absolute;
            right: 35px;
        }
        #btn_reg,#btn_pay_code,#btn_edit{
            width: 105px;
            position: absolute;
            left: 35px;
        }
        textarea{
            resize:none;
            overflow: hidden;
            height: 55px;
        }
        #tips{
            position: absolute;
            left: 0px;
            bottom: 15px;
            width: 100%;
            text-align: center;
            color: white;
            z-index: 1;
            font-size: 14px
        }
        #success_msg{
            position: absolute;
            top: 143px;
            width: 100%;
            text-align: center;
            color: #ffffff;
            left: 0px;
            display: none;
            font-size: 14px;
            display: none;
        }
        .btns_box{
            height: 24px;
            position: absolute;
            top: 155px;
            width: 100%;
            left: 0px;
        }
        #forget{
            position: absolute;
            right: 43px;
            top: 0px;
        }
        #reg{
            position: absolute;
            left: 5px;
            top: 0px;
        }
        #pay{
            position: absolute;
            left: 43px;
            top: 0px;
        }
        #unbind{
            position: absolute;
            right: 5px;
            top: 0px;
        }


        .btn_luck_draw{
            position: absolute;
            bottom: -20px;
            background-color: #F44336;
            padding: 7px 12px;
            border-radius: 2px;
            left: 50%;
            margin-left: -44px;
        }
        .btn_luck_draw:hover{
            cursor: pointer;
            background-color: #f3736a;
        }
        #gonggao_box{
            position: relative;
            height: 22px;
            overflow: hidden;
            top: 400px;
            line-height: 22px;
            font-size: 14px;
            border: 1px solid #606060;
        }
        #gonggao{
            position: relative;
            white-space: nowrap;
            display: inline-block;
        }
        .minimize{
            font-size: 22px;
            display: inherit;
            height: 2px;
            line-height: 0px;
            overflow: hidden;
            padding: 0;
            position: absolute;
            right: 28px;
            top: 12px;
            text-shadow: none;
            color: #646464;
        }
        .close{
            font-size: 23px;
            position: absolute;
            right: 0px;
            top: -6px;
            text-shadow: none;
            color: #646464;
            display: inherit;
        }
        .reg_box .input_div{
            margin-bottom: 6px;
        }
        .center_box.reg_box{
            top: 200px
        }
        .forget_box .input_div{
            margin-bottom: 8px;
        }
        .btns_box a.hover{
            color: #FF8000;
            text-shadow: 0px 0px 5px #FF8000;
        }
        .center_box.unbind_box{
            top: 230px
        }
        .tip_concat{
            font-size: 14px;
            margin-top: 12px;
        }
        .unbind_box .btn_return{
            width: 220px;
            top: 85px;
        }
        #bottom_box.login_success{
            background: #383735 url(http://wx2.sinaimg.cn/large/0060lm7Tly1fyh05pck5kj308205k0sy.jpg) no-repeat;
        }
    </style>

    <script src="http://lib.sinaapp.com/js/jquery/2.2.4/jquery-2.2.4.min.js"></script>
</head>
<body data-w="400" data-h="610">
    <img id="view_animation" src="http://wx2.sinaimg.cn/large/0060lm7Tly1fyh15e0tkyg30820b40yt.gif">
<!--    <div id="view_animation"></div>-->

    <div id="bottom_box">
        <div class="header">
            <span class="right_btn">
                <a class="minimize unmove" onclick="eBtnMsg('minimize','');">+</a>
                <a class="close unmove" onclick="eBtnMsg('close','');">×</a>
            </span>
        </div>

        <div id="tips"></div>

        <div id="success_msg"></div>

        <div id="gonggao_box">
            <span id="gonggao"><?php echo $msg; ?></span>
        </div>

        <div class="btns_box">
            <a id="reg">注册</a>
            <a id="pay">充值</a>
            <a id="forget">改密</a>
            <a id="unbind">换机</a>
        </div>

        <div class="center_box login_box">
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="请输入账号" id="login_account" class="input unmove" value="" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="请输入密码" id="login_pwd" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <input id="login_device" type="hidden">
            <div class="input_div" style="margin-top: 20px;">
                <span id="btn_login" class="btn unmove">登　录</span>
            </div>

            <?php if($aid): ?>
                <span class="btn_luck_draw">幸运抽奖</span>
            <?php endif; ?>
        </div>

        <div class="center_box reg_box">
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="用户账号" id="reg_account" class="input unmove" value="" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="设定密码" id="reg_pwd" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="确认密码" id="reg_pwd_rep" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="充值卡密" id="reg_code" class="input unmove" value="" maxlength="50">
                </div>
            </div>
            <div class="input_div">
                <span id="btn_reg" class="btn unmove">注　册</span>
                <span data-page="reg" class="btn btn_return unmove">返　回</span>
            </div>
        </div>

        <div class="center_box pay_box">
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="请输入账号" id="pay_account" class="input unmove" value="" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="请输入卡密" id="pay_code" class="input unmove" value="" maxlength="50">
                </div>
            </div>
            <div class="input_div">
                <span id="btn_pay_code" class="btn unmove">充　值</span>
                <span data-page="pay" class="btn btn_return unmove">返　回</span>
            </div>
        </div>

        <div class="center_box forget_box">
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="请输入账号" id="forget_account" class="input unmove" value="" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="输入原密码" id="forget_pwd_old" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="输入新密码" id="forget_pwd_new" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <span id="btn_edit" class="btn unmove">改　密</span>
                <span data-page="forget" class="btn btn_return unmove">返　回</span>
            </div>
        </div>

        <div class="center_box unbind_box">
            <div class="tip_wait">此功能暂未开通 敬请期待</div>
            <div class="tip_concat">如需换机请联系管理员 每次换机收费三十元</div>
            <span data-page="unbind" class="btn btn_return unmove">返　回</span>
        </div>
    </div>

    <script>
//        $(function(){
//            var gonggao = $('#gonggao');
//            var gonggao_width = gonggao.width();
//            setInterval(function(){
//                var left = gonggao.position().left-1;
//                if(left + gonggao_width < 0){
//                    left = 270;
//                }
//                gonggao.css('left',(left-1).toString()+'px');
//            },20);
//        });

        $('.btns_box a').click(function(){
            $('.btns_box a').removeClass('hover');
            var this_e = $(this);
            this_e.addClass('hover');
            var id = this_e.attr('id');

            $('.center_box').hide();

            if(id == 'reg'){
                $('.reg_box').show();
            }else if(id == 'pay'){
                $('.pay_box').show();
            }else if(id == 'forget'){
                $('.forget_box').show();
            }else if(id == 'unbind'){
                $('.unbind_box').show();
            }
            tip_show('');
        });

        $('.btn_return').click(function(){
            $('.center_box').hide();
            $('.login_box').show();
            tip_show('');
        });

        $('#btn_login').click(function(){
            tip_show('');

            var account = $('#login_account').val().toString().trim();
            var pwd = $('#login_pwd').val().toString().trim();
            if(account == '' || pwd == ''){
                tip_show('账号或密码不可以为空');
                return false;
            }

            var device = $('#login_device').val().toString().trim();
            if(device == ''){
                tip_show('初始化错误，请以管理员权限重新运行');
                return false;
            }

            $('#btn_login').html('登 录 中 ...');

            apiRequestPost('login',{
                account: account,
                pwd: pwd,
                device: device
            });
        });

        $('#btn_reg').click(function(){
            tip_show('');

            var account = $('#reg_account').val().toString().trim();
            var pwd = $('#reg_pwd').val().toString().trim();
            var pwd_rep = $('#reg_pwd_rep').val().toString().trim();
            var code = $('#reg_code').val().toString().trim();
            if(account == '' || pwd == '' || pwd_rep == ''){
                tip_show('账号或密码不可以为空');
                return false;
            }
            if(pwd != pwd_rep){
                tip_show('密码不一致');
                return false;
            }

            if(code == ''){
                tip_show('卡密不可以为空');
                return false;
            }

            apiRequestPost('reg',{
                account: account,
                pwd: pwd,
                code: code
            });
        });

        $('#btn_pay_code').click(function(){
            tip_show('');

            var account = $('#pay_account').val().toString().trim();
            var code = $('#pay_code').val().toString().trim();
            if(account == ''){
                tip_show('账号不可以为空');
                return false;
            }
            if(code == ''){
                tip_show('卡密不可以为空');
                return false;
            }

            apiRequestPost('pay',{
                account: account,
                code: code
            });
        });

        $('#btn_edit').click(function(){
            tip_show('');

            var account = $('#forget_account').val().toString().trim();
            var pwd_old = $('#forget_pwd_old').val().toString().trim();
            var pwd_new = $('#forget_pwd_new').val().toString().trim();
            if(account == '' || pwd_old == ''){
                tip_show('账号或密码不可以为空');
                return false;
            }
            if(pwd_new == ''){
                tip_show('新密码不可以为空');
                return false;
            }

            apiRequestPost('edit',{
                account: account,
                pwd_old: pwd_old,
                pwd_new: pwd_new
            });
        });

        function onLoginSuccess(res_data) {
            $('#btn_login').html('登 录');

            if(res_data['ok']){
                $('.login_box').fadeOut();
                $('.btns_box').fadeOut();

                $('#tips').css('top','118px');

                $('#bottom_box').addClass('login_success');

                $('#bottom_box').animate({height:'180px'},600,function(){

                    var account = $('#login_account').val().toString().trim();
                    var pwd_old = $('#login_pwd').val().toString().trim();
                    tip_show('正在配置加速环境 请耐心等待');

                    $('#success_msg').fadeIn(function(){
                        $('#gonggao_box').css('top','160px').show();

                        eBtnMsg('auto_window',397,242);
                        setTimeout(function(){
                            eBtnMsg('success',account,pwd_old,res_data['sign']);
                        },1000);
                    });
                });
            }else{
                tip_show(res_data['msg']);
            }
        }

        function apiRequestPost(action,post_data){
            var api_url = '<?php echo $api_url; ?>';
            $.ajax({
                url: api_url+'?a=api_'+action+'&cf=1',
                data: post_data,
                type: 'post',
                dataType: 'json',
                success: function (res_data) {
                    if(action == 'login'){
                        onLoginSuccess(res_data);
                    }else{
                        tip_show(res_data['msg']);
                    }
                },
                error: function (res_data) {
                    tip_show('服务器繁忙，请稍后尝试操作');
                }
            });
        }

        var is_bind_move_function = false;
        $('#bottom_box').mousedown(function (e) {
            is_bind_move_function = false;
            if (typeof window.eMoveMsg != 'function') {
                return;
            }
            var mousedownCls = e.target.classList.toString();
            if (mousedownCls.indexOf('unmove') == -1) {
                is_bind_move_function = true;
            }
        });
        $(document).mousemove(function (e) {
            if(is_bind_move_function){
                eMoveMsg();
            }
        }).mouseup(function () {
            is_bind_move_function = false;
        });
        function tip_show(msg){
            $('#tips').html(msg);
        }
        function setLoginInitData(version,account,pwd,device){
            $('#login_account').val(account);
            $('#login_pwd').val(pwd);
            $('#login_device').val(device);

            $('#view_animation').show();

            setTimeout(function(){
                $('#view_animation').hide();
                $('#bottom_box').show();
            },2500);
        }
        $(function(){
            var w = $('body').data('w');
            var h = $('body').data('h');
            if (typeof window.eBtnMsg == 'function') {
                eBtnMsg('auto_window',w,h);
            }
        });
        function showloginBtns(){}
    </script>
</body>
</html>