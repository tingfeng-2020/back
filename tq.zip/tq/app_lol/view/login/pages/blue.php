<!DOCTYPE html>
<html>
<head>
    <title>渠道网游加速器</title>
    <meta charset="utf-8">
    <style>
        html,body{
            font-family: 'Microsoft YaHei', 'Arial', 'sans-serif', 'SimHei';
            -webkit-font-smoothing: subpixel-antialiased;
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }
        #bottom_box{
            overflow: hidden;
            padding: 10px;
            width: 355px;
            height: 600px;
            margin: 0 auto;
            position: relative;
            border-radius: 3px;
            color: white;
            box-shadow: 0px 0px 10px rgb(70, 69, 69);
            border: 1px solid #868686;
            background: -webkit-linear-gradient(-45deg,rgb(84, 73, 210),rgb(101, 143, 225));
            background-size: cover;
            top: 10px;
        }
        #bottom_box .header{
            text-align: center;
            height: 100px;
        }
        a{
            text-decoration: none;
            cursor: pointer;
            display: inline-block;
            font-size: 13px;
            text-shadow: 0px 0px 5px #000000;
            padding: 2px 5px;
        }
        a:hover{
            border-bottom: 1px solid #f9f9f9;
        }
        .header .title{
            text-shadow: 0px 0px 5px #000000;
            font-size: 20px;
            font-weight: bold;
            position: absolute;
            left: 50%;
            margin-left: -70px;
            top: 60px;
        }
        #version{
            font-size: 12px;
            position: relative;
        }
        .right_btn{
            position: absolute;
            right: 10px;
            top: 10px;
        }
        .center_box{
            position: absolute;
            min-height: 260px;
            width: 100%;
            text-align: center;
            display: none;
            top: 230px;
            left: 0px;
        }
        .input_div{
            margin-bottom: 20px;
            position: relative;
        }
        .input{
            width: 270px;
            outline: none;
            padding: 12px 12px;
            font-size: 14px;
            text-align: left;
            background-color: white;
            border: none;
            transition: 0.4s;
            -moz-transition: 0.4s;
            -webkit-transition: 0.4s;
            border-radius: 2px;
            color: #666;
            position: relative;
            left: 0px;
        }
        .btn{
            width: 294px;
            display: inline-block;
            height: 40px;
            line-height: 40px;
            cursor: pointer;
            border: none;
            transition: 0.4s;
            -moz-transition: 0.4s;
            -webkit-transition: 0.4s;
            color: #fff;
            background: rgba(0,0,0,0.2);
            border-radius: 2px;
        }
        .btn:hover{
            background: rgba(0,0,0,0.5);
        }
        #can_use_num{
            position: absolute;
            bottom: 20px;
            text-align: center;
            width: 100%;
            cursor: pointer;
            left: 0px;
        }
        .login_box{
            display: inline;
        }
        .btn_return{
            width: 90px;
        }
        #btn_edit,#btn_reg,#btn_pay_code{
            width: 90px;
            margin-right: 20px;
        }
        textarea{
            resize:none;
            overflow: hidden;
            height: 55px;
        }
        #tips{
            position: absolute;
            top: 200px;
            left: 0px;
            width: 100%;
            text-align: center;
            color: white;
            text-shadow: 0px 0px 5px #888888;
            z-index: 1;
        }
        #success_msg{
            position: absolute;
            top: 508px;
            width: 100%;
            text-align: center;
            color: #ffffff;
            text-shadow: 0px 0px 3px #dadada;
            left: 0px;
            display: none;
        }
        #forget{
            position: absolute;
            top: -44px;
            right: 40px;
            font-size: 14px;
        }
        #reg{
            position: absolute;
            left: 108px;
            top: 45px;
            font-size: 14px;
        }
        #pay{
            position: absolute;
            left: 40px;
            top: -44px;
            font-size: 14px;
        }
        #logo{
            position: absolute;
            width: 90px;
            top: 105px;
            left: 138px;
        }


        .btn_luck_draw{
            position: absolute;
            bottom: -20px;
            background-color: #F44336;
            padding: 7px 12px;
            border-radius: 2px;
            left: 50%;
            margin-left: -44px;
        }
        .btn_luck_draw:hover{
            cursor: pointer;
            background-color: #f3736a;
        }

        #luck_draw_box{
            width: 300px;
            height: 300px;
            position: fixed;
            top: 285px;
            left: 50%;
            margin-left: -150px;
            z-index: 10;
            background-color: #d43b34;
            border-radius: 2px;
            display: none;
        }
        .luck_box{
            width: 200px;
            height: 200px;
            position: absolute;
            left: 51px;
            top: 85px;
        }
        .square_box{
            border: 1px solid white;
            background-color: #7d7d7d;
            display: inline-block;
            width: 60px;
            height: 60px;
            position: absolute;
            text-align: center;
            line-height: 62px;
            color: #d43b34;
            background-color: #e2e2e2;
        }
        .box_1{
            top: 0px;
            left: 0px;
        }
        .box_2{
            top: 0px;
            left: 50%;
            margin-left: -31px;
        }
        .box_3{
            top: 0px;
            right: 0px;
        }
        .box_4{
            right: 0px;
            top: 50%;
            margin-top: -31px;
        }
        .box_5{
            right: 0px;
            bottom: 0px;
        }
        .box_6{
            left: 50%;
            margin-left: -31px;
            bottom: 0px;
        }
        .box_7{
            left: 0px;
            bottom: 0px;
        }
        .box_8{
            left: 0px;
            top: 50%;
            margin-top: -31px;
        }
        .box_center_btn{
            left: 50%;
            margin-left: -31px;
            top: 50%;
            margin-top: -31px;
            background-color: #ffc800;
            color: white;
            border-radius: 31px;
        }
        .box_center_btn:hover{
            background-color: #eac437;
            cursor: pointer;
        }
        .square_box.hover{
            background-color: #ffc800;
            color: white;
        }
        #luck_draw_box .tip_msg{
            color: white;
            text-align: center;
            padding: 10px;
            position: relative;
            top: 20px;
        }
        #close_luck_draw_box{
            color: white;
            position: absolute;
            right: 2px;
            top: 2px;
            z-index: 99;
        }
    </style>

    <script src="http://lib.sinaapp.com/js/jquery/2.2.4/jquery-2.2.4.min.js"></script>
</head>
<body data-w="400" data-h="650">

    <div id="luck_draw_box">
        <a id="close_luck_draw_box">关闭</a>
        <div class="tip_msg">未到期用户可以抽奖1次<br/>充值1次增加1次抽奖机会</div>
        <div class="luck_box">
            <span class="square_box box_center_btn">抽奖</span>
            <span class="square_box box_1">倒霉</span>
            <span class="square_box box_2">一等奖</span>
            <span class="square_box box_3">木有</span>
            <span class="square_box box_4">二等奖</span>
            <span class="square_box box_5">脑残</span>
            <span class="square_box box_6">三等奖</span>
            <span class="square_box box_7">白来</span>
            <span class="square_box box_8">三等奖</span>
        </div>
    </div>

    <div id="bottom_box">
        <div class="header">
            <span class="title">渠道网游加速器</span>
            <span class="right_btn">
                <span id="version">Ver：<?php echo $server_ver; ?></span>
                <a class="minimize unmove" onclick="eBtnMsg('minimize','');">最小化</a>
                <a class="close unmove" onclick="eBtnMsg('close','');">关闭</a>
            </span>
        </div>

        <div id="tips"></div>

        <div id="success_msg"></div>

        <img id="logo" src="<?php echo H::app()->public_url; ?>/login_page/logo.png">

        <div class="center_box login_box">
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="账号" id="login_account" class="input unmove" value="" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="密码" id="login_pwd" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <input id="login_device" type="hidden">
            <div class="input_div" style="margin-top: 50px;">
                <a id="pay">卡密充值</a>
                <a id="forget">忘记密码？</a>
                <span id="btn_login" class="btn unmove">登 录</span>
                <a id="reg">还没有账号？快速注册</a>
            </div>

            <?php if($aid): ?>
                <span class="btn_luck_draw">幸运抽奖</span>
            <?php endif; ?>
        </div>

        <div class="center_box reg_box">
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="账号" id="reg_account" class="input unmove" value="" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="密码" id="reg_pwd" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="重复" id="reg_pwd_rep" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <textarea placeholder="卡密" id="reg_code" class="input unmove" maxlength="50"></textarea>
                </div>
            </div>
            <div class="input_div">
                <span id="btn_reg" class="btn unmove">注 册</span>
                <span data-page="reg" class="btn btn_return unmove">返 回</span>
            </div>
        </div>

        <div class="center_box pay_box">
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="账号" id="pay_account" class="input unmove" value="" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <textarea placeholder="卡密" id="pay_code" class="input unmove" maxlength="50"></textarea>
                </div>
            </div>
            <div class="input_div">
                <span id="btn_pay_code" class="btn unmove">充 值</span>
                <span data-page="pay" class="btn btn_return unmove">返 回</span>
            </div>
        </div>

        <div class="center_box forget_box">
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="账号" id="forget_account" class="input unmove" value="" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="旧密" id="forget_pwd_old" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="新密" id="forget_pwd_new" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <span id="btn_edit" class="btn unmove">改 密</span>
                <span data-page="forget" class="btn btn_return unmove">返 回</span>
            </div>
        </div>

        <div id="can_use_num">点击查询剩余位置</div>
    </div>

    <script>
        $('.btn_luck_draw').click(function(){
            $('#luck_draw_box').fadeIn();
        });
        $('#close_luck_draw_box').click(function(){
            $('#luck_draw_box').fadeOut();
        });

        var now_num = 1;
        var lucy_box_interval = 0;
        $('.box_center_btn').click(function(){
            if(lucy_box_interval > 0){
                return false;
            }
            var account = $('#login_account').val().toString().trim();
            if(account == ''){
                $('#luck_draw_box .tip_msg').html('账号不可以为空');
                return false;
            }

            var device = $('#login_device').val().toString().trim();
            device = 'ddddd';
            if(device == ''){
                $('#luck_draw_box .tip_msg').html('初始化错误，请以管理员权限重新运行');
                return false;
            }

            var api_url = '<?php echo $api_url; ?>';
            $.ajax({
                url: api_url+'?a=api_lucybox',
                data: {
                    'account': account,
                    'device': device,
                    'aid': '<?php echo $aid; ?>'
                },
                type: 'post',
                dataType: 'json',
                success: function (res_data) {
                    $('#luck_draw_box .tip_msg').html(res_data['msg']);

                    if(res_data['ok']){
                        lucyBoxRun(res_data);
                    }
                },
                error: function (res_data) {
                    $('#luck_draw_box .tip_msg').html('服务器繁忙，请稍后尝试操作');
                }
            });
        });

        function lucyBoxRun(res_data){
            $('.box_'+now_num).removeClass('hover');
            now_num = 1;

            var speed = 100;
            var run_num = 0;

            var end_box_key = parseInt(res_data['key']);
            var end_run_num = end_box_key+37

            var i = 0;
            lucy_box_interval = setInterval(function(){
                i++;
                if(i%speed==0){
                    netLucyBoxHover();
                    run_num++;

                    switch (run_num){
                        case 1:speed = 80;break;
                        case 2:speed = 60;break;
                        case 3:speed = 40;break;
                        case 4:speed = 30;break;
                        case 5:speed = 20;break;
                        case 6:speed = 10;break;
                        case 7:speed = 5;break;
                        case end_run_num:speed = 10;break;
                        case end_run_num+1:speed = 20;break;
                        case end_run_num+2:speed = 30;break;
                        case end_run_num+3:speed = 40;break;
                        case end_run_num+4:speed = 50;break;
                        case end_run_num+5:speed = 60;break;
                        case end_run_num+6:speed = 70;break;
                        case end_run_num+7:speed = 80;break;
                        case end_run_num+8:speed = 90;break;
                        case end_run_num+9:speed = 100;break;
                        case end_run_num+10:lucyBoxEndCallback(res_data);break;
                    }
                }
            },10);
        }
        function netLucyBoxHover(){
            $('.box_'+now_num).removeClass('hover');
            if(now_num == 8){
                now_num = 1;
            }else{
                now_num++;
            }
            $('.box_'+now_num).addClass('hover');
        }
        function lucyBoxEndCallback(res_data){
            clearInterval(lucy_box_interval);
            lucy_box_interval = 0;
            $('#luck_draw_box .tip_msg').html(res_data['real_msg']);
        }


        var is_get_num = false;
        $('#can_use_num').click(function(){
            if(is_get_num){
                return false;
            }
            $('#can_use_num').html('刷新数量中...');
            is_get_num = true;
            setTimeout(function(){
                apiRequestPost('getnum',{});
                is_get_num = false;
            },1000)
        });
        $('#reg').click(function(){
            $('.login_box').fadeOut(function(){
                $('.reg_box').fadeIn();
            });
            tip_show('');
        });
        $('#pay').click(function(){
            $('.login_box').fadeOut(function(){
                $('.pay_box').fadeIn();
            });
            tip_show('');
        });
        $('#forget').click(function(){
            $('.login_box').fadeOut(function(){
                $('.forget_box').fadeIn();
            });
            tip_show('');
        });
        $('.btn_return').click(function(){
            var page_type = $(this).data('page');
            if(page_type == 'reg'){
                $('.reg_box').fadeOut(function(){
                    $('.login_box').fadeIn();
                });
            }else if(page_type == 'pay'){
                $('.pay_box').fadeOut(function(){
                    $('.login_box').fadeIn();
                });
            }else{
                $('.forget_box').fadeOut(function(){
                    $('.login_box').fadeIn();
                });
            }

            tip_show('');
        });

        $('#btn_login').click(function(){
            tip_show('');

            var account = $('#login_account').val().toString().trim();
            var pwd = $('#login_pwd').val().toString().trim();
            if(account == '' || pwd == ''){
                tip_show('账号或密码不可以为空');
                return false;
            }

            var device = $('#login_device').val().toString().trim();
            if(device == ''){
                tip_show('初始化错误，请以管理员权限重新运行');
                return false;
            }

            $('#btn_login').html('登 录 中 ...');

            apiRequestPost('login',{
                account: account,
                pwd: pwd,
                device: device
            });
        });

        $('#btn_reg').click(function(){
            tip_show('');

            var account = $('#reg_account').val().toString().trim();
            var pwd = $('#reg_pwd').val().toString().trim();
            var pwd_rep = $('#reg_pwd_rep').val().toString().trim();
            var code = $('#reg_code').val().toString().trim();
            if(account == '' || pwd == '' || pwd_rep == ''){
                tip_show('账号或密码不可以为空');
                return false;
            }
            if(pwd != pwd_rep){
                tip_show('密码不一致');
                return false;
            }

            if(code == ''){
                tip_show('卡密不可以为空');
                return false;
            }

            apiRequestPost('reg',{
                account: account,
                pwd: pwd,
                code: code
            });
        });

        $('#btn_pay_code').click(function(){
            tip_show('');

            var account = $('#pay_account').val().toString().trim();
            var code = $('#pay_code').val().toString().trim();
            if(account == ''){
                tip_show('账号不可以为空');
                return false;
            }
            if(code == ''){
                tip_show('卡密不可以为空');
                return false;
            }

            apiRequestPost('pay',{
                account: account,
                code: code
            });
        });

        $('#btn_edit').click(function(){
            tip_show('');

            var account = $('#forget_account').val().toString().trim();
            var pwd_old = $('#forget_pwd_old').val().toString().trim();
            var pwd_new = $('#forget_pwd_new').val().toString().trim();
            if(account == '' || pwd_old == ''){
                tip_show('账号或密码不可以为空');
                return false;
            }
            if(pwd_new == ''){
                tip_show('新密码不可以为空');
                return false;
            }

            apiRequestPost('edit',{
                account: account,
                pwd_old: pwd_old,
                pwd_new: pwd_new
            });
        });

        function onLoginSuccess(res_data) {
            $('#btn_login').html('登 录');

            if(res_data['ok']){
                $('.login_box').fadeOut();
                $('#can_use_num').fadeOut();

                $('#logo').animate({width:'26px',top:'9px','left':'10px'},600);
                $('#version').animate({'left':'-176px'},600);
                $('#tips').css('top','115px');
                $('#success_msg').css('top','160px');

                $('#bottom_box').animate({height:'200px'},600,function(){
                    var account = $('#login_account').val().toString().trim();
                    var pwd_old = $('#login_pwd').val().toString().trim();
                    tip_show('连接服务器，请等待...');
                    $('#success_msg').html(res_data['msg']).fadeIn(function(){
                        eBtnMsg('auto_window',397,242);
                        setTimeout(function(){
                            eBtnMsg('success',account,pwd_old,res_data['sign']);
                        },1000);
                    });
                });
            }else{
                tip_show(res_data['msg']);
            }
        }

        function apiRequestPost(action,post_data){
            var api_url = '<?php echo $api_url; ?>';
            $.ajax({
                url: api_url+'?a=api_'+action,
                data: post_data,
                type: 'post',
                dataType: 'json',
                success: function (res_data) {
                    if(action == 'login'){
                        onLoginSuccess(res_data);
                    }else if(action == 'getnum'){
                        var html = '';
                        for(var k in res_data['list']){
                            var str = res_data['list'][k];
                            html += ''+str+'<br/>';
                        }
                        html += '点击刷新';
                        $('#can_use_num').html(html);
                    }else{
                        tip_show(res_data['msg']);
                    }
                },
                error: function (res_data) {
                    tip_show('服务器繁忙，请稍后尝试操作');
                }
            });
        }

        var is_bind_move_function = false;
        $('#bottom_box').mousedown(function (e) {
            is_bind_move_function = false;
            if (typeof window.eMoveMsg != 'function') {
                return;
            }
            var mousedownCls = e.target.classList.toString();
            if (mousedownCls.indexOf('unmove') == -1) {
                is_bind_move_function = true;
            }
        });
        $(document).mousemove(function (e) {
            if(is_bind_move_function){
                eMoveMsg();
            }
        }).mouseup(function () {
            is_bind_move_function = false;
        });
        function tip_show(msg){
            $('#tips').html(msg);
        }
        function setLoginInitData(version,account,pwd,device){
            $('#version').html('Ver：'+version);
            $('#login_account').val(account);
            $('#login_pwd').val(pwd);
            $('#login_device').val(device);
        }
        $(function(){
            var w = $('body').data('w');
            var h = $('body').data('h');
            if (typeof window.eBtnMsg == 'function') {
                eBtnMsg('auto_window',w,h);
            }
        });
        function showloginBtns(){}
    </script>
</body>
</html>