<?php

if($nb == 'nbtest'){
    include 'pages/neibu_test.php';
}else if($nb){
    if($ver == $server_ver){
        include 'pages/neibu.php';
    }else{
        include 'update.php';
    }
}else if($cf){
    if($ver == $server_ver){
        include 'pages/chaofan.php';
    }else{
        include 'cf_update.php';
    }
}else{
    //include 'weihu.php';
    if($ver == $server_ver){
        if($ui_page){
            include $ui_page;
        }else{
            include 'pages/blue.php';
        }
    }else{
        include 'update.php';
    }
}