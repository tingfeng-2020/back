<!DOCTYPE html>
<html>
<head>
    <title><?php echo H::app()->getConfig('app_name'); ?></title>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="Keywords" content="后台管理">
    <meta name="description" content="后台管理">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <link rel="shortcut icon" href="<?php echo H::app()->public_url; ?>/images/favicon.ico" sizes="any" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" href="<?php echo H::app()->public_url; ?>/images/apple.png">

    <link href="<?php echo $this->getAppPublicUrl(); ?>/css/login.css?t=201708242305" type="text/css" rel="stylesheet">
    <script>
        var geetest_data = {
            gt: '<?php echo $gt; ?>',
            challenge: '<?php echo $challenge; ?>',
            new_captcha: '<?php echo $new_captcha; ?>',
            offline: <?php echo !$success?1:0; ?>
        };
    </script>
</head>
<body>
    <div id="login_box">
        <div id="app_logo">
            <img src="<?php echo $this->getAppPublicUrl(); ?>/img/cute_dog.gif">
        </div>
        <span id="sys_title"><?php echo H::app()->getConfig('app_name'); ?></span>
        <div>
            <input id="user_account" value="<?php echo isset($cookie['account'])?$cookie['account']:''; ?>" class="login_input" placeholder="账号" type="text">
        </div>
        <div>
            <input id="user_pwd" value="" class="login_input" placeholder="密码" type="password">
        </div>
        <div>
            <span id="geetest_box"></span>
        </div>
        <div id="err_msg"></div>

        <a id="btn_login" href="javascript:;">登录</a>
        <div id="copyright">© <?php echo date('Y'); ?> Build By H+</div>
    </div>

    <script src="<?php echo H::app()->public_url; ?>/js/jquery.min.js"></script>
    <script src="<?php echo H::app()->public_url; ?>/js/gt.js"></script>
    <script src="<?php echo H::app()->public_url; ?>/js/md5-min.js"></script>
    <script src="<?php echo $this->getAppPublicUrl(); ?>/js/login.js?t=201708242305"></script>
</body>
</html>