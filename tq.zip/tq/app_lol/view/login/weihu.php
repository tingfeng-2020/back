<!DOCTYPE html>
<html>
<head>
    <title>渠道网游加速器</title>
    <meta charset="utf-8">
    <style>
        html,body{
            font-family: 'Microsoft YaHei', 'Arial', 'sans-serif', 'SimHei';
            -webkit-font-smoothing: subpixel-antialiased;
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }
        #bottom_box{
            overflow: hidden;
            padding: 10px;
            width: 355px;
            height: 600px;
            margin: 0 auto;
            position: relative;
            border-radius: 3px;
            color: white;
            box-shadow: 0px 0px 10px rgb(70, 69, 69);
            border: 1px solid #868686;
            background: -webkit-linear-gradient(-45deg,rgb(84, 73, 210),rgb(101, 143, 225));
            background-size: cover;
            top: 10px;
        }
        #bottom_box .header{
            text-align: center;
            height: 100px;
        }
        a{
            text-decoration: none;
            cursor: pointer;
            display: inline-block;
            font-size: 13px;
            text-shadow: 0px 0px 5px #000000;
            padding: 2px 5px;
        }
        a:hover{
            border-bottom: 1px solid #f9f9f9;
        }
        .header .title{
            text-shadow: 0px 0px 5px #000000;
            font-size: 15px;
            font-weight: bold;
            position: absolute;
            left: 26px;
            top: 11px;
        }
        #version{
            font-size: 12px;
            position: relative;
        }
        .right_btn{
            position: absolute;
            right: 10px;
            top: 10px;
        }
        .center_box{
            position: absolute;
            min-height: 260px;
            width: 100%;
            text-align: center;
            display: none;
            top: 60px;
            left: 0px;
        }
        .input_div{
            margin-bottom: 10px;
            position: relative;
        }
        .input{
            width: 200px;
            outline: none;
            padding: 6px;
            font-size: 14px;
            text-align: left;
            background-color: white;
            border: none;
            transition: 0.4s;
            -moz-transition: 0.4s;
            -webkit-transition: 0.4s;
            border-radius: 2px;
            color: #666;
            position: relative;
            left: 0px;
        }
        .btn{
            width: 210px;
            display: inline-block;
            height: 40px;
            line-height: 40px;
            cursor: pointer;
            border: none;
            transition: 0.4s;
            -moz-transition: 0.4s;
            -webkit-transition: 0.4s;
            color: #fff;
            background: rgba(0,0,0,0.2);
            border-radius: 2px;
        }
        .btn:hover{
            background: rgba(0,0,0,0.5);
        }
        #can_use_num{
            position: absolute;
            bottom: 20px;
            text-align: center;
            width: 100%;
            cursor: pointer;
            left: 0px;
        }
        .login_box{
            display: inline;
        }
        .btn_return{
            width: 90px;
        }
        #btn_edit,#btn_reg,#btn_pay_code{
            width: 90px;
            margin-right: 20px;
        }
        textarea{
            resize:none;
            overflow: hidden;
            height: 55px;
        }
        #tips{
            position: absolute;
            top: 120px;
            left: 0px;
            width: 100%;
            text-align: center;
            color: white;
            text-shadow: 0px 0px 5px #888888;
            z-index: 1;
        }
        #success_msg{
            position: absolute;
            top: 508px;
            width: 100%;
            text-align: center;
            color: #ffffff;
            text-shadow: 0px 0px 3px #dadada;
            left: 0px;
            display: none;
        }
        #forget{
            position: absolute;
            top: -44px;
            right: 40px;
            font-size: 14px;
        }
        #reg{
            position: absolute;
            left: 108px;
            top: 45px;
            font-size: 14px;
        }
        #pay{
            position: absolute;
            left: 40px;
            top: -44px;
            font-size: 14px;
        }
        #logo{
            position: absolute;
            width: 90px;
            top: 105px;
            left: 138px;
        }


        .btn_luck_draw{
            position: absolute;
            bottom: -20px;
            background-color: #F44336;
            padding: 7px 12px;
            border-radius: 2px;
            left: 50%;
            margin-left: -44px;
        }
        .btn_luck_draw:hover{
            cursor: pointer;
            background-color: #f3736a;
        }
    </style>

    <script src="http://lib.sinaapp.com/js/jquery/2.2.4/jquery-2.2.4.min.js"></script>
</head>
<body data-w="400" data-h="650">

    <div id="bottom_box">
        <div class="header">
            <span class="title">渠道网游加速器</span>
            <span class="right_btn">
                <span id="version">Ver：<?php echo $server_ver; ?></span>
                <a class="minimize unmove" onclick="eBtnMsg('minimize','');">最小化</a>
                <a class="close unmove" onclick="eBtnMsg('close','');">关闭</a>
            </span>
        </div>

        <div class="center_box login_box">
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="账号" id="login_account" class="input unmove" value="" maxlength="20">
                </div>
            </div>
            <div class="input_div">
                <div class="right_input">
                    <input placeholder="密码" id="login_pwd" class="input unmove" value="" type="password" maxlength="20">
                </div>
            </div>
            <span id="btn_login" class="btn unmove">查询到期时间</span>
            <div id="tips"></div>
        </div>

        <div style="position: relative;top: 75px;padding: 20px;">
            致歉信：<br>
            　　尊敬的客户你们好，渠道运营团队在此先真诚的给你们道歉。
            希望你们理解。我们也是普普通通的人，有些外界因素无法避免，可能
            还有很多刚刚购买就遇到这次重大打击的客户，说实话，您很幸运，先去
            买一张彩票。<br>
            　　最后渠道不会跑路，这次维护可能时间会久一点，对于政策，我们给出：<br><br>
            <span style="color: #75e621;">
                1.先恢复内部版本，从以往长期使用的老客户中选取进入。<br>
                2.下周后逐渐恢复其它客户。<br>
                3.相信我们的客户可以选择等待，钱也不多，等我们回归之日，在原有基础上每个账号<span style="color:yellow;"> 增加7天 (退款的不会加)</span>
            </span><br>
            <span style="position: relative;left: 80px;top: 10px">Please wait for us 2018.10.18</span>
        </div>

    </div>

    <script>
        $('#btn_login').click(function(){
            tip_show('');

            var account = $('#login_account').val().toString().trim();
            var pwd = $('#login_pwd').val().toString().trim();
            if(account == '' || pwd == ''){
                tip_show('账号或密码不可以为空');
                return false;
            }

            $('#btn_login').html('查 询 中 ...');

            apiRequestPost('login2',{
                account: account,
                pwd: pwd,
            });
        });

        function apiRequestPost(action,post_data){
            var api_url = '<?php echo $api_url; ?>';
            $.ajax({
                url: api_url+'?a=api_'+action,
                data: post_data,
                type: 'post',
                dataType: 'json',
                success: function (res_data) {
                    if(action == 'login'){
                        onLoginSuccess(res_data);
                    }else{
                        tip_show(res_data['msg']);
                    }
                },
                error: function (res_data) {
                    tip_show('服务器繁忙，请稍后尝试操作');
                }
            });
        }

        function onLoginSuccess(res_data) {
            $('#btn_login').html('查询到期时间');
            tip_show(res_data['msg']);
        }
        function tip_show(msg){
            $('#tips').html(msg);
        }
        var is_bind_move_function = false;
        $('#bottom_box').mousedown(function (e) {
            is_bind_move_function = false;
            if (typeof window.eMoveMsg != 'function') {
                return;
            }
            var mousedownCls = e.target.classList.toString();
            if (mousedownCls.indexOf('unmove') == -1) {
                is_bind_move_function = true;
            }
        });
        $(document).mousemove(function (e) {
            if(is_bind_move_function){
                eMoveMsg();
            }
        }).mouseup(function () {
            is_bind_move_function = false;
        });
        function setLoginInitData(version,account,pwd,device){}
        $(function(){
            var w = $('body').data('w');
            var h = $('body').data('h');
            if (typeof window.eBtnMsg == 'function') {
                eBtnMsg('auto_window',w,h);
            }
        });
        function showloginBtns(){}
    </script>
</body>
</html>