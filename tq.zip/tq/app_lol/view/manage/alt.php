<style>
    .auth{
        cursor: pointer;
        margin-right: 10px;
    }
</style>
<form action="<?php echo $this->genurl('save',array('id'=>$manage['id'])); ?>" class="edit_form">
    <div class="attr">
        <span class="attr_name">QQ：</span>
        <span class="attr_info">
            <input name="qq" type="text" value="<?php echo $manage['qq']; ?>">
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">账号：</span>
        <span class="attr_info">
            <input name="account" type="text" value="<?php echo $manage['account']; ?>">
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">密码：</span>
        <span class="attr_info">
            <input name="pwd" type="text">
            <?php if($manage): ?>
                <span>填写就表示改密码，不填写表示不改</span>
            <?php endif; ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">范围：</span>
        <span class="attr_info">
            <input name="can_view_card_type" type="text" value="<?php echo $manage['can_view_card_type']; ?>">
        </span>
    </div>

    <?php if(Manage::isSuperAdmin()): ?>
<!--        <div class="attr">-->
<!--            <span class="attr_name">类型：</span>-->
<!--            <span class="attr_info">-->
<!--                --><?php //HtmlBuilder::buildSelect('type',array(
//                    Manage::TYPE_DAILI => '代理',
//                ),$manage['type']); ?>
<!--            </span>-->
<!--        </div>-->

        <div class="attr">
            <span class="attr_name">余额：</span>
            <span class="attr_info">
                <input name="money" type="text" value="<?php echo $manage['money']; ?>">
                <span>(单位:元)</span>
            </span>
        </div>
    <?php endif; ?>

    <div class="attr">
        <span class="attr_name">状态：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('status',array(
                Manage::STATUS_OK => '正常',
                Manage::STATUS_FORBID =>  '禁止'
            ),$manage?$manage['status']:Manage::STATUS_OK); ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">权限：</span>
        <span class="attr_info">
            <?php foreach (AuthManage::$all_auth_arr as $auth_type => $auth_name): ?>
                <label class="auth">
                    <input name="auth[]" <?php echo AuthManage::isHave($auth_type,$manage)?'checked="checked"':''; ?> value="<?php echo $auth_type; ?>" type="checkbox">
                    <?php echo $auth_name; ?>
                </label>
            <?php endforeach; ?>
        </span>
    </div>

    <a id="save_edit_info" href="javascript:;" class="btn">保存</a>
</form>

<script>
    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'));
    });
</script>