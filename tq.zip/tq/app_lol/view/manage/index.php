<?php

HtmlBuilder::buildFormStart($this->genurl('index'));

HtmlBuilder::buildInputSearch(array(
    'acount' => '账号'
));

HtmlBuilder::buildSelectSearch('状态','status',array(
    0                           => '全部',
    Manage::STATUS_FORBID + 1   => '禁止',
    Manage::STATUS_OK + 1       => '正常',
),isset($_GET['status'])?$_GET['status']:0);

HtmlBuilder::buildFormEnd();

?>

<a href="<?php echo $this->genurl('alt'); ?>" class="btn">新增代理</a>

<span>合计金额：<?php echo $all_money; ?></span>

<table class="x-table x-table-even">
    <thead align="center">
        <tr>
            <th>QQ</th>
            <th>账号</th>
            <th>类型</th>
            <th>未使用卡密</th>
            <th>余额(单位:元)</th>
            <th>状态</th>
            <th>操作</th>
        </tr>
    </thead>
    <tbody align="center">
        <?php foreach($list as $data): ?>
            <tr>
                <td><?php echo $data['qq']; ?></td>
                <td><?php echo $data['account']; ?></td>
                <td><?php echo $data['type']; ?></td>
                <td><?php echo $data['card_num']; ?></td>
                <td><?php echo $data['money']; ?></td>
                <td><?php echo $data['status']; ?></td>
                <td>
                    <a href="<?php echo $this->genurl('alt',array('id'=>$data['id'])); ?>" class="btn">编辑</a>
<!--                    <a data-id="--><?php //echo $data['id']; ?><!--" data-href="--><?php //echo $this->genurl('baned'); ?><!--" class="btn btn_baned">封卡</a>-->
                    <a data-id="<?php echo $data['id']; ?>" data-href="<?php echo $this->genurl('del'); ?>" class="btn btn_del">删除</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php HtmlBuilder::buildPage($now_page,$all_num); ?>

<script>
    $('.btn_baned').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var id = this_e.data('id');
        var post_data = {"id":id};

        if(confirm('确定要封掉该用户的所有卡密？')){
            $.app.postData(url,post_data,function(){
                alert("封禁成功");
                window.location.reload();
            });
        }
    });

    $('.btn_del').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var id = this_e.data('id');
        var post_data = {"id":id};

        if(confirm('确定删除该代用户？(卡密不会删除)')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });
</script>