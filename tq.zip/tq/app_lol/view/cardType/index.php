<a href="<?php echo $this->genurl('alt'); ?>" class="btn">新增卡密类型</a>

<table class="x-table x-table-even">
    <thead align="center">
        <tr>
            <th>ID</th>
            <th>名称</th>
            <th>时间</th>
            <th>价格</th>
            <th>前缀</th>
            <th>网关限制</th>
            <th>是否显示</th>
            <th>类型</th>
            <th>操作</th>
        </tr>
    </thead>
    <tbody align="center">
        <?php foreach($list as $data): ?>
            <tr>
                <td><?php echo $data['id']; ?></td>
                <td><?php echo $data['name']; ?></td>
                <td><?php echo $data['num']; ?></td>
                <td><?php echo $data['money']; ?></td>
                <td><?php echo $data['prefix']; ?></td>
                <td><?php echo $data['can_use_wg']; ?></td>
                <td><?php echo $data['is_show']?'显示':'不显示'; ?></td>
                <td><?php echo CardType::formatType($data['type']); ?></td>
                <td>
                    <a href="<?php echo $this->genurl('alt',array('id'=>$data['id'])); ?>" class="btn">编辑</a>
                    <a data-id="<?php echo $data['id']; ?>"
                       data-href="<?php echo $this->genurl('del'); ?>"
                       class="btn btn_del">删除</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<script>
    $('.btn_del').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var id = this_e.data('id');
        var post_data = {"id":id};

        if(confirm('确定要删除该类型？')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });
</script>