<form action="<?php echo $this->genurl('save',array('id'=>$card_type['id'])); ?>" class="edit_form">
    <div class="attr">
        <span class="attr_name">名称：</span>
        <span class="attr_info">
            <input name="name" type="text" value="<?php echo $card_type['name']; ?>">
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">小时：</span>
        <span class="attr_info">
            <input name="num" type="text" value="<?php echo $card_type['num']; ?>">
            <span>小时：表示卡密增加多少时间，单位小时 1天24 7天168 30天720</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">卡密前缀：</span>
        <span class="attr_info">
            <input name="prefix" type="text" value="<?php echo $card_type['prefix']; ?>">
            <span>例如：XXX-EKSHJJDDQIAJSKFDJC (可以不填写不用前缀)</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">价格：</span>
        <span class="attr_info">
            <input name="money" type="text" value="<?php echo $card_type['money']; ?>">
            <span>单位(元) 可以输入小数</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">限制网关ID：</span>
        <span class="attr_info">
            <input name="can_use_wg" type="text" value="<?php echo $card_type['can_use_wg']; ?>">
            <span>格式："id,id,id" 逗号为英文逗号,为空 表示不限制 所有网关都可以使用</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">是否显示数量：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('is_show',array(
                0 => '不显示',
                1 =>  '显示'
            ),$card_type['is_show']); ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">类型：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('type',array(
                CardType::TYPE_NORMAL => '普通',
                CardType::TYPE_VIP => 'VIP尊享',
                CardType::TYPE_CHAOFAN => '超凡',
            ),$card_type['type']); ?>
        </span>
    </div>

    <a id="save_edit_info" href="javascript:;" class="btn">保存</a>
</form>

<script>
    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'));
    });
</script>