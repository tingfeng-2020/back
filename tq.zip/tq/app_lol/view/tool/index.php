<form action="<?php echo $this->genurl('save'); ?>" class="edit_form" method="get">

    <input name="a" value="tool_save" type="hidden">

    <div class="attr">
        <span class="attr_name">MAC前缀：</span>
        <span class="attr_info">
            <input name="mac" type="text" value="">
            <span>例如：D8-50-E6-04-CB (前5个MAC地址 最后2位按01-99后台自动生成)</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">生成个数：</span>
        <span class="attr_info">
            <input name="num" type="text" value="">
            <span>最大1次生成数量：99个</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">备注：</span>
        <span class="attr_info">
            <input name="remark" type="text" value="">
            <span>备注用于导入网关</span>
        </span>
    </div>

    <button class="btn" type="submit">生成MAC</button>
</form>