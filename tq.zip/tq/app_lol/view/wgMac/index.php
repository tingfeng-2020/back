<style>
    .red{color: red;}
</style>

<?php

HtmlBuilder::buildFormStart($this->genurl('index'));

HtmlBuilder::buildInputSearch(array(
    'id' => 'ID',
    'mac' => 'MAC地址',
    'wg_id' => '网关ID',
    'account' => '账号'
));

HtmlBuilder::buildSelectSearch('状态','status',array(
    0 => '全部',
    WgMac::STATUS_ONLINE => '在线',
    WgMac::STATUS_OFFLINE => '离线',
),isset($_GET['status'])?$_GET['status']:0);

HtmlBuilder::buildSelectSearch('是否使用','type',array(
    0 => '全部',
    1 => '已使用',
    2 => '未使用',
),isset($_GET['type'])?$_GET['type']:0);

HtmlBuilder::buildSelectSearch('排序','sort',array(
    0 => '默认',
    1 => '到期时间升序',
    2 => '到期时间降序',
),isset($_GET['sort'])?$_GET['sort']:0);

HtmlBuilder::buildSelectSearch('需要重绑','unbind',array(
    0 => '全部',
    1 => '需要重绑',
),isset($_GET['unbind'])?$_GET['unbind']:0);

HtmlBuilder::buildFormEnd();

?>

<a id="export_cards" data-url="<?php echo $this->genurl('export'); ?>" class="btn">按搜索条件导出MAC</a>
<span class="search"><label>备注：</label><input id="mac_remark" name="mac_remark" value=""></span>

<table class="x-table x-table-even">
    <thead align="center">
        <tr>
            <th>ID</th>
            <th>MAC地址</th>
            <th>网关ID</th>
            <th>最近使用账号</th>
            <th>到期时间</th>
            <th>最近使用卡密</th>
            <th>状态</th>
            <th>操作</th>
        </tr>
    </thead>
    <tbody align="center">
        <?php foreach($list as $data): ?>
            <tr class="<?php echo $data['color_class']; ?>">
                <td><?php echo $data['id']; ?></td>
                <td><?php echo $data['mac']; ?></td>
                <td><?php echo $data['wg_id']; ?></td>
                <td><?php echo $data['account']; ?></td>
                <td><?php echo $data['u_end_time_str']; ?></td>
                <td><?php echo $data['code']; ?></td>
                <td><?php echo $data['status']; ?></td>
                <td>
                    <?php if($data['color_class']): ?>
                        <a data-id="<?php echo $data['id']; ?>"
                           data-href="<?php echo $this->genurl('unbind'); ?>"
                           class="btn btn_unbind">释放</a>
                    <?php endif; ?>
                    <a data-id="<?php echo $data['id']; ?>"
                       data-href="<?php echo $this->genurl('del'); ?>"
                       class="btn btn_del">删除</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php HtmlBuilder::buildPage($now_page,$all_num); ?>

<script>
    $('.btn_unbind').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var id = this_e.data('id');
        var post_data = {"id":id};

        if(confirm('确定要释放该MAC？释放后该MAC即可被新卡密所占用')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });

    $('.btn_del').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var id = this_e.data('id');
        var post_data = {"id":id};

        if(confirm('确定要删除该MAC？')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });

    $('#export_cards').click(function(){
        var this_e = $(this);

        if(confirm('单次导出最多1000个MAC,超出将无法导出,确定继续？')){
            var mac_remark = $('#mac_remark').val();

            var real_url = this_e.data('url');
            var post_data = $('.search_form').serialize();
            window.location.href = real_url+'&'+post_data+'&mac_remark='+mac_remark;
        }
    });
</script>