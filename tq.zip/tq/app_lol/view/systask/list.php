<div>
    <label>网关ID</label>
    <input style="width: 60px;" id="wg_id" value="" type="text">
    <a id="btn_add" data-href="<?php echo $this->genurl('add'); ?>" class="btn">添加重启任务</a>
</div>

<table class="x-table x-table-even">
    <thead align="center">
        <tr>
            <th>序号</th>
            <th>网关ID</th>
            <th>状态</th>
            <th>添加时间</th>
        </tr>
    </thead>
    <tbody align="center">
        <?php foreach($list as $data): ?>
            <tr>
                <td><?php echo $data['id']; ?></td>
                <td><?php echo $data['wg_id']; ?></td>
                <td><?php echo $data['status']; ?></td>
                <td><?php echo $data['time']; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php HtmlBuilder::buildPage($now_page,$all_num); ?>

<script>
    $('#btn_add').click(function(){
        var wg_id = $('#wg_id').val();
        if(wg_id == ''){
            alert('网关ID不可以为空');
            return;
        }

        var url = $(this).data('href');
        if(confirm('确定给 网关ID：'+wg_id.toString()+' 添加重启任务？')){
            $.app.postData(url,{wg_id:wg_id},function(){
                alert('操作成功');
                window.location.reload();
            });
        }
    });
</script>