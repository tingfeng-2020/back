<style>
    textarea{
        width: 300px;
        min-height: 100px;
        position: absolute;
        top: 38px;
        left: 105px;
        text-align: left;
        resize:none;
    }
    #save_edit_info{
        position: absolute;
        left: 105px;
        top: 155px;
    }
</style>

<form style="position: relative;" action="<?php echo $this->genurl('save'); ?>" class="edit_form">
    <div class="attr">
        <span class="attr_name">QQ群：</span>
        <span class="attr_info">
            <input name="qq_qun" type="text" value="<?php echo $qq_qun; ?>">
            <span>绑定QQ群，不填写则不绑定</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">公告：</span>
        <span class="attr_info">
            <textarea name="msg" style=""><?php echo $msg; ?></textarea>
        </span>
    </div>

    <a id="save_edit_info" href="javascript:;" class="btn">保存</a>
</form>

<script>
    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'));
    });
</script>