<form action="<?php echo $this->genurl('altsave',array('id'=>$card['id'])); ?>" class="edit_form">

    <div class="attr">
        <span class="attr_name">卡密：</span>
        <span class="attr_info">
            <?php echo $card['code']; ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">限制网关ID：</span>
        <span class="attr_info">
            <input name="can_use_wg" type="text" value="<?php echo $card['can_use_wg']; ?>">
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">标记：</span>
        <span class="attr_info">
            <input name="group_str" type="text" value="<?php echo $card['group_str']; ?>">
        </span>
    </div>

    <?php if(Manage::isHermitAdmin()): ?>
        <div class="attr">
            <span class="attr_name">是否结算：</span>
            <span class="attr_info">
                <?php HtmlBuilder::buildSelect('is_pay',array(
                    0 => '未结算',
                    1 =>  '已结算'
                ),$card['is_pay']); ?>
            </span>
        </div>
    <?php endif; ?>

    <a id="save_edit_info" href="javascript:;" class="btn">保存</a>
</form>

<script>
    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'));
    });
</script>