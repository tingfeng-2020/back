<form action="<?php echo $this->genurl('checkData'); ?>" data-url="<?php echo $this->genurl('save'); ?>" class="edit_form">
    <div class="attr">
        <span class="attr_name">卡密标记：</span>
        <span class="attr_info">
            <input name="group_str" type="text">
            <span>用于卡密分组 例如：2017-05-23 QQ123456 (长度不能超过20)</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">生成张数：</span>
        <span class="attr_info">
            <input id="card_num" name="num" type="text">
            <span>最大一次性可以生成1000张卡密</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">卡密时长：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('card_type',$type_arr,'','name'); ?>
        </span>
    </div>

    <?php if(Manage::isSuperAdmin()): ?>
    <div class="attr">
        <span class="attr_name">类型：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('type',array(
                Card::TYPE_SALE => '销售',
                Card::TYPE_GIVE => '赠送'
            ),Card::TYPE_SALE); ?>
        </span>
    </div>
    <?php endif; ?>

    <?php if(Manage::isHermitAdmin()): ?>
    <div class="attr">
        <span class="attr_name">价格：</span>
        <span class="attr_info">
            <input name="new_money" type="text">
        </span>
    </div>
    <?php endif; ?>

    <div class="attr">
        <span class="attr_name">单张价格：</span>
        <span id="money" class="attr_info"><?php echo $first_card_type['money']; ?></span>
    </div>

    <div class="attr">
        <span class="attr_name">次数或时长：</span>
        <span id="info" class="attr_info"><?php echo $first_card_type['num']; ?></span>
    </div>

    <a id="save_edit_info" href="javascript:;" class="btn">生成并且下载卡密</a>
</form>

<script>
    var card_type_arr = eval(<?php echo empty($type_arr)?'{}':json_encode($type_arr); ?>);
    $('#card_type').change(function(){
        var type_id = $(this).val();
        if(card_type_arr.hasOwnProperty(type_id)){
            $('#money').html(card_type_arr[type_id]['money']);
            $('#info').html(card_type_arr[type_id]['num']);
        }else{
            $('#money').html('');
            $('#info').html('');
        }
    });

    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'),function(){
            var search_form = $('.edit_form');
            var url = search_form.data('url');
            var post_data = search_form.serialize();

            window.open(url+'&'+post_data);

            setTimeout(function(){
                window.location.href = '<?php echo $this->genurl('index'); ?>';
            },2000);
        });
    });
</script>