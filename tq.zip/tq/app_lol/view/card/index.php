<style>
    input{
        width: 100px;
    }
</style>

<?php

HtmlBuilder::buildFormStart($this->genurl('index'));

HtmlBuilder::buildInputSearch(array(
    'code' => '卡密',
    'group_str' => '标记',
    'account' => '使用账号'
));

if(Manage::isSuperAdmin()){
    HtmlBuilder::buildInputSearch(array(
        'cuser' => '创建者',
    ));
}

//HtmlBuilder::buildStartAndEndSearch(
//    '创建时间',
//	isset($_GET['s_time'])?$_GET['s_time']:'',
//	isset($_GET['e_time'])?$_GET['e_time']:''
//);

HtmlBuilder::buildSelectSearch('卡密状态','status',array(
    0 => '全部',
    Card::STATUS_OK => '未使用',
    Card::STATUS_USE => '已使用',
),isset($_GET['status'])?$_GET['status']:0);

HtmlBuilder::buildSelectSearch('类型','type',array(
    0 => '全部',
    Card::TYPE_SALE => '销售',
    Card::TYPE_GIVE => '赠送',
),isset($_GET['type'])?$_GET['type']:0);

if(Manage::isHermitAdmin()){
    HtmlBuilder::buildSelectSearch('是否结算','pay',array(
        0 => '全部',
        1 => '已结算',
        2 => '未结算',
    ),isset($_GET['pay'])?$_GET['pay']:0);
}

HtmlBuilder::buildStartAndEndSearch(
    '使用时间',
	isset($_GET['use_s_time'])?$_GET['use_s_time']:'',
	isset($_GET['use_e_time'])?$_GET['use_e_time']:'',
    'use_s_time',
    'use_e_time'
);

HtmlBuilder::buildFormEnd();

?>

<a href="<?php echo $this->genurl('batchCreate'); ?>" class="btn">批量生成卡密</a>

<a id="export_cards" data-href="<?php echo $this->genurl('exportcheck'); ?>" data-url="<?php echo $this->genurl('export'); ?>" class="btn">按搜索条件导出卡密</a>

<?php if(Manage::isHermitAdmin()): ?>
<a id="btn_jiesuan" data-href="<?php echo $this->genurl('jiesuan'); ?>" class="btn">按搜索条件结算卡密</a>
<?php endif; ?>

<table class="x-table x-table-even">
    <thead align="center">
        <tr>
            <th>标记</th>
            <th>卡密</th>
            <?php if(Manage::isSuperAdmin()): ?>
                <th>创建者</th>
            <?php endif; ?>
            <th>时长</th>
            <th>创建时间</th>
            <th>使用时间</th>
            <th>使用账号</th>
            <?php if(Manage::isHermitAdmin()): ?>
                <th>价格</th>
                <th>是否结算</th>
            <?php endif; ?>
            <th>类型</th>
            <th>操作</th>
        </tr>
    </thead>
    <tbody align="center">
        <?php foreach($list as $data): ?>
            <tr>
                <td><?php echo $data['group_str']; ?></td>
                <td><?php echo $data['code']; ?></td>
                <?php if(Manage::isSuperAdmin()): ?>
                    <td><?php echo $data['m_account']; ?></td>
                <?php endif; ?>
                <td><?php echo $data['num']; ?></td>
                <td><?php echo $data['time']; ?></td>
                <td><?php echo $data['use_time']; ?></td>
                <td><?php echo $data['account']; ?></td>
                <?php if(Manage::isHermitAdmin()): ?>
                    <td><?php echo $data['money']; ?></td>
                    <td><?php echo $data['is_pay']; ?></td>
                <?php endif; ?>
                <td><?php echo $data['card_type']; ?></td>
                <td>
                    <?php if(Manage::isSuperAdmin()): ?>
                        <a href="<?php echo $this->genurl('alt',array('id'=>$data['id'])); ?>" class="btn">编辑</a>
                    <?php endif; ?>
                	<?php if(AuthManage::isHave(AuthManage::CARD_BANED_CHANGE)): ?>
                    <a data-code="<?php echo $data['code']; ?>"
                        data-href="<?php echo $this->genurl('getnew'); ?>"
                        class="btn btn_get_new">封换</a>
                    <?php endif; ?>
                    <?php if(AuthManage::isHave(AuthManage::CARD_DEL)): ?>
                        <a data-code="<?php echo $data['code']; ?>"
                            data-href="<?php echo $this->genurl('del'); ?>"
                            class="btn btn_del">删除</a>
                        <a data-code="<?php echo $data['code']; ?>"
                            data-href="<?php echo $this->genurl('del'); ?>"
                            class="btn btn_del_all">封卡</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php HtmlBuilder::buildPage($now_page,$all_num); ?>

<script>
    $('.btn_unbind').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var id = this_e.data('id');
        var post_data = {"id":id};

        if(confirm('确定 解绑 该卡密？')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });

	<?php if(Manage::isManage()): ?>
	    $('.btn_get_new').click(function(){
	        var this_e = $(this);
	        var url = this_e.data('href');
	        var code = this_e.data('code');
	        var post_data = {"code":code};

	        if(confirm('确定 封换 该卡密,封换后该卡密将被删除？然后返回对应余额给制卡代理')){
	            $.app.postData(url,post_data,function(){
	                window.location.reload();
	            });
	        }
	    });
    <?php endif; ?>

    $('.btn_del').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var code = this_e.data('code');
        var post_data = {"code":code};

        if(confirm('确定删除该卡密？(卡密未使用将会返还余额到制卡代理)')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });

    $('.btn_del_all').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var code = this_e.data('code');
        var post_data = {"code":code,'del':1};

        if(confirm('确定封卡？(卡密封禁不返回余额)')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });

    <?php if(Manage::isHermitAdmin()): ?>
   	$('#btn_jiesuan').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var post_data = $('.search_form').serialize();

        if(confirm('确定要按照当前赛选条件结算所有卡密？')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });
    <?php endif; ?>

    $('#export_cards').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var post_data = $('.search_form').serialize();

        if(confirm('单次导出最多1000张卡密,超出将无法导出,确定继续？')){
            $.app.postData(url,post_data,function(){
            	var real_url = this_e.data('url');
                window.location.href = real_url+'&'+post_data;
            });
        }
    });
</script>
