<?php

HtmlBuilder::buildFormStart($this->genurl('index'));

HtmlBuilder::buildInputSearch(array(
    'group_str' => '分组标记',
    'mac' => 'MAC地址',
    'wg_id' => '网关ID',
    'ip' => '外网IP'
));

HtmlBuilder::buildSelectSearch('到期','type',array(
    0 => '全部',
    1 => '正常',
    2 => '已到期'
),isset($_GET['type'])?$_GET['type']:0);

HtmlBuilder::buildFormEnd();

?>

<table class="x-table x-table-even">
    <thead align="center">
        <tr>
        <?php if(isset($_GET['only_mac'])): ?>
			<th>MAC地址</th>
			<th>到期时间</th>
        <?php else: ?>
            <th>ID</th>
            <th>分组标记</th>
            <th>MAC地址</th>
            <th>网关ID</th>
            <th>外网IP</th>
            <th>机器码</th>
            <th>到期时间</th>
            <th>授权总次数</th>
            <th>最近授权时间</th>
            <th>状态</th>
            <th>操作</th>
        <?php endif; ?>		
        </tr>
    </thead>
    <tbody align="center">
        <?php foreach($list as $data): ?>
            <tr>
        	<?php if(isset($_GET['only_mac'])): ?>
        		<td><?php echo $data['mac']; ?></td>
        		<td><?php echo $data['end_time']; ?></td>
        	<?php else: ?>
                <td><?php echo $data['id']; ?></td>
                <td><?php echo $data['group_str']; ?></td>
                <td><?php echo $data['mac']; ?></td>
                <td><?php echo $data['wg_id']; ?></td>
                <td><?php echo $data['ip']; ?></td>
                <td><?php echo $data['device']; ?></td>
                <td><?php echo $data['end_time']; ?></td>
                <td><?php echo $data['num']; ?></td>
                <td><?php echo $data['near_time']; ?></td>
                <td><?php echo $data['status']; ?></td>
                <td>
                    <a href="<?php echo $this->genurl('alt',array('id'=>$data['id'])); ?>" class="btn">编辑</a>

                    <a data-id="<?php echo $data['id']; ?>"
                       data-href="<?php echo $this->genurl('del'); ?>"
                       class="btn btn_del">删除</a>
                </td>
             <?php endif; ?>		
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php HtmlBuilder::buildPage($now_page,$all_num); ?>

<script>
    $('.btn_del').click(function(){
        var this_e = $(this);
        var url = this_e.data('href');
        var id = this_e.data('id');
        var post_data = {"id":id};

        if(confirm('确定要删除该MAC？')){
            $.app.postData(url,post_data,function(){
                window.location.reload();
            });
        }
    });
</script>