<form action="<?php echo $this->genurl('save',array('id'=>$mac['id'])); ?>" class="edit_form">

    <div class="attr">
        <span class="attr_name">网关ID：</span>
        <span class="attr_info">
            <?php echo $mac['wg_id']; ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">分组标记：</span>
        <span class="attr_info">
            <input name="group_str" type="text" value="<?php echo $mac['group_str']; ?>">
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">MAC地址：</span>
        <span class="attr_info">
            <input name="mac" type="text" value="<?php echo $mac['mac']; ?>">
        </span>
    </div>
	<?php if(isset($_GET['set_wg'])): ?>
    <div class="attr">
        <span class="attr_name">WG_ID：</span>
        <span class="attr_info">
            <input name="wg_id" type="text" value="<?php echo $mac['wg_id']; ?>">
        </span>
    </div>
	<?php endif; ?>

    <div class="attr">
        <span class="attr_name">到期时间：</span>
        <span class="attr_info">
            <input class="date_time" name="end_time" type="text" value="<?php echo $mac['end_time']?date('Y-m-d H:i:s',$mac['end_time']):''; ?>">
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">状态：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('status',array(
                0 => '未授权',
                1 => '已授权'
            ),$mac['status']); ?>
        </span>
    </div>

    <a id="save_edit_info" href="javascript:;" class="btn">保存</a>
</form>

<script>
    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'));
    });
</script>