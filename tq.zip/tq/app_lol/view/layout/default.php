<!DOCTYPE html>
<html>
<head>
    <title><?php echo H::app()->getConfig('app_name'); ?></title>

    <meta charset="utf-8">
    <meta content="telephone=no,email=no" name="format-detection">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta name="renderer" content="webkit">

    <link rel="icon" href="<?php echo H::app()->public_url; ?>/images/favicon.ico" sizes="any">

    <link href="<?php echo $this->getAppPublicUrl(); ?>/css/base.css?time=201706091728" type="text/css" rel="stylesheet">

    <script src="<?php echo H::app()->public_url; ?>/js/jquery.min.js"></script>
</head>
<body>
    <!-- head -->
    <div class="header">
        <span id="tip_info">角色：<?php echo Manage::getMeInfo('account'); ?>
            余额：<?php echo Manage::getMeInfo('money'); ?>元
        </span>
        <a id="logout" href="<?php echo $this->genurl('login/logout'); ?>">退出</a>
    </div>

    <!-- navbar -->
    <div class="left_navbar">
        <div id="logo">渠道</br>特权</div>
        <a href="<?php echo $this->genurl('user/index'); ?>" class="<?php echo $this->controller=='user'?'hover':''; ?>">用户管理</a>
        <a href="<?php echo $this->genurl('card/index'); ?>" class="<?php echo $this->controller=='card'?'hover':''; ?>">卡密管理</a>

        <?php if(AuthManage::isHave(AuthManage::SET_SOFT_NOTICE)): ?>
            <a href="<?php echo $this->genurl('soft/set'); ?>" class="<?php echo $this->controller=='soft'?'hover':''; ?>">软件设置</a>
        <?php endif; ?>

        <?php if(Manage::isSuperAdmin()): ?>
            <a href="<?php echo $this->genurl('cardType/index'); ?>" class="<?php echo $this->controller=='cardType'?'hover':''; ?>">卡密类型</a>
            <a href="<?php echo $this->genurl('wg/index'); ?>" class="<?php echo $this->controller=='wg'?'hover':''; ?>">网关设置</a>
            <a href="<?php echo $this->genurl('mac/index'); ?>" class="<?php echo $this->controller=='mac'?'hover':''; ?>">网吧MAC</a>
            <a href="<?php echo $this->genurl('wgMac/index'); ?>" class="<?php echo $this->controller=='wgMac'?'hover':''; ?>">分配MAC</a>
            <a href="<?php echo $this->genurl('manage/index'); ?>" class="<?php echo $this->controller=='manage'?'hover':''; ?>">代理管理</a>
            <a href="<?php echo $this->genurl('sys/set'); ?>" class="<?php echo $this->controller=='sys'?'hover':''; ?>">系统设置</a>
            <a href="<?php echo $this->genurl('systask/list'); ?>" class="<?php echo $this->controller=='systask'?'hover':''; ?>">重启任务</a>
            <a href="<?php echo $this->genurl('tool/index'); ?>" class="<?php echo $this->controller=='tool'?'hover':''; ?>">小小工具</a>
        <?php endif; ?>
    </div>

    <div class="content">
        <?php echo $H_VIEW_HTML; ?>
    </div>

    <script src="<?php echo H::app()->public_url; ?>/js/md5-min.js"></script>
    <script src="<?php echo $this->getAppPublicUrl(); ?>/My97DatePicker/WdatePicker.js"></script>
    <script src="<?php echo $this->getAppPublicUrl(); ?>/js/base.js?time=201706091728"></script>
</body>
</html>