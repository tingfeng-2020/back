<style>
    .show_card_list{
        color: green;
        cursor: pointer;
    }
</style>
<?php

HtmlBuilder::buildFormStart($this->genurl('index'));

HtmlBuilder::buildInputSearch(array(
    'account' => '账号',
));

HtmlBuilder::buildSelectSearch('网关','wg_id',
    Wg::getWgIdNameArr([0=>'全部']),
isset($_GET['wg_id'])?$_GET['wg_id']:0);

HtmlBuilder::buildStartAndEndSearch(
    '到期时间',
	isset($_GET['s_time'])?$_GET['s_time']:'',
	isset($_GET['e_time'])?$_GET['e_time']:'',
    's_time',
    'e_time'
);

HtmlBuilder::buildSelectSearch('状态','status',array(
    0 => '全部',
    User::STATUS_OK => '正常',
    User::STATUS_BANED => '禁用',
),isset($_GET['status'])?$_GET['status']:0);

HtmlBuilder::buildSelectSearch('排序','sort',array(
    0 => '默认',
    1 => '到期时间升序',
    2 => '到期时间降序',
),isset($_GET['sort'])?$_GET['sort']:0);

HtmlBuilder::buildSelectSearch('付费类型','pay_type',array(
    0 => '全部',
    1 => '充值过',
    2 => '未充值',
),isset($_GET['pay_type'])?$_GET['pay_type']:0);

$_uid = HSession::get('uid');
if(in_array($_uid,[1,2])){//可乐 和 我
    $search_data = [
        0 => '全部',
        User::TYPE_NORMAL => '普通',
        User::TYPE_VIP => 'VIP尊享',
        User::TYPE_CHAOFAN => '超凡',
    ];

    HtmlBuilder::buildSelectSearch('类型','type',$search_data,isset($_GET['type'])?$_GET['type']:0);
}else if($_uid == 6){//卡牌
    $search_data = [
        0 => '全部',
        User::TYPE_NORMAL => '普通',
        User::TYPE_VIP => 'VIP尊享',
    ];

    HtmlBuilder::buildSelectSearch('类型','type',$search_data,isset($_GET['type'])?$_GET['type']:0);
}

HtmlBuilder::buildFormEnd();

?>

<?php if(Manage::isSuperAdmin()): ?>
<div>
    <label>批量增加或减少时间：</label>
    <input style="width: 60px;" id="batch_num" value="" type="text">
    <a id="batch_time" data-href="<?php echo $this->genurl('batchtime'); ?>" class="btn">执行</a>
    <span>单位：小时</span>
</div>
<?php endif; ?>

<table class="x-table x-table-even">
    <thead align="center">
        <tr>
            <th>账号</th>
            <th>登录IP</th>
            <?php if(Manage::isSuperAdmin()): ?>
                <th>所属代理</th>
            <?php endif; ?>
            <th>状态</th>
            <th>到期时间</th>
            <th>授权总次数</th>
            <th>最近授权时间</th>
            <th>机器码</th>
            <th>网关</th>
            <?php if(Manage::isSuperAdmin()): ?>
                <th>分配MAC</th>
            <?php endif; ?>
            <?php if(in_array($_uid,[1,2,6])): ?>
                <th>类型</th>
            <?php endif; ?>
            <th>操作</th>
        </tr>
    </thead>
    <tbody align="center">
        <?php foreach($list as $data): ?>
            <tr>
                <td>
                    <a href="<?php echo $this->genurl('card/index',['account'=>$data['account']]); ?>" target="_blank" class="show_card_list" >
                        <?php echo $data['account']; ?>
                    </a>
                </td>
                <td><?php echo $data['ip']; ?></td>
                <?php if(Manage::isSuperAdmin()): ?>
                    <td><?php echo $data['m_account']; ?></td>
                <?php endif; ?>
                <td><?php echo $data['status_str']; ?></td>
                <td><?php echo $data['end_time']; ?></td>
                <td><?php echo $data['all_num']; ?></td>
                <td><?php echo $data['near_time']; ?></td>
                <td><?php echo $data['device']; ?></td>
                <td><?php echo $data['wg_id']; ?></td>
                <?php if(Manage::isSuperAdmin()): ?>
                    <td><?php echo $data['wg_mac_str']; ?></td>
                <?php endif; ?>
                <?php if(in_array($_uid,[1,2,6])): ?>
                    <td><?php echo $data['type']; ?></td>
                <?php endif; ?>
                <td>
                    <?php if(Manage::isSuperAdmin()): ?>
                        <a href="<?php echo $this->genurl('alt',array('id'=>$data['id'])); ?>" class="btn">编辑</a>
                    <?php endif; ?>
                    <?php if(AuthManage::isHave(AuthManage::USER_UNBIND)): ?>
                        <a data-href="<?php echo $this->genurl('unbind',['id'=>$data['id']]); ?>" class="btn btn_unbind">解绑</a>
                    <?php endif; ?>
                    <?php if(AuthManage::isHave(AuthManage::USER_BANED)): ?>
                        <a data-id="<?php echo $data['id']; ?>"
                            data-href="<?php echo $this->genurl('baned'); ?>"
                            class="btn btn_baned"><?php echo $data['status']==User::STATUS_OK?'禁用':'解禁'; ?></a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php HtmlBuilder::buildPage($now_page,$all_num); ?>

<script>
    <?php if(Manage::isSuperAdmin()): ?>
        $('#batch_time').click(function(){
            var num = $('#batch_num').val();
            var data = $('.search_form').serialize();
            data = data + '&num='+num;
            var url = $(this).data('href');
            if(confirm('确定执行该操作？')){
                $.app.postData(url,data,function(){
                    alert('操作成功');
                    window.location.reload();
                });
            }
        });
    <?php endif; ?>
    <?php if(AuthManage::isHave(AuthManage::USER_UNBIND)): ?>
	    $('.btn_unbind').click(function(){
	        var url = $(this).data('href');

	        if(confirm('确定执行该操作？')){
	            $.app.postData(url,{},function(){
	                window.location.reload();
	            });
	        }
	    });
    <?php endif; ?>
    <?php if(AuthManage::isHave(AuthManage::USER_BANED)): ?>
	    $('.btn_baned').click(function(){
	        var this_e = $(this);
	        var url = this_e.data('href');
	        var id = this_e.data('id');
	        var post_data = {"id":id};

	        if(confirm('确定执行该操作？')){
	            $.app.postData(url,post_data,function(){
	                window.location.reload();
	            });
	        }
	    });
    <?php endif; ?>
</script>
