<form action="<?php echo $this->genurl('save',array('id'=>$user['id'])); ?>" class="edit_form">
    <?php if(Manage::isHermitAdmin()): ?>
        <div class="attr">
            <span class="attr_name">账号：</span>
            <span class="attr_info">
                <input name="account" type="text" value="<?php echo $user['account']; ?>">
            </span>
        </div>
    <?php else: ?>
        <div class="attr">
            <span class="attr_name">账号：</span>
            <span class="attr_info"><?php echo $user['account']; ?></span>
        </div>
    <?php endif; ?>

    <div class="attr">
        <span class="attr_name">新密码：</span>
        <span class="attr_info">
            <input name="pwd" type="text">
            <span>填写就表示改密码，不填写表示不改</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">小时：</span>
        <span class="attr_info">
            <input name="num" type="text" value="0">
            <span>小时：表示增加多少时间，单位小时 负数表示减少多少小时 0表示不增加</span>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">类型：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('type',array(
                User::TYPE_NORMAL => '普通',
                User::TYPE_VIP =>  'VIP尊享',
                User::TYPE_CHAOFAN => '超凡'
            ),$user['type']); ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">是否解绑：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('unbind',array(
                0 => '不解绑',
                1 =>  '解绑'
            ),0); ?>
        </span>
    </div>

    <div class="attr">
        <span class="attr_name">是否分配网关：</span>
        <span class="attr_info">
            <?php HtmlBuilder::buildSelect('new_wg',
                Wg::getWgIdNameArr([
                    0 => '保持不变',
                    -1 => '随机分配'
                ]),
            0); ?>
        </span>
    </div>

    <a id="save_edit_info" href="javascript:;" class="btn">保存</a>
</form>

<script>
    $('#save_edit_info').click(function(){
        $.app.post($('.edit_form'));
    });
</script>