<?php

/**
 * User: Hermit
 * Date: 2017/8/24
 * Time: 0:33
 */
class HGeetest {

    private static function getGeetestObj() {
        return new GeetestLib('d0610d7af0005ba360a21034894c2c9b', 'f4619fc450724135849cce677ad812cd');
    }

    public static function getInitData() {
        $GtSdk = self::getGeetestObj();

        $data = array(
            "user_id" => uniqid(),
            "client_type" => "web",
            "ip_address" => getClientIP()
        );

        $status = $GtSdk->pre_process($data, 1);

        HSession::set('gt_server', $status);
        HSession::set('gt_uid', $data['user_id']);

        return $GtSdk->get_response();
    }

    public static function checkStatus($geetest_challenge,$geetest_validate,$geetest_seccode) {
        $GtSdk = self::getGeetestObj();

        $data = array(
            "user_id" => HSession::get('gt_uid'),
            "client_type" => "web",
            "ip_address" => getClientIP()
        );

        $gtserver = HSession::get('gt_server');
        if ($gtserver == 1) {//服务器正常
            $result = $GtSdk->success_validate($geetest_challenge,$geetest_validate,$geetest_seccode,$data);
            if ($result) {
                return true;
            }
        } else {//服务器宕机,走failback模式
            if ($GtSdk->fail_validate($geetest_challenge,$geetest_validate,$geetest_seccode)) {
                return true;
            }
        }

        return false;
    }

}