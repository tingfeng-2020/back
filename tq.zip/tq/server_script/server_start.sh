#!/bin/bash

nohup php /data/web/tq/server.php php_tcp_server &> error.log &

