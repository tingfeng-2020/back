<?php
/*


--
-- 表的结构 `lol_activity`
--

CREATE TABLE `lol_activity` (
  `id` bigint(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `s_time` bigint(20) NOT NULL COMMENT '开始时间',
  `e_time` bigint(20) NOT NULL COMMENT '结束时间',
  `num` int(10) NOT NULL DEFAULT '0' COMMENT '时长 单位小时',
  `lucy_num` int(10) NOT NULL DEFAULT '0' COMMENT '中奖数量',
  `all_num` int(10) NOT NULL DEFAULT '0' COMMENT '总数量',
  `sign_num` int(10) NOT NULL DEFAULT '0' COMMENT '标记数量',
  `odds` int(10) NOT NULL DEFAULT '0' COMMENT '中奖概率',
  `ui` varchar(100) NOT NULL DEFAULT '',
  `wg_id_str` varchar(100) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_card`
--

CREATE TABLE `lol_card` (
  `id` bigint(20) NOT NULL,
  `code` varchar(50) NOT NULL COMMENT '卡密',
  `manage_id` bigint(20) NOT NULL COMMENT '制作人ID',
  `group_str` varchar(20) NOT NULL DEFAULT '' COMMENT '标记',
  `time` bigint(20) NOT NULL COMMENT '创建时间',
  `status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1.正常 2.已使用 3.封换 4.封禁 5.删除 ',
  `type` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1.收费 2.赠送',
  `use_time` int(11) NOT NULL DEFAULT '0' COMMENT '使用时间',
  `num` int(10) NOT NULL DEFAULT '0' COMMENT '时长单位小时',
  `money` double(20,2) DEFAULT NULL COMMENT '价格',
  `end_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '到期时间',
  `near_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '最近授权时间',
  `all_num` int(10) NOT NULL DEFAULT '0' COMMENT '授权总次数',
  `device` varchar(50) NOT NULL DEFAULT '' COMMENT '机器码',
  `ip` varchar(40) NOT NULL DEFAULT '' COMMENT 'IP',
  `wg_mac_id` bigint(20) NOT NULL DEFAULT '0',
  `uid` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `can_use_wg` varchar(200) NOT NULL DEFAULT '',
  `is_pay` tinyint(3) NOT NULL DEFAULT '0',
  `card_type` bigint(20) NOT NULL DEFAULT '1' COMMENT '卡密类型 1.普通 2.内部',
  `card_type_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '卡密类型ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_card_type`
--

CREATE TABLE `lol_card_type` (
  `id` bigint(20) NOT NULL COMMENT '类型ID',
  `name` varchar(20) NOT NULL COMMENT '名称',
  `num` bigint(20) NOT NULL DEFAULT '0' COMMENT '时间秒',
  `money` double(20,2) NOT NULL DEFAULT '0.00',
  `prefix` varchar(20) NOT NULL,
  `can_use_wg` varchar(200) NOT NULL DEFAULT '' COMMENT '允许授权的WGID',
  `is_show` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否显示位置',
  `type` tinyint(3) NOT NULL DEFAULT '1' COMMENT '卡密类型 1.普通 2.内部'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_files`
--

CREATE TABLE `lol_files` (
  `id` bigint(20) NOT NULL,
  `s_time` bigint(20) NOT NULL,
  `e_time` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `path` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL,
  `ver` varchar(20) DEFAULT NULL,
  `need_kill` tinyint(3) NOT NULL DEFAULT '0',
  `type` tinyint(3) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_ip_check`
--

CREATE TABLE `lol_ip_check` (
  `ip` varchar(20) NOT NULL COMMENT 'ip',
  `last_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '上次验证时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_lucy_user`
--

CREATE TABLE `lol_lucy_user` (
  `id` bigint(20) NOT NULL,
  `activity_id` bigint(20) NOT NULL COMMENT '活动ID',
  `uid` bigint(20) NOT NULL COMMENT '用户ID',
  `time` bigint(20) NOT NULL COMMENT '中奖时间',
  `num` int(10) NOT NULL DEFAULT '0' COMMENT '中奖时长单位小时',
  `ip` varchar(20) NOT NULL COMMENT 'IP地址',
  `device` varchar(50) NOT NULL COMMENT '机器码'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_mac`
--

CREATE TABLE `lol_mac` (
  `id` bigint(20) NOT NULL COMMENT 'MACID',
  `mac` varchar(50) NOT NULL COMMENT 'MAC地址',
  `wg_id` bigint(20) NOT NULL COMMENT '网关ID',
  `device` varchar(50) NOT NULL DEFAULT '' COMMENT '机器码',
  `time` bigint(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态 1.授权成功 0.等待授权',
  `near_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '最近授权时间',
  `near_num` int(10) NOT NULL DEFAULT '0' COMMENT '最近授权次数',
  `num` int(10) NOT NULL DEFAULT '0' COMMENT '授权总次数',
  `end_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '到期时间',
  `group_str` varchar(100) DEFAULT NULL,
  `ip` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_manage`
--

CREATE TABLE `lol_manage` (
  `id` bigint(20) NOT NULL,
  `account` varchar(50) NOT NULL COMMENT '账号',
  `pwd` varchar(50) NOT NULL COMMENT '密码',
  `type` tinyint(3) NOT NULL DEFAULT '1' COMMENT '用户类型 1.代理 2.管理员 3.超管',
  `money` double(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '状态 0.禁止 1.正常 2.删除',
  `pid` bigint(20) NOT NULL DEFAULT '0' COMMENT 'PID',
  `qq` varchar(20) DEFAULT NULL,
  `auth` text,
  `can_view_card_type` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_manage_price`
--

CREATE TABLE `lol_manage_price` (
  `id` bigint(20) NOT NULL,
  `manage_id` bigint(20) NOT NULL,
  `type_id` bigint(20) NOT NULL,
  `money` double(20,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_money`
--

CREATE TABLE `lol_money` (
  `id` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `money` varchar(100) NOT NULL DEFAULT '',
  `mid` bigint(20) NOT NULL,
  `time` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_set`
--

CREATE TABLE `lol_set` (
  `id` bigint(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `data` varchar(20) DEFAULT NULL,
  `msg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_task`
--

CREATE TABLE `lol_task` (
  `id` bigint(20) NOT NULL,
  `wg_id` bigint(20) NOT NULL,
  `status` tinyint(3) DEFAULT '0' COMMENT '0.未执行 1.已执行',
  `time` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_user`
--

CREATE TABLE `lol_user` (
  `id` bigint(20) NOT NULL,
  `account` varchar(50) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `end_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '到期时间',
  `wg_mac_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '网关MACID',
  `status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '0.删除 1.正常 2.禁用',
  `all_num` int(10) NOT NULL DEFAULT '0' COMMENT '授权总次数',
  `near_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '最近授权时间',
  `device` varchar(50) NOT NULL DEFAULT '' COMMENT '机器码',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT 'IP地址',
  `manage_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `injec_game` tinyint(3) NOT NULL DEFAULT '0' COMMENT '注入游戏',
  `type` tinyint(3) NOT NULL DEFAULT '1' COMMENT '类型 1.普通客户 2.内部客户',
  `card_type_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '卡密类型ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_wg`
--

CREATE TABLE `lol_wg` (
  `id` int(10) NOT NULL COMMENT '网关ID',
  `mac` varchar(20) NOT NULL COMMENT 'MAC地址',
  `ip` varchar(40) DEFAULT NULL COMMENT 'IP地址',
  `ip_inner` varchar(40) DEFAULT NULL COMMENT '内网IP',
  `mac_num` int(10) NOT NULL DEFAULT '0' COMMENT '可授权数量',
  `type` tinyint(3) DEFAULT '0' COMMENT '类型 0.未授权 1.授权',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态 0.离线 1.在线',
  `account` text,
  `local_config` text,
  `time` bigint(20) NOT NULL DEFAULT '0' COMMENT '网关连接时间',
  `off_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '掉线时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `lol_wg_mac`
--

CREATE TABLE `lol_wg_mac` (
  `id` bigint(20) NOT NULL COMMENT 'MACID',
  `mac` varchar(50) NOT NULL COMMENT 'MAC地址',
  `wg_id` bigint(20) NOT NULL COMMENT '网关ID',
  `card_id` bigint(20) NOT NULL DEFAULT '0',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0.离线 1.在线',
  `last_use_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '上次使用时间',
  `uid` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转储表的索引
--

--
-- 表的索引 `lol_activity`
--
ALTER TABLE `lol_activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `s_e_time` (`s_time`,`e_time`);

--
-- 表的索引 `lol_card`
--
ALTER TABLE `lol_card`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`),
  ADD KEY `end_time` (`end_time`);

--
-- 表的索引 `lol_card_type`
--
ALTER TABLE `lol_card_type`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lol_files`
--
ALTER TABLE `lol_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `se` (`s_time`,`e_time`);

--
-- 表的索引 `lol_ip_check`
--
ALTER TABLE `lol_ip_check`
  ADD PRIMARY KEY (`ip`),
  ADD KEY `ip` (`ip`);

--
-- 表的索引 `lol_lucy_user`
--
ALTER TABLE `lol_lucy_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `activity_id` (`activity_id`);

--
-- 表的索引 `lol_mac`
--
ALTER TABLE `lol_mac`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mac` (`mac`);

--
-- 表的索引 `lol_manage`
--
ALTER TABLE `lol_manage`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lol_manage_price`
--
ALTER TABLE `lol_manage_price`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mid` (`manage_id`);

--
-- 表的索引 `lol_money`
--
ALTER TABLE `lol_money`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lol_set`
--
ALTER TABLE `lol_set`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lol_task`
--
ALTER TABLE `lol_task`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lol_user`
--
ALTER TABLE `lol_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account` (`account`);

--
-- 表的索引 `lol_wg`
--
ALTER TABLE `lol_wg`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lol_wg_mac`
--
ALTER TABLE `lol_wg_mac`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mac` (`mac`),
  ADD KEY `last_use_time` (`last_use_time`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `lol_activity`
--
ALTER TABLE `lol_activity`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_card`
--
ALTER TABLE `lol_card`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_card_type`
--
ALTER TABLE `lol_card_type`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '类型ID';

--
-- 使用表AUTO_INCREMENT `lol_files`
--
ALTER TABLE `lol_files`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_lucy_user`
--
ALTER TABLE `lol_lucy_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_mac`
--
ALTER TABLE `lol_mac`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'MACID';

--
-- 使用表AUTO_INCREMENT `lol_manage`
--
ALTER TABLE `lol_manage`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_manage_price`
--
ALTER TABLE `lol_manage_price`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_money`
--
ALTER TABLE `lol_money`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_set`
--
ALTER TABLE `lol_set`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_task`
--
ALTER TABLE `lol_task`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_user`
--
ALTER TABLE `lol_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `lol_wg`
--
ALTER TABLE `lol_wg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '网关ID';

--
-- 使用表AUTO_INCREMENT `lol_wg_mac`
--
ALTER TABLE `lol_wg_mac`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'MACID';
COMMIT;


*/